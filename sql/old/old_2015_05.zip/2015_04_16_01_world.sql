
update quest_template set RequestItemsText="Did you find the Collector?  Did you discover whom he's working for?" where Id=147;



