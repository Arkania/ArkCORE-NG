
UPDATE `quest_template` SET `Flags`=8388616  WHERE `Id`= 26505; --   ++unk24 sniff=8 (tc=8388616)
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26508;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26509;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26511;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26510;
UPDATE `quest_template` SET `Flags`=2424836  WHERE `Id`= 26512;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26513;
UPDATE `quest_template` SET `Flags`=589824  WHERE `Id`= 26514; --   -auto_complete (tc=sniff=589824) (ytdb=524288)
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26519;
UPDATE `quest_template` SET `Flags`=589824  WHERE `Id`= 26544;
UPDATE `quest_template` SET `Flags`=524288  WHERE `Id`= 26545;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26520;
UPDATE `quest_template` SET `Flags`=262152  WHERE `Id`= 26567;
UPDATE `quest_template` SET `Flags`=8650760  WHERE `Id`= 26728; --  ++unk24 sniff=262152 (ng ++unk25) (tc=8650760)
UPDATE `quest_template` SET `Flags`=16777224  WHERE `Id`= 26568;
UPDATE `quest_template` SET `Flags`=65544  WHERE `Id`= 26571;
UPDATE `quest_template` SET `Flags`=262152  WHERE `Id`= 26586;
UPDATE `quest_template` SET `Flags`=0  WHERE `Id`= 26569;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26570;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26587;
UPDATE `quest_template` SET `Flags`=8912896  WHERE `Id`= 26573; --  ++unk24 sniff=524288 (tc=8912896)
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26560;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26561;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26562;
UPDATE `quest_template` SET `Flags`=8650760  WHERE `Id`= 26563; --  ++unk24 sniff=262152 (tc=8650760)
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26607;
UPDATE `quest_template` SET `Flags`=4194314  WHERE `Id`= 26616;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26639;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26636;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26637;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26638;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26640;
UPDATE `quest_template` SET `Flags`=2162688  WHERE `Id`= 26646;  --  -auto_complete (tc=sniff=2162688) (ytdb=2097152)
UPDATE `quest_template` SET `Flags`=272105472  WHERE `Id`= 26651;
UPDATE `quest_template` SET `Flags`=5242882  WHERE `Id`= 26668;
UPDATE `quest_template` SET `Flags`=65536  WHERE `Id`= 26693;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26692; --  		-auto_complete (ytdb=sniff=8) (tc=65544)
UPDATE `quest_template` SET `Flags`=2621440  WHERE `Id`= 26694;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26708;
UPDATE `quest_template` SET `Flags`=5308416  WHERE `Id`= 26713; --  -auto_complete (tc=sniff=5308416) (ytdb=5242880)
UPDATE `quest_template` SET `Flags`=5767168  WHERE `Id`= 26714;
UPDATE `quest_template` SET `Flags`=8  WHERE `Id`= 26726;
