
update creature set position_z=25.1136 where guid=93786 and id=38225;

update creature set position_x=-750.315, position_y=-5595.826, position_z=-7.598, orientation=2.5416 where guid=88902 and id=38300;

update creature_template set AIName="", ScriptName="npc_echo_isles_quest_bunny" where entry=38003;