
delete from playercreateinfo_item where race>0 and class=6 and itemid=40582;
insert into playercreateinfo_item (race,class,itemid,amount) value
(0,6,40582,-1);
