


 
UPDATE `playercreateinfo_spell` SET `racemask`=2097152 WHERE `racemask`=22;
UPDATE `playercreateinfo_spell` SET `racemask`=1024 WHERE `racemask`=11;
UPDATE `playercreateinfo_spell` SET `racemask`=512 WHERE `racemask`=10;
UPDATE `playercreateinfo_spell` SET `racemask`=256 WHERE `racemask`=9;
UPDATE `playercreateinfo_spell` SET `racemask`=128 WHERE `racemask`=8;
UPDATE `playercreateinfo_spell` SET `racemask`=64 WHERE `racemask`=7;
UPDATE `playercreateinfo_spell` SET `racemask`=32 WHERE `racemask`=6;
UPDATE `playercreateinfo_spell` SET `racemask`=16 WHERE `racemask`=5;
UPDATE `playercreateinfo_spell` SET `racemask`=8 WHERE `racemask`=4;
UPDATE `playercreateinfo_spell` SET `racemask`=4 WHERE `racemask`=3;
 
UPDATE `playercreateinfo_spell` SET `classmask`=1024 WHERE `classmask`=11;
UPDATE `playercreateinfo_spell` SET `classmask`=256 WHERE `classmask`=9;
UPDATE `playercreateinfo_spell` SET `classmask`=128 WHERE `classmask`=8;
UPDATE `playercreateinfo_spell` SET `classmask`=64 WHERE `classmask`=7;
UPDATE `playercreateinfo_spell` SET `classmask`=32 WHERE `classmask`=6;
UPDATE `playercreateinfo_spell` SET `classmask`=16 WHERE `classmask`=5;
UPDATE `playercreateinfo_spell` SET `classmask`=8 WHERE `classmask`=4;
UPDATE `playercreateinfo_spell` SET `classmask`=4 WHERE `classmask`=3;
 
UPDATE `playercreateinfo_spell_custom` SET `racemask`=2097152 WHERE `racemask`=22;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=1024 WHERE `racemask`=11;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=512 WHERE `racemask`=10;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=256 WHERE `racemask`=9;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=128 WHERE `racemask`=8;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=64 WHERE `racemask`=7;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=32 WHERE `racemask`=6;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=16 WHERE `racemask`=5;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=8 WHERE `racemask`=4;
UPDATE `playercreateinfo_spell_custom` SET `racemask`=4 WHERE `racemask`=3;
 
UPDATE `playercreateinfo_spell_custom` SET `classmask`=1024 WHERE `classmask`=11;
UPDATE `playercreateinfo_spell_custom` SET `classmask`=256 WHERE `classmask`=9;
UPDATE `playercreateinfo_spell_custom` SET `classmask`=128 WHERE `classmask`=8;
UPDATE `playercreateinfo_spell_custom` SET `classmask`=64 WHERE `classmask`=7;
UPDATE `playercreateinfo_spell_custom` SET `classmask`=32 WHERE `classmask`=6;
UPDATE `playercreateinfo_spell_custom` SET `classmask`=16 WHERE `classmask`=5;
UPDATE `playercreateinfo_spell_custom` SET `classmask`=8 WHERE `classmask`=4;
UPDATE `playercreateinfo_spell_custom` SET `classmask`=4 WHERE `classmask`=3;
 