
UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Kehrt zu Prinz Liam Graumähne am Händlerplatz in Gilneas zurück." WHERE Id=14093;

UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Kehrt zu Gwen Armstead am Händlerplatz in Gilneas zurück." WHERE Id=14094;

UPDATE locales_quest SET EndText_loc3="" WHERE Id=14098;

update creature set SpawnDist=0, MovementType=0 where id=35830;

UPDATE locales_quest SET OfferRewardText_loc3="$N! Ich wusste, dass Ihr hier irgendwo sein müsst." WHERE Id=14275;

UPDATE locales_quest SET OfferRewardText_loc3="Ihr lernst mit solch einer schnelligkeit und leichtigkeit, bald werdet Ihr der Lehrer sein.", RequestItemsText_loc3="Ich wusste immer, Ihr begreift schnell!" WHERE Id=14281;

UPDATE quest_template SET QuestGiverTextWindow="Wounded Guard", QuestGiverTargetName="Wounded Guard" WHERE Id=14283;
UPDATE locales_quest SET Title_loc3="Ein Hauch von Verjüngung", Objectives_loc3="Sprecht mit Celestine Erntedank und lernt 'Verjüngung'. Übt Verjüngung an einer verwundeten Wache.", Details_loc3="Wir standen schon einmal am Rande der Ausrottung, $N. Aber wir Druiden, Hüter des alten Wegs, haben unsere Leute vor der Hungersnot gerettet.$B$BAls wir uns selbst von der Außenwelt abschnitten und unsere Ernte ein Misserfolg war, war es unser Orden, der den Segen der Erde herbeigerufen und die Früchte wieder zum Wachsen gebracht hat.$B$BGenauso wie damals sollten wir unser Schicksal in die Hände einer höheren Macht legen. Kommt mit mir und lernt, was die Wildnis uns zu lehren hat. Geht, entwickelt Eure Kräfte und setzt das ein, was Ihr erlernt habt.", OfferRewardText_loc3="Gar nicht so schlecht. Gar nicht so schlecht. Vielleicht gibt es noch Hoffnung für die alten Wege.", RequestItemsText_loc3="Die Erde spricht zu uns, $N. Sie wird uns nicht verlassen, besonders nicht in diesen gefährlichen Zeiten.", ObjectiveText1_loc3="Übt Verjüngung", QuestGiverTextWindow_loc3="Verwundete Wache", QuestGiverTargetName_loc3="Verwundete Wache" WHERE Id=14283;

UPDATE locales_quest SET OfferRewardText_loc3="Oh, Hallo! Da seid Ihr ja!" WHERE Id=14269;

UPDATE locales_quest SET OfferRewardText_loc3="Werdet jetzt nur nicht überheblich. Vergesst nicht wer Ihnen alles beigebracht hat.$B$BUnd jetzt wollen wir sehen, ob wir uns aus dieser Stadt mit heiler Haut retten können." WHERE Id=14272;

UPDATE locales_quest SET OfferRewardText_loc3="Ausgezeichnete Arbeit, SN. Diese Worgen werden bereuen, dass sie je einen Fuß auf unser Land gesetzt haben.", ObjectiveText1_loc3="Übt 'Zuverlässiger Schuss'" WHERE Id=14276;







