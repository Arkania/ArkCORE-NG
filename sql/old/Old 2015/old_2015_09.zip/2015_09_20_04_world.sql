DELETE FROM `creature` WHERE `guid` in (278391, 278392, 278393, 278394, 250975);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`phaseMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`MovementType`,`npcflag`,`unit_flags`,`dynamicflags`) VALUES
(278391, 35011, 654, 1, 2, 0, 0, -1499.54, 1397.65, 35.5562, 4.5355, 300, 0, 0, 4121, 0, 0, 0, 0, 0),
(278392, 35011, 654, 1, 2, 0, 0, -1504.24, 1420.34, 35.5562, 4.88894, 300, 0, 0, 4121, 0, 0, 0, 0, 0),
(278393, 35011, 654, 1, 2, 0, 0, -1439.96, 1392.98, 35.5562, 1.51958, 300, 0, 0, 4121, 0, 0, 0, 0, 0),
(278394, 35011, 654, 1, 2, 0, 0, -1403.23, 1369.82, 35.5562, 1.57849, 300, 0, 0, 4121, 0, 0, 0, 0, 0),
(250975, 35011, 654, 1, 2, 0, 0, -1570.67, 1322.7, 35.6393, 0, 300, 0, 0, 4121, 0, 0, 0, 0, 0);
