
UPDATE quest_template SET NextQuestIdChain=14281 WHERE Id=14277;

UPDATE locales_quest SET OfferRewardText_loc3="Ein Schüler des Arkanen findet immer seinen Weg. Es freut mich Euch zu sehen, $N." WHERE Id=14277;


