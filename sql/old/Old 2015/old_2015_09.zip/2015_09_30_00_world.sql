

DROP TABLE IF EXISTS `archaeology_digsites`;
DROP TABLE IF EXISTS `archaeology_digsites_positions`;


