
UPDATE creature_template SET mindmg=32, maxdmg=43, attackpower=78, rangeattacktime=2000, minrangedmg=22, maxrangedmg=32, rangedattackpower=6 WHERE entry=1860;
UPDATE creature_template SET mindmg=29, maxdmg=39, attackpower=70, minrangedmg=20, maxrangedmg=30, rangedattackpower=4 WHERE entry=4627;
UPDATE creature_template SET mindmg=13, maxdmg=17, attackpower=42, minrangedmg=9, maxrangedmg=13, rangedattackpower=100 WHERE entry=5676;
UPDATE creature_template SET mindmg=56, maxdmg=74, attackpower=136, rangeattacktime=2000, minrangedmg=39, maxrangedmg=57, rangedattackpower=14 WHERE entry=5729;
UPDATE creature_template SET mindmg=77, maxdmg=102, attackpower=188, minrangedmg=52, maxrangedmg=77, rangedattackpower=17 WHERE entry=8656;
UPDATE creature_template SET mindmg=20, maxdmg=27, attackpower=50, dmg_multiplier=1, rangeattacktime=2000, minrangedmg=13, maxrangedmg=1, Health_mod=0.4444 WHERE entry=8996;
UPDATE creature_template SET mindmg=104, maxdmg=138, attackpower=252, minrangedmg=72, maxrangedmg=106, rangedattackpower=26 WHERE entry=15146;
UPDATE creature_template SET mindmg=152, maxdmg=210, attackpower=244, minrangedmg=120, maxrangedmg=179, rangedattackpower=25 WHERE entry=16974;
UPDATE creature_template SET mindmg=152, maxdmg=210, attackpower=244, minrangedmg=120, maxrangedmg=179, rangedattackpower=25 WHERE entry=16974;
UPDATE creature_template SET mindmg=172, maxdmg=240, attackpower=262, minrangedmg=139, maxrangedmg=207, rangedattackpower=30 WHERE entry=17014;
UPDATE creature_template SET mindmg=252, maxdmg=357, attackpower=304, dmg_multiplier=7.5000, rangeattacktime=2000, minrangedmg=215, maxrangedmg=320 WHERE entry=19427;
UPDATE creature_template SET mindmg=146, maxdmg=192, attackpower=238, minrangedmg=101, maxrangedmg=167, rangedattackpower=24 WHERE entry=20145;
UPDATE creature_template SET mindmg=2, maxdmg=2, attackpower=24, rangeattacktime=2000, minrangedmg=1, maxrangedmg=1 WHERE entry=418;
UPDATE creature_template SET mindmg=37, maxdmg=49, attackpower=90, rangeattacktime=2000, minrangedmg=25, maxrangedmg=37, rangedattackpower=7 WHERE entry=1861;
UPDATE creature_template SET mindmg=2, maxdmg=2, attackpower=24, rangeattacktime=2000, minrangedmg=1, maxrangedmg=1 WHERE entry=2710;
UPDATE creature_template SET mindmg=2, maxdmg=2, attackpower=24, rangeattacktime=2000, minrangedmg=1, maxrangedmg=1 WHERE entry=5016;
UPDATE creature_template SET mindmg=2, maxdmg=2, attackpower=24, rangeattacktime=2000, minrangedmg=1, maxrangedmg=1 WHERE entry=7129;
UPDATE creature_template SET mindmg=2, maxdmg=2, attackpower=24, rangeattacktime=2000, minrangedmg=1, maxrangedmg=1 WHERE entry=7130;
UPDATE creature_template SET mindmg=2, maxdmg=2, attackpower=24, rangeattacktime=2000, minrangedmg=1, maxrangedmg=1 WHERE entry=7131;
UPDATE creature_template SET mindmg=104, maxdmg=138, attackpower=252, rangeattacktime=2000, minrangedmg=72, maxrangedmg=106, rangedattackpower=26 WHERE entry=19287;
UPDATE creature_template SET mindmg=252, maxdmg=357, attackpower=304, dmg_multiplier=13, rangeattacktime=2000, minrangedmg=215, maxrangedmg=320, rangedattackpower=44 WHERE entry=20665;
UPDATE creature_template SET mindmg=159, maxdmg=221, attackpower=258, rangeattacktime=2000, minrangedmg=127, maxrangedmg=188, rangedattackpower=28 WHERE entry=19233;
UPDATE creature_template SET mindmg=2, maxdmg=2, attackpower=24, rangeattacktime=2000, minrangedmg=1, maxrangedmg=1 WHERE entry=19237;
UPDATE creature_template SET mindmg=50, maxdmg=66, attackpower=120, rangeattacktime=2000, minrangedmg=34, maxrangedmg=51, rangedattackpower=12 WHERE entry=24476;
UPDATE creature_template SET mindmg=12, maxdmg=16, attackpower=38, rangeattacktime=2000, minrangedmg=8, maxrangedmg=12 WHERE entry=39603;


