
update creature_template set exp=2 where entry in (10404,38110,1040402,1040403);
update creature_template set exp=3 where entry in (25740,26338);
update creature_template set exp=3 where entry in (25755,26342);
update creature_template set exp=3 where entry in (25756,26340);
update creature_template set exp=3 where entry in (25757,26341);
update creature_template set exp=2 where entry in (25985,26337);
update creature_template set exp=2 where entry in (31118,31491);
update creature_template set exp=2 where entry in (35564,35568);

update creature_template set VehicleId=436 where entry in (35069,35433);
update creature_template set VehicleId=201 where entry in (29838,30935);
update creature_template set VehicleId=447 where entry in (34776,69502);

update creature_template set npcflag=2 where entry in (35557,35560);

update creature_template set faction_A=21, faction_H=21 where entry in (36830,37638);
update creature_template set faction_A=534, faction_H=534 where entry in (37496,37604);


