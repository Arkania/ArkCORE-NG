
update creature_template set AIName="", ScriptName="boss_halfus_wyrmbreaker" where entry in (44600, 46209, 46210, 46211);

update creature_template set AIName="", ScriptName="boss_proto_behemoth" where entry in (44687, 46227, 46228, 46229);

update creature_template set AIName="", ScriptName="npc_halfus_dragon" where entry in (44645, 44650, 44652, 44797);

update creature_template set AIName="", ScriptName="npc_orphaned_whelp" where entry in (44641);

update gameobject_template set AIName="", ScriptName="go_halfus_whelp_cage" where entry in (205087);


 