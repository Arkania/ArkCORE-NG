
SET NAMES 'utf8';

SET @Id=8010;

update arkcore_string set content_loc3="Um die verfügbare Hilfe aufzurufen, benutze .npcbot oder .npcb" where entry=@Id+0;
update arkcore_string set content_loc3="Ausserdem könnt Ihr den Befehl .maintank(.mt oder .main) auf jedes Gruppenmitglied anwenden, so daß Eure Gruppe Euren Bedürfnissen entspricht." where entry=@Id+1;
update arkcore_string set content_loc3="Wenn Euer Bot-Helfer Euch oder jemanden aus Eurer Gruppe heilen soll, gebt ihm ein entsprechendes Schlachtzug Icon im Gruppen-Kontrollfenster." where entry=@Id+2;
update arkcore_string set content_loc3="Wenn Euer Bot-Helfer Euch oder jemanden aus Eurer Gruppe heilen soll, gebt ihm eines der folgenden Schlachtzug Icon's im Gruppen-Kontrollfenster." where entry=@Id+3;
update arkcore_string set content_loc3="Stern" where entry=@Id+4;
update arkcore_string set content_loc3="Kreis" where entry=@Id+5;
update arkcore_string set content_loc3="Diamant" where entry=@Id+6;
update arkcore_string set content_loc3="Dreieck" where entry=@Id+7;
update arkcore_string set content_loc3="Mond" where entry=@Id+8;
update arkcore_string set content_loc3="Rechteck" where entry=@Id+9;
update arkcore_string set content_loc3="Kreuz" where entry=@Id+10;
update arkcore_string set content_loc3="Totenkopf" where entry=@Id+11;
update arkcore_string set content_loc3="Ich bin hier der Tank." where entry=@Id+12;
update arkcore_string set content_loc3="Ich werde euch jetzt beschützen." where entry=@Id+13;
update arkcore_string set content_loc3="Ich beschütze euch jetzt." where entry=@Id+14;
update arkcore_string set content_loc3="Ich denke ich werde der beste Tank aller Zeiten sein..." where entry=@Id+15;
update arkcore_string set content_loc3="Ich BIN der Tank." where entry=@Id+16;
