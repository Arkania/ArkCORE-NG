
-- quest 12641 Death Comes From On High
update creature_template set modelid1=23980, modelid2=11686 where entry in (28525, 28542, 28543, 28544);
update creature_addon set auras=51939 where guid in (236953, 237079, 237083, 237087);



