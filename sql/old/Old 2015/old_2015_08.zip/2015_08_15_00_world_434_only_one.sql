
ALTER TABLE archaeology_digsites ADD BranchId TINYINT(3) NOT NULL AFTER AreaId;

