
update game_tele set name="FesteDrak'Tharon" where id=1411;
update game_tele set name="Zul'Drak" where id=1403;
update game_tele set name="Taunka'le" where id=1397;
update game_tele set name="Unu'pe" where id=1396;
update game_tele set name="Au�enpostenVonBor'gorok" where id=1394;
update game_tele set name="Zun'Watha" where id=1378;
update game_tele set name="Zul'Mashar" where id=1377;
update game_tele set name="Zul'Gurub" where id=1376;
update game_tele set name="Zul'Farrak" where id=1375;
update game_tele set name="Amanipass/Zul'Aman" where id=1374;
update game_tele set name="RuinenVonZiata'jai" where id=1372;
update game_tele set name="Zeth'Gor" where id=1370;
update game_tele set name="Zeb'Watha" where id=1368;
update game_tele set name="Zeb'Tela" where id=1367;
update game_tele set name="Zeb'Sora" where id=1366;
update game_tele set name="Zeb'Nowa" where id=1365;
update game_tele set name="Zabra'in" where id=1361;
update game_tele set name="OgerhortVul'Gol" where id=1302;
update game_tele set name="VerteidigersRuh'" where id=1299;
update game_tele set name="Vim'golsKreis" where id=1298;
update game_tele set name="Harr'ikversteck" where id=1284;
update game_tele set name="Ala'rakversteck" where id=1283;
update game_tele set name="OberesShil'akversteck" where id=1266;

