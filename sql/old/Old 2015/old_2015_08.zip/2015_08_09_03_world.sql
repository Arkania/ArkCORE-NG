update waypoint_scripts set dataint=1101 where id=271;
update waypoint_scripts set dataint=1102 where id=272;
update waypoint_scripts set dataint=1103 where id=273;
update waypoint_scripts set dataint=1104 where id=274;

