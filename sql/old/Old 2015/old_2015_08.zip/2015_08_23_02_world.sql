
-- #19
UPDATE quest_template SET RequiredRaces=2098253 WHERE Id=13188;

-- #18
UPDATE quest_template SET Method=2 WHERE Id=13166;

-- #14
update spell_area set quest_start_status=74 where spell=53081 and area=4298;


