
delete from creature where guid=112387;

UPDATE quest_template SET ExclusiveGroup=0, NextQuestIdChain=0 WHERE Id=12679;

