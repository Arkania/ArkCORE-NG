
ALTER TABLE  transports  DROP  period ;
