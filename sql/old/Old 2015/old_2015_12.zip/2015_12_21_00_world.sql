DELETE FROM game_graveyard_zone WHERE id=101 AND ghost_zone=1537;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (101, 1537, 67);

DELETE FROM game_graveyard_zone WHERE id=109 AND ghost_zone=5339;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (109, 5339, 0);

DELETE FROM game_graveyard_zone WHERE id=1411 AND ghost_zone=267;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1411, 267, 0);

DELETE FROM game_graveyard_zone WHERE id=1458 AND ghost_zone=5339;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1458, 5339, 0);

DELETE FROM game_graveyard_zone WHERE id=1722 AND ghost_zone=5146;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1722, 5146, 0);

DELETE FROM game_graveyard_zone WHERE id=1723 AND ghost_zone=5146;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1723, 5146, 0);

DELETE FROM game_graveyard_zone WHERE id=1724 AND ghost_zone=5146;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1724, 5146, 0);

DELETE FROM game_graveyard_zone WHERE id=1725 AND ghost_zone=5146;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1725, 5146, 0);

DELETE FROM game_graveyard_zone WHERE id=1745 AND ghost_zone=5146;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1745, 5146, 0);

DELETE FROM game_graveyard_zone WHERE id=1746 AND ghost_zone=5146;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1746, 5146, 0);

DELETE FROM game_graveyard_zone WHERE id=1747 AND ghost_zone=5146;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1747, 5146, 0);

DELETE FROM game_graveyard_zone WHERE id=1778 AND ghost_zone=5004;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1778, 5004, 0);

DELETE FROM game_graveyard_zone WHERE id=1778 AND ghost_zone=5146;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1778, 5146, 0);

DELETE FROM game_graveyard_zone WHERE id=389 AND ghost_zone=5339;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (389, 5339, 0);

DELETE FROM game_graveyard_zone WHERE id=96 AND ghost_zone=1497;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (96, 1497, 67);

DELETE FROM game_graveyard_zone WHERE id=109 AND ghost_zone=214;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (109, 214, 0);

DELETE FROM game_graveyard_zone WHERE id=1779 AND ghost_zone=5339;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1779, 5339, 0);

DELETE FROM game_graveyard_zone WHERE id=1780 AND ghost_zone=5339;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1780, 5339, 0);

DELETE FROM game_graveyard_zone WHERE id=1781 AND ghost_zone=5339;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1781, 5339, 0);

DELETE FROM game_graveyard_zone WHERE id=1782 AND ghost_zone=5339;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1782, 5339, 0);

DELETE FROM game_graveyard_zone WHERE id=389 AND ghost_zone=1581;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (389, 1581, 0);

DELETE FROM game_graveyard_zone WHERE id=389 AND ghost_zone=214;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (389, 214, 0);

DELETE FROM game_graveyard_zone WHERE id=39 AND ghost_zone=1638;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (39, 1638, 469);

DELETE FROM game_graveyard_zone WHERE id=1458 AND ghost_zone=5287;
INSERT INTO game_graveyard_zone (id, ghost_zone, faction) VALUES (1458, 5287, 0);


