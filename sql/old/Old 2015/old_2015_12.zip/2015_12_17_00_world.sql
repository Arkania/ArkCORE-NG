
delete from creature_text where entry=38415;
insert into creature_text values
(38415, 0, 0, "Gilneas will remember your courage forever, Liam.", 12, 0, 100, 0, 1, 0, "say",50477),
(38415, 1, 0, "Let us join your father's force's, Liam.  They'll need our help against Sylvanas.", 14, 0, 100, 0, 1, 0, "say",38361),
(38415, 2, 0, "He's too strong!  Use the catapults to bring him down!", 14, 0, 100, 0, 1, 0, "say",38662);


