
delete from character_skills where guid=8 and skill=356;

delete from character_spell where guid=8 and spell in (7620, 7731, 43308, 7732, 18248);

