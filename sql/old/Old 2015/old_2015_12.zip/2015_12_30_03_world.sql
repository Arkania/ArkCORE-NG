
delete from spell_script_names where spell_id=34947;
insert into spell_script_names values 
(34947, "spell_warl_pet_scaling_01");

delete from spell_script_names where spell_id=34956;
insert into spell_script_names values 
(34956, "spell_warl_pet_scaling_02");

delete from spell_script_names where spell_id=34957;
insert into spell_script_names values 
(34957, "spell_warl_pet_scaling_03");

delete from spell_script_names where spell_id=34958;
insert into spell_script_names values 
(34958, "spell_warl_pet_scaling_04");

delete from spell_script_names where spell_id=61013;
insert into spell_script_names values 
(61013, "spell_warl_pet_scaling_05");

delete from spell_script_names where spell_id=35695;
insert into spell_script_names values 
(35695, "spell_warl_pet_passive");

delete from spell_script_names where spell_id in (18727, 18728, 18729, 18730, 30147);
insert into spell_script_names values 
(18727, "spell_warl_pet_passive_damage_done"),
(18728, "spell_warl_pet_passive_damage_done"),
(18729, "spell_warl_pet_passive_damage_done"),
(18730, "spell_warl_pet_passive_damage_done"),
(30147, "spell_warl_pet_passive_damage_done");

delete from spell_script_names where spell_id=18735;
insert into spell_script_names values 
(18735, "spell_warl_pet_passive_voidwalker");

delete from spell_script_names where spell_id=6262 and ScriptName="spell_warl_healthstone_heal";
insert into spell_script_names values 
(6262, "spell_warl_healthstone_heal");

delete from spell_script_names where spell_id=61783;
insert into spell_script_names values 
(61783, "spell_sha_pet_scaling_04");

delete from spell_script_names where spell_id=34902;
insert into spell_script_names values 
(34902, "spell_hun_pet_scaling_01");

delete from spell_script_names where spell_id=34903;
insert into spell_script_names values 
(34903, "spell_hun_pet_scaling_02");

delete from spell_script_names where spell_id=34904;
insert into spell_script_names values 
(34904, "spell_hun_pet_scaling_03");

delete from spell_script_names where spell_id=61017;
insert into spell_script_names values 
(61017, "spell_hun_pet_scaling_04");

delete from spell_script_names where spell_id=89446;
insert into spell_script_names values 
(89446, "spell_hun_pet_scaling_05");

delete from spell_script_names where spell_id=19591;
insert into spell_script_names values 
(19591, "spell_hun_pet_passive_crit");

delete from spell_script_names where spell_id=8875;
insert into spell_script_names values 
(8875, "spell_hun_pet_passive_damage_done");


-- spell_warl_soul_burn
