
UPDATE  creature_template  SET  ScriptName = "npc_tentacle_of_the_old_ones" WHERE  entry =57220;
UPDATE  creature_template  SET  ScriptName = "npc_tentacle_of_the_old_ones" WHERE  entry =58077;
UPDATE  creature_template  SET  ScriptName = "npc_tentacle_of_the_old_ones" WHERE  entry =58078;


