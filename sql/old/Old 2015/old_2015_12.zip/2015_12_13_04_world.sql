
delete from spell_script_names where spell_id in (83958, 88304, 44643, 92679);
insert into spell_script_names values
(83958 ,"spell_guild_chest"),
(88304 ,"spell_guild_chest"),
(44643 ,"spell_guild_check_friendly_reputation"),
(92679 ,"spell_guild_flask_of_battle");

