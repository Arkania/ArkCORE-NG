
-- on protest on solomon

DELETE FROM `creature_addon` WHERE (`guid`=33776);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33776, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=33794);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33794, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=33874);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33874, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=33884);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33884, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34042);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34042, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34093);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34093, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34105);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34105, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34184);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34184, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34199);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34199, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34281);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34281, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34360);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34360, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34471);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34471, 0, 0, 65536, 257, 0, '80694, 80815');


