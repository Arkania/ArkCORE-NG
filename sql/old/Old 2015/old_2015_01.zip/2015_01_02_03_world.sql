DELETE FROM `creature_equip_template` WHERE (`entry`=508);

DELETE FROM `creature_equip_template` WHERE (`entry`=512);

DELETE FROM `creature_equip_template` WHERE (`entry`=526);

DELETE FROM `creature_equip_template` WHERE (`entry`=527);

DELETE FROM `creature_equip_template` WHERE (`entry`=528);

DELETE FROM `creature_equip_template` WHERE (`entry`=529);

DELETE FROM `creature_equip_template` WHERE (`entry`=530);

DELETE FROM `creature_equip_template` WHERE (`entry`=532);

DELETE FROM `creature_equip_template` WHERE (`entry`=537);

DELETE FROM `creature_equip_template` WHERE (`entry`=540);

DELETE FROM `creature_equip_template` WHERE (`entry`=546);

DELETE FROM `creature_equip_template` WHERE (`entry`=549);

DELETE FROM `creature_equip_template` WHERE (`entry`=551);

DELETE FROM `creature_equip_template` WHERE (`entry`=552);

DELETE FROM `creature_equip_template` WHERE (`entry`=553);

DELETE FROM `creature_equip_template` WHERE (`entry`=554);

DELETE FROM `creature_equip_template` WHERE (`entry`=555);

DELETE FROM `creature_equip_template` WHERE (`entry`=556);

DELETE FROM `creature_equip_template` WHERE (`entry`=557);

DELETE FROM `creature_equip_template` WHERE (`entry`=558);

DELETE FROM `creature_equip_template` WHERE (`entry`=559);

DELETE FROM `creature_equip_template` WHERE (`entry`=560);

DELETE FROM `creature_equip_template` WHERE (`entry`=561);

DELETE FROM `creature_equip_template` WHERE (`entry`=562);

DELETE FROM `creature_equip_template` WHERE (`entry`=563);

DELETE FROM `creature_equip_template` WHERE (`entry`=571);

DELETE FROM `creature_equip_template` WHERE (`entry`=577);

DELETE FROM `creature_equip_template` WHERE (`entry`=581);

DELETE FROM `creature_equip_template` WHERE (`entry`=585);

DELETE FROM `creature_equip_template` WHERE (`entry`=591);

DELETE FROM `creature_equip_template` WHERE (`entry`=593);

DELETE FROM `creature_equip_template` WHERE (`entry`=600);

DELETE FROM `creature_equip_template` WHERE (`entry`=602);

DELETE FROM `creature_equip_template` WHERE (`entry`=608);

DELETE FROM `creature_equip_template` WHERE (`entry`=617);

DELETE FROM `creature_equip_template` WHERE (`entry`=618);

DELETE FROM `creature_equip_template` WHERE (`entry`=627);

DELETE FROM `creature_equip_template` WHERE (`entry`=629);

DELETE FROM `creature_equip_template` WHERE (`entry`=630);

DELETE FROM `creature_equip_template` WHERE (`entry`=632);

DELETE FROM `creature_equip_template` WHERE (`entry`=635);

DELETE FROM `creature_equip_template` WHERE (`entry`=637);

DELETE FROM `creature_equip_template` WHERE (`entry`=640);

DELETE FROM `creature_equip_template` WHERE (`entry`=654);

DELETE FROM `creature_equip_template` WHERE (`entry`=655);

DELETE FROM `creature_equip_template` WHERE (`entry`=662);

DELETE FROM `creature_equip_template` WHERE (`entry`=665);

DELETE FROM `creature_equip_template` WHERE (`entry`=666);

DELETE FROM `creature_equip_template` WHERE (`entry`=668);

DELETE FROM `creature_equip_template` WHERE (`entry`=673);

DELETE FROM `creature_equip_template` WHERE (`entry`=692);

DELETE FROM `creature_equip_template` WHERE (`entry`=695);

DELETE FROM `creature_equip_template` WHERE (`entry`=719);

DELETE FROM `creature_equip_template` WHERE (`entry`=720);

DELETE FROM `creature_equip_template` WHERE (`entry`=726);

DELETE FROM `creature_equip_template` WHERE (`entry`=748);

DELETE FROM `creature_equip_template` WHERE (`entry`=774);

DELETE FROM `creature_equip_template` WHERE (`entry`=776);

DELETE FROM `creature_equip_template` WHERE (`entry`=778);

DELETE FROM `creature_equip_template` WHERE (`entry`=779);

DELETE FROM `creature_equip_template` WHERE (`entry`=788);

DELETE FROM `creature_equip_template` WHERE (`entry`=792);

DELETE FROM `creature_equip_template` WHERE (`entry`=803);

DELETE FROM `creature_equip_template` WHERE (`entry`=816);

DELETE FROM `creature_equip_template` WHERE (`entry`=817);

DELETE FROM `creature_equip_template` WHERE (`entry`=825);

DELETE FROM `creature_equip_template` WHERE (`entry`=835);

DELETE FROM `creature_equip_template` WHERE (`entry`=838);

DELETE FROM `creature_equip_template` WHERE (`entry`=839);

DELETE FROM `creature_equip_template` WHERE (`entry`=845);

DELETE FROM `creature_equip_template` WHERE (`entry`=872);

DELETE FROM `creature_equip_template` WHERE (`entry`=884);

DELETE FROM `creature_equip_template` WHERE (`entry`=899);

DELETE FROM `creature_equip_template` WHERE (`entry`=901);

DELETE FROM `creature_equip_template` WHERE (`entry`=902);

DELETE FROM `creature_equip_template` WHERE (`entry`=961);

DELETE FROM `creature_equip_template` WHERE (`entry`=962);

DELETE FROM `creature_equip_template` WHERE (`entry`=964);

DELETE FROM `creature_equip_template` WHERE (`entry`=965);

DELETE FROM `creature_equip_template` WHERE (`entry`=966);

DELETE FROM `creature_equip_template` WHERE (`entry`=967);

DELETE FROM `creature_equip_template` WHERE (`entry`=968);

DELETE FROM `creature_equip_template` WHERE (`entry`=969);

DELETE FROM `creature_equip_template` WHERE (`entry`=970);

DELETE FROM `creature_equip_template` WHERE (`entry`=971);

DELETE FROM `creature_equip_template` WHERE (`entry`=972);

DELETE FROM `creature_equip_template` WHERE (`entry`=973);

DELETE FROM `creature_equip_template` WHERE (`entry`=974);

DELETE FROM `creature_equip_template` WHERE (`entry`=975);

DELETE FROM `creature_equip_template` WHERE (`entry`=990);

DELETE FROM `creature_equip_template` WHERE (`entry`=991);

DELETE FROM `creature_equip_template` WHERE (`entry`=992);

DELETE FROM `creature_equip_template` WHERE (`entry`=997);

DELETE FROM `creature_equip_template` WHERE (`entry`=998);

DELETE FROM `creature_equip_template` WHERE (`entry`=1002);

DELETE FROM `creature_equip_template` WHERE (`entry`=1003);

DELETE FROM `creature_equip_template` WHERE (`entry`=1004);

DELETE FROM `creature_equip_template` WHERE (`entry`=1005);

DELETE FROM `creature_equip_template` WHERE (`entry`=1006);

DELETE FROM `creature_equip_template` WHERE (`entry`=1079);

DELETE FROM `creature_equip_template` WHERE (`entry`=1080);

DELETE FROM `creature_equip_template` WHERE (`entry`=1086);

DELETE FROM `creature_equip_template` WHERE (`entry`=1102);

DELETE FROM `creature_equip_template` WHERE (`entry`=1107);

DELETE FROM `creature_equip_template` WHERE (`entry`=1113);

DELETE FROM `creature_equip_template` WHERE (`entry`=1136);

DELETE FROM `creature_equip_template` WHERE (`entry`=1143);

DELETE FROM `creature_equip_template` WHERE (`entry`=1145);

DELETE FROM `creature_equip_template` WHERE (`entry`=1168);

DELETE FROM `creature_equip_template` WHERE (`entry`=1170);

DELETE FROM `creature_equip_template` WHERE (`entry`=1208);

DELETE FROM `creature_equip_template` WHERE (`entry`=1209);

DELETE FROM `creature_equip_template` WHERE (`entry`=1219);

DELETE FROM `creature_equip_template` WHERE (`entry`=1220);

DELETE FROM `creature_equip_template` WHERE (`entry`=1221);

DELETE FROM `creature_equip_template` WHERE (`entry`=1223);

DELETE FROM `creature_equip_template` WHERE (`entry`=1248);

DELETE FROM `creature_equip_template` WHERE (`entry`=1264);

DELETE FROM `creature_equip_template` WHERE (`entry`=1272);

DELETE FROM `creature_equip_template` WHERE (`entry`=1357);

DELETE FROM `creature_equip_template` WHERE (`entry`=1359);

DELETE FROM `creature_equip_template` WHERE (`entry`=1363);

DELETE FROM `creature_equip_template` WHERE (`entry`=1369);

DELETE FROM `creature_equip_template` WHERE (`entry`=1372);

DELETE FROM `creature_equip_template` WHERE (`entry`=1389);

DELETE FROM `creature_equip_template` WHERE (`entry`=1390);

DELETE FROM `creature_equip_template` WHERE (`entry`=1391);

DELETE FROM `creature_equip_template` WHERE (`entry`=1394);

DELETE FROM `creature_equip_template` WHERE (`entry`=1396);

DELETE FROM `creature_equip_template` WHERE (`entry`=1438);

DELETE FROM `creature_equip_template` WHERE (`entry`=1486);

DELETE FROM `creature_equip_template` WHERE (`entry`=1510);

DELETE FROM `creature_equip_template` WHERE (`entry`=1517);

DELETE FROM `creature_equip_template` WHERE (`entry`=1524);

DELETE FROM `creature_equip_template` WHERE (`entry`=1542);

DELETE FROM `creature_equip_template` WHERE (`entry`=1556);

DELETE FROM `creature_equip_template` WHERE (`entry`=1566);

DELETE FROM `creature_equip_template` WHERE (`entry`=1610);

DELETE FROM `creature_equip_template` WHERE (`entry`=1611);

DELETE FROM `creature_equip_template` WHERE (`entry`=1612);

DELETE FROM `creature_equip_template` WHERE (`entry`=1630);

DELETE FROM `creature_equip_template` WHERE (`entry`=1647);

DELETE FROM `creature_equip_template` WHERE (`entry`=1648);

DELETE FROM `creature_equip_template` WHERE (`entry`=1704);

DELETE FROM `creature_equip_template` WHERE (`entry`=1705);

DELETE FROM `creature_equip_template` WHERE (`entry`=1709);

DELETE FROM `creature_equip_template` WHERE (`entry`=1710);

DELETE FROM `creature_equip_template` WHERE (`entry`=1712);

DELETE FROM `creature_equip_template` WHERE (`entry`=1728);

DELETE FROM `creature_equip_template` WHERE (`entry`=1734);

DELETE FROM `creature_equip_template` WHERE (`entry`=1771);

DELETE FROM `creature_equip_template` WHERE (`entry`=1774);

DELETE FROM `creature_equip_template` WHERE (`entry`=1803);

DELETE FROM `creature_equip_template` WHERE (`entry`=1818);

DELETE FROM `creature_equip_template` WHERE (`entry`=1828);

DELETE FROM `creature_equip_template` WHERE (`entry`=1829);

DELETE FROM `creature_equip_template` WHERE (`entry`=1830);

DELETE FROM `creature_equip_template` WHERE (`entry`=1856);

DELETE FROM `creature_equip_template` WHERE (`entry`=1886);

DELETE FROM `creature_equip_template` WHERE (`entry`=1887);

DELETE FROM `creature_equip_template` WHERE (`entry`=2016);

DELETE FROM `creature_equip_template` WHERE (`entry`=2023);

DELETE FROM `creature_equip_template` WHERE (`entry`=2024);

DELETE FROM `creature_equip_template` WHERE (`entry`=2026);

DELETE FROM `creature_equip_template` WHERE (`entry`=2028);

DELETE FROM `creature_equip_template` WHERE (`entry`=2035);

DELETE FROM `creature_equip_template` WHERE (`entry`=2036);

DELETE FROM `creature_equip_template` WHERE (`entry`=2037);

DELETE FROM `creature_equip_template` WHERE (`entry`=2047);

DELETE FROM `creature_equip_template` WHERE (`entry`=2048);

DELETE FROM `creature_equip_template` WHERE (`entry`=2049);

DELETE FROM `creature_equip_template` WHERE (`entry`=2059);

DELETE FROM `creature_equip_template` WHERE (`entry`=2072);

DELETE FROM `creature_equip_template` WHERE (`entry`=2073);

DELETE FROM `creature_equip_template` WHERE (`entry`=2074);

DELETE FROM `creature_equip_template` WHERE (`entry`=2075);

DELETE FROM `creature_equip_template` WHERE (`entry`=2076);

DELETE FROM `creature_equip_template` WHERE (`entry`=2085);

DELETE FROM `creature_equip_template` WHERE (`entry`=2088);

DELETE FROM `creature_equip_template` WHERE (`entry`=2100);

DELETE FROM `creature_equip_template` WHERE (`entry`=2101);

DELETE FROM `creature_equip_template` WHERE (`entry`=2125);

DELETE FROM `creature_equip_template` WHERE (`entry`=2139);

DELETE FROM `creature_equip_template` WHERE (`entry`=2141);

DELETE FROM `creature_equip_template` WHERE (`entry`=2143);

DELETE FROM `creature_equip_template` WHERE (`entry`=2144);

DELETE FROM `creature_equip_template` WHERE (`entry`=2145);

DELETE FROM `creature_equip_template` WHERE (`entry`=2146);

DELETE FROM `creature_equip_template` WHERE (`entry`=2147);

DELETE FROM `creature_equip_template` WHERE (`entry`=2148);

DELETE FROM `creature_equip_template` WHERE (`entry`=2161);

DELETE FROM `creature_equip_template` WHERE (`entry`=2193);

DELETE FROM `creature_equip_template` WHERE (`entry`=2194);

DELETE FROM `creature_equip_template` WHERE (`entry`=2195);

DELETE FROM `creature_equip_template` WHERE (`entry`=2196);

DELETE FROM `creature_equip_template` WHERE (`entry`=2259);

DELETE FROM `creature_equip_template` WHERE (`entry`=2262);

DELETE FROM `creature_equip_template` WHERE (`entry`=2273);

DELETE FROM `creature_equip_template` WHERE (`entry`=2328);

DELETE FROM `creature_equip_template` WHERE (`entry`=2340);

DELETE FROM `creature_equip_template` WHERE (`entry`=2341);

DELETE FROM `creature_equip_template` WHERE (`entry`=2342);

DELETE FROM `creature_equip_template` WHERE (`entry`=2343);

DELETE FROM `creature_equip_template` WHERE (`entry`=2353);

DELETE FROM `creature_equip_template` WHERE (`entry`=6969);

DELETE FROM `creature_equip_template` WHERE (`entry`=10001);

DELETE FROM `creature_equip_template` WHERE (`entry`=10002);

DELETE FROM `creature_equip_template` WHERE (`entry`=10003);

DELETE FROM `creature_equip_template` WHERE (`entry`=10005);

DELETE FROM `creature_equip_template` WHERE (`entry`=10006);

DELETE FROM `creature_equip_template` WHERE (`entry`=10008);

DELETE FROM `creature_equip_template` WHERE (`entry`=10009);

DELETE FROM `creature_equip_template` WHERE (`entry`=10010);

DELETE FROM `creature_equip_template` WHERE (`entry`=10011);

DELETE FROM `creature_equip_template` WHERE (`entry`=10012);

DELETE FROM `creature_equip_template` WHERE (`entry`=10013);

DELETE FROM `creature_equip_template` WHERE (`entry`=10014);

DELETE FROM `creature_equip_template` WHERE (`entry`=10015);

DELETE FROM `creature_equip_template` WHERE (`entry`=10018);

DELETE FROM `creature_equip_template` WHERE (`entry`=10019);

DELETE FROM `creature_equip_template` WHERE (`entry`=10020);

DELETE FROM `creature_equip_template` WHERE (`entry`=10021);

DELETE FROM `creature_equip_template` WHERE (`entry`=10022);

DELETE FROM `creature_equip_template` WHERE (`entry`=10023);

DELETE FROM `creature_equip_template` WHERE (`entry`=10024);

DELETE FROM `creature_equip_template` WHERE (`entry`=10025);

DELETE FROM `creature_equip_template` WHERE (`entry`=10026);

DELETE FROM `creature_equip_template` WHERE (`entry`=10027);

DELETE FROM `creature_equip_template` WHERE (`entry`=10028);

DELETE FROM `creature_equip_template` WHERE (`entry`=10029);

DELETE FROM `creature_equip_template` WHERE (`entry`=10030);

DELETE FROM `creature_equip_template` WHERE (`entry`=10031);

DELETE FROM `creature_equip_template` WHERE (`entry`=10032);

DELETE FROM `creature_equip_template` WHERE (`entry`=10033);

DELETE FROM `creature_equip_template` WHERE (`entry`=10034);

DELETE FROM `creature_equip_template` WHERE (`entry`=10035);

DELETE FROM `creature_equip_template` WHERE (`entry`=10039);

DELETE FROM `creature_equip_template` WHERE (`entry`=10064);

DELETE FROM `creature_equip_template` WHERE (`entry`=10065);

DELETE FROM `creature_equip_template` WHERE (`entry`=10066);

DELETE FROM `creature_equip_template` WHERE (`entry`=10067);

DELETE FROM `creature_equip_template` WHERE (`entry`=10068);

DELETE FROM `creature_equip_template` WHERE (`entry`=10069);

DELETE FROM `creature_equip_template` WHERE (`entry`=10070);

DELETE FROM `creature_equip_template` WHERE (`entry`=10071);

DELETE FROM `creature_equip_template` WHERE (`entry`=10072);

DELETE FROM `creature_equip_template` WHERE (`entry`=10073);

DELETE FROM `creature_equip_template` WHERE (`entry`=10074);

DELETE FROM `creature_equip_template` WHERE (`entry`=10075);

DELETE FROM `creature_equip_template` WHERE (`entry`=10087);

DELETE FROM `creature_equip_template` WHERE (`entry`=10091);

DELETE FROM `creature_equip_template` WHERE (`entry`=10092);

DELETE FROM `creature_equip_template` WHERE (`entry`=10093);

DELETE FROM `creature_equip_template` WHERE (`entry`=10094);

DELETE FROM `creature_equip_template` WHERE (`entry`=10095);

DELETE FROM `creature_equip_template` WHERE (`entry`=10097);

DELETE FROM `creature_equip_template` WHERE (`entry`=10098);

DELETE FROM `creature_equip_template` WHERE (`entry`=10099);

DELETE FROM `creature_equip_template` WHERE (`entry`=10100);

DELETE FROM `creature_equip_template` WHERE (`entry`=10101);

DELETE FROM `creature_equip_template` WHERE (`entry`=10102);

DELETE FROM `creature_equip_template` WHERE (`entry`=10103);

DELETE FROM `creature_equip_template` WHERE (`entry`=10104);

DELETE FROM `creature_equip_template` WHERE (`entry`=10105);

DELETE FROM `creature_equip_template` WHERE (`entry`=10106);

DELETE FROM `creature_equip_template` WHERE (`entry`=10107);

DELETE FROM `creature_equip_template` WHERE (`entry`=10108);

DELETE FROM `creature_equip_template` WHERE (`entry`=10109);

DELETE FROM `creature_equip_template` WHERE (`entry`=10110);

DELETE FROM `creature_equip_template` WHERE (`entry`=10111);

DELETE FROM `creature_equip_template` WHERE (`entry`=10112);

DELETE FROM `creature_equip_template` WHERE (`entry`=10113);

DELETE FROM `creature_equip_template` WHERE (`entry`=10114);

DELETE FROM `creature_equip_template` WHERE (`entry`=10115);

DELETE FROM `creature_equip_template` WHERE (`entry`=10121);

DELETE FROM `creature_equip_template` WHERE (`entry`=10122);

DELETE FROM `creature_equip_template` WHERE (`entry`=10123);

DELETE FROM `creature_equip_template` WHERE (`entry`=10124);

DELETE FROM `creature_equip_template` WHERE (`entry`=10125);

DELETE FROM `creature_equip_template` WHERE (`entry`=10126);

DELETE FROM `creature_equip_template` WHERE (`entry`=10127);

DELETE FROM `creature_equip_template` WHERE (`entry`=10128);

DELETE FROM `creature_equip_template` WHERE (`entry`=10129);

DELETE FROM `creature_equip_template` WHERE (`entry`=10130);

DELETE FROM `creature_equip_template` WHERE (`entry`=10131);

DELETE FROM `creature_equip_template` WHERE (`entry`=10132);

DELETE FROM `creature_equip_template` WHERE (`entry`=10133);

DELETE FROM `creature_equip_template` WHERE (`entry`=10134);

DELETE FROM `creature_equip_template` WHERE (`entry`=10135);

DELETE FROM `creature_equip_template` WHERE (`entry`=52652);

DELETE FROM `creature_equip_template` WHERE (`entry`=52653);

DELETE FROM `creature_equip_template` WHERE (`entry`=52656);

DELETE FROM `creature_equip_template` WHERE (`entry`=52666);

DELETE FROM `creature_equip_template` WHERE (`entry`=99972);

DELETE FROM `creature_equip_template` WHERE (`entry`=99973);

DELETE FROM `creature_equip_template` WHERE (`entry`=99974);

DELETE FROM `creature_equip_template` WHERE (`entry`=99975);

DELETE FROM `creature_equip_template` WHERE (`entry`=99976);

DELETE FROM `creature_equip_template` WHERE (`entry`=99977);

DELETE FROM `creature_equip_template` WHERE (`entry`=99978);

DELETE FROM `creature_equip_template` WHERE (`entry`=99979);

DELETE FROM `creature_equip_template` WHERE (`entry`=99980);

DELETE FROM `creature_equip_template` WHERE (`entry`=99981);
