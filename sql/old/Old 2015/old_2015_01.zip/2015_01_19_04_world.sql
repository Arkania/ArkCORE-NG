
-- http://www.wowhead.com/npc=43249/dumpy					 
update creature_addon set auras="80694" where guid=34187;
update creature_template set AIName="", ScriptName="npc_dumpy_43249" where entry=43249;

-- http://www.wowhead.com/npc=43248/big-earl
update creature_addon set auras="80694" where guid=33881;
update creature_template set AIName="", ScriptName="npc_big_earl_43248" where entry=43248;

