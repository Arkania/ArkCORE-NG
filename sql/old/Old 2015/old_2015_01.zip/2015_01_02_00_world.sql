

-- many error on console are equipment for non existing creature..
-- we delete all such entrys

-- 02.01.2015 06:54:15
DELETE FROM `creature_equip_template` WHERE (`entry`=4);

-- 02.01.2015 06:54:31
DELETE FROM `creature_equip_template` WHERE (`entry`=5);

-- 02.01.2015 06:54:41
DELETE FROM `creature_equip_template` WHERE (`entry`=7);

-- 02.01.2015 06:54:47
DELETE FROM `creature_equip_template` WHERE (`entry`=8);

-- 02.01.2015 06:54:57
DELETE FROM `creature_equip_template` WHERE (`entry`=9);

-- 02.01.2015 06:55:09
DELETE FROM `creature_equip_template` WHERE (`entry`=10);

-- 02.01.2015 06:56:20
DELETE FROM `creature_equip_template` WHERE (`entry`=11);

-- 02.01.2015 06:56:30
DELETE FROM `creature_equip_template` WHERE (`entry`=12);

-- 02.01.2015 06:56:38
DELETE FROM `creature_equip_template` WHERE (`entry`=13);

-- 02.01.2015 06:56:47
DELETE FROM `creature_equip_template` WHERE (`entry`=14);

-- 02.01.2015 06:56:56
DELETE FROM `creature_equip_template` WHERE (`entry`=15);

-- 02.01.2015 06:57:04
DELETE FROM `creature_equip_template` WHERE (`entry`=16);

-- 02.01.2015 06:57:12
DELETE FROM `creature_equip_template` WHERE (`entry`=17);

-- 02.01.2015 06:57:20
DELETE FROM `creature_equip_template` WHERE (`entry`=18);

-- 02.01.2015 06:57:28
DELETE FROM `creature_equip_template` WHERE (`entry`=20);

-- 02.01.2015 06:57:36
DELETE FROM `creature_equip_template` WHERE (`entry`=21);

-- 02.01.2015 06:57:45
DELETE FROM `creature_equip_template` WHERE (`entry`=22);

-- 02.01.2015 06:57:51
DELETE FROM `creature_equip_template` WHERE (`entry`=23);

-- 02.01.2015 06:57:58
DELETE FROM `creature_equip_template` WHERE (`entry`=24);

-- 02.01.2015 06:58:08
DELETE FROM `creature_equip_template` WHERE (`entry`=26);

-- 02.01.2015 06:58:16
DELETE FROM `creature_equip_template` WHERE (`entry`=27);

-- 02.01.2015 06:58:23
DELETE FROM `creature_equip_template` WHERE (`entry`=28);

-- 02.01.2015 06:58:32
DELETE FROM `creature_equip_template` WHERE (`entry`=32);

-- 02.01.2015 06:58:40
DELETE FROM `creature_equip_template` WHERE (`entry`=33);

-- 02.01.2015 06:58:49
DELETE FROM `creature_equip_template` WHERE (`entry`=34);

-- 02.01.2015 06:59:01
DELETE FROM `creature_equip_template` WHERE (`entry`=35);

-- 02.01.2015 06:59:12
DELETE FROM `creature_equip_template` WHERE (`entry`=37);

-- 02.01.2015 06:59:21
DELETE FROM `creature_equip_template` WHERE (`entry`=39);

-- 02.01.2015 06:59:32
DELETE FROM `creature_equip_template` WHERE (`entry`=41);

-- 02.01.2015 06:59:41
DELETE FROM `creature_equip_template` WHERE (`entry`=42);

-- 02.01.2015 06:59:50
DELETE FROM `creature_equip_template` WHERE (`entry`=44);

-- 02.01.2015 06:59:58
DELETE FROM `creature_equip_template` WHERE (`entry`=45);

-- 02.01.2015 07:00:09
DELETE FROM `creature_equip_template` WHERE (`entry`=47);

-- 02.01.2015 07:00:15
DELETE FROM `creature_equip_template` WHERE (`entry`=50);

-- 02.01.2015 07:00:36
DELETE FROM `creature_equip_template` WHERE (`entry`=51);

-- 02.01.2015 07:00:44
DELETE FROM `creature_equip_template` WHERE (`entry`=52);

-- 02.01.2015 07:00:52
DELETE FROM `creature_equip_template` WHERE (`entry`=53);

-- 02.01.2015 07:01:00
DELETE FROM `creature_equip_template` WHERE (`entry`=56);

-- 02.01.2015 07:01:08
DELETE FROM `creature_equip_template` WHERE (`entry`=57);

-- 02.01.2015 07:01:16
DELETE FROM `creature_equip_template` WHERE (`entry`=58);

-- 02.01.2015 07:01:24
DELETE FROM `creature_equip_template` WHERE (`entry`=59);

-- 02.01.2015 07:01:40
DELETE FROM `creature_equip_template` WHERE (`entry`=63);

-- 02.01.2015 07:01:51
DELETE FROM `creature_equip_template` WHERE (`entry`=64);

-- 02.01.2015 07:02:03
DELETE FROM `creature_equip_template` WHERE (`entry`=76);

-- 02.01.2015 07:02:11
DELETE FROM `creature_equip_template` WHERE (`entry`=77);

-- 02.01.2015 07:02:20
DELETE FROM `creature_equip_template` WHERE (`entry`=83);

-- 02.01.2015 07:02:27
DELETE FROM `creature_equip_template` WHERE (`entry`=84);

-- 02.01.2015 07:02:33
DELETE FROM `creature_equip_template` WHERE (`entry`=85);

-- 02.01.2015 07:02:58
DELETE FROM `creature_equip_template` WHERE (`entry`=86);

-- 02.01.2015 07:03:07
DELETE FROM `creature_equip_template` WHERE (`entry`=88);

-- 02.01.2015 07:03:17
DELETE FROM `creature_equip_template` WHERE (`entry`=91);

-- 02.01.2015 07:03:26
DELETE FROM `creature_equip_template` WHERE (`entry`=96);

-- 02.01.2015 07:03:39
DELETE FROM `creature_equip_template` WHERE (`entry`=101);

-- 02.01.2015 07:03:49
DELETE FROM `creature_equip_template` WHERE (`entry`=104);

-- 02.01.2015 07:03:59
DELETE FROM `creature_equip_template` WHERE (`entry`=110);

-- 02.01.2015 07:04:10
DELETE FROM `creature_equip_template` WHERE (`entry`=131);

-- 02.01.2015 07:04:17
DELETE FROM `creature_equip_template` WHERE (`entry`=132);

-- 02.01.2015 07:04:24
DELETE FROM `creature_equip_template` WHERE (`entry`=133);

-- 02.01.2015 07:04:32
DELETE FROM `creature_equip_template` WHERE (`entry`=134);

-- 02.01.2015 07:04:40
DELETE FROM `creature_equip_template` WHERE (`entry`=135);

-- 02.01.2015 07:04:49
DELETE FROM `creature_equip_template` WHERE (`entry`=136);

-- 02.01.2015 07:04:55
DELETE FROM `creature_equip_template` WHERE (`entry`=137);

-- 02.01.2015 07:05:07
DELETE FROM `creature_equip_template` WHERE (`entry`=140);

-- 02.01.2015 07:05:36
DELETE FROM `creature_equip_template` WHERE (`entry`=141);

-- 02.01.2015 07:05:47
DELETE FROM `creature_equip_template` WHERE (`entry`=142);

-- 02.01.2015 07:05:55
DELETE FROM `creature_equip_template` WHERE (`entry`=143);

-- 02.01.2015 07:06:11
DELETE FROM `creature_equip_template` WHERE (`entry`=144);

-- 02.01.2015 07:06:21
DELETE FROM `creature_equip_template` WHERE (`entry`=145);

-- 02.01.2015 07:06:30
DELETE FROM `creature_equip_template` WHERE (`entry`=146);

-- 02.01.2015 07:06:37
DELETE FROM `creature_equip_template` WHERE (`entry`=147);

-- 02.01.2015 07:06:46
DELETE FROM `creature_equip_template` WHERE (`entry`=148);

-- 02.01.2015 07:06:58
DELETE FROM `creature_equip_template` WHERE (`entry`=155);

-- 02.01.2015 07:07:09
DELETE FROM `creature_equip_template` WHERE (`entry`=156);

-- 02.01.2015 07:07:20
DELETE FROM `creature_equip_template` WHERE (`entry`=158);

-- 02.01.2015 07:07:28
DELETE FROM `creature_equip_template` WHERE (`entry`=159);

-- 02.01.2015 07:07:37
DELETE FROM `creature_equip_template` WHERE (`entry`=160);

DELETE FROM `creature_equip_template` WHERE (`entry`=139);

DELETE FROM `creature_equip_template` WHERE (`entry`=162);

DELETE FROM `creature_equip_template` WHERE (`entry`=164);

DELETE FROM `creature_equip_template` WHERE (`entry`=166);

DELETE FROM `creature_equip_template` WHERE (`entry`=168);

DELETE FROM `creature_equip_template` WHERE (`entry`=169);

DELETE FROM `creature_equip_template` WHERE (`entry`=170);

DELETE FROM `creature_equip_template` WHERE (`entry`=172);

DELETE FROM `creature_equip_template` WHERE (`entry`=173);

DELETE FROM `creature_equip_template` WHERE (`entry`=174);

DELETE FROM `creature_equip_template` WHERE (`entry`=175);

DELETE FROM `creature_equip_template` WHERE (`entry`=176);

DELETE FROM `creature_equip_template` WHERE (`entry`=177);

DELETE FROM `creature_equip_template` WHERE (`entry`=178);

DELETE FROM `creature_equip_template` WHERE (`entry`=179);

DELETE FROM `creature_equip_template` WHERE (`entry`=180);

DELETE FROM `creature_equip_template` WHERE (`entry`=181);

DELETE FROM `creature_equip_template` WHERE (`entry`=182);

DELETE FROM `creature_equip_template` WHERE (`entry`=183);

DELETE FROM `creature_equip_template` WHERE (`entry`=184);

DELETE FROM `creature_equip_template` WHERE (`entry`=185);

DELETE FROM `creature_equip_template` WHERE (`entry`=186);

DELETE FROM `creature_equip_template` WHERE (`entry`=187);

DELETE FROM `creature_equip_template` WHERE (`entry`=188);

DELETE FROM `creature_equip_template` WHERE (`entry`=189);

DELETE FROM `creature_equip_template` WHERE (`entry`=191);

DELETE FROM `creature_equip_template` WHERE (`entry`=194);

DELETE FROM `creature_equip_template` WHERE (`entry`=195);

DELETE FROM `creature_equip_template` WHERE (`entry`=214);

DELETE FROM `creature_equip_template` WHERE (`entry`=216);

DELETE FROM `creature_equip_template` WHERE (`entry`=231);

DELETE FROM `creature_equip_template` WHERE (`entry`=236);

DELETE FROM `creature_equip_template` WHERE (`entry`=245);

DELETE FROM `creature_equip_template` WHERE (`entry`=249);

DELETE FROM `creature_equip_template` WHERE (`entry`=254);

DELETE FROM `creature_equip_template` WHERE (`entry`=256);

DELETE FROM `creature_equip_template` WHERE (`entry`=259);

DELETE FROM `creature_equip_template` WHERE (`entry`=292);

DELETE FROM `creature_equip_template` WHERE (`entry`=293);

DELETE FROM `creature_equip_template` WHERE (`entry`=310);

DELETE FROM `creature_equip_template` WHERE (`entry`=312);

DELETE FROM `creature_equip_template` WHERE (`entry`=316);

DELETE FROM `creature_equip_template` WHERE (`entry`=317);

DELETE FROM `creature_equip_template` WHERE (`entry`=337);

DELETE FROM `creature_equip_template` WHERE (`entry`=350);

DELETE FROM `creature_equip_template` WHERE (`entry`=355);

DELETE FROM `creature_equip_template` WHERE (`entry`=357);

DELETE FROM `creature_equip_template` WHERE (`entry`=360);

DELETE FROM `creature_equip_template` WHERE (`entry`=362);

DELETE FROM `creature_equip_template` WHERE (`entry`=363);

DELETE FROM `creature_equip_template` WHERE (`entry`=366);

DELETE FROM `creature_equip_template` WHERE (`entry`=367);

DELETE FROM `creature_equip_template` WHERE (`entry`=368);

DELETE FROM `creature_equip_template` WHERE (`entry`=369);

DELETE FROM `creature_equip_template` WHERE (`entry`=378);

DELETE FROM `creature_equip_template` WHERE (`entry`=394);

DELETE FROM `creature_equip_template` WHERE (`entry`=396);

DELETE FROM `creature_equip_template` WHERE (`entry`=398);

DELETE FROM `creature_equip_template` WHERE (`entry`=413);

DELETE FROM `creature_equip_template` WHERE (`entry`=414);

DELETE FROM `creature_equip_template` WHERE (`entry`=419);

DELETE FROM `creature_equip_template` WHERE (`entry`=420);

DELETE FROM `creature_equip_template` WHERE (`entry`=425);

DELETE FROM `creature_equip_template` WHERE (`entry`=427);

DELETE FROM `creature_equip_template` WHERE (`entry`=438);

DELETE FROM `creature_equip_template` WHERE (`entry`=439);

DELETE FROM `creature_equip_template` WHERE (`entry`=443);

DELETE FROM `creature_equip_template` WHERE (`entry`=447);

DELETE FROM `creature_equip_template` WHERE (`entry`=451);

DELETE FROM `creature_equip_template` WHERE (`entry`=455);

DELETE FROM `creature_equip_template` WHERE (`entry`=457);

DELETE FROM `creature_equip_template` WHERE (`entry`=463);

DELETE FROM `creature_equip_template` WHERE (`entry`=477);

DELETE FROM `creature_equip_template` WHERE (`entry`=479);

DELETE FROM `creature_equip_template` WHERE (`entry`=484);

DELETE FROM `creature_equip_template` WHERE (`entry`=492);

DELETE FROM `creature_equip_template` WHERE (`entry`=493);