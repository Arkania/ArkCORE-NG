
-- on fight with big earl

DELETE FROM `creature_addon` WHERE (`guid`=33762);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33762, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=33880);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33880, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=33911);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33911, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=33912);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33912, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=33945);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33945, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=33957);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(33957, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34030);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34030, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34084);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34084, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34100);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34100, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34218);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34218, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34239);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34239, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34255);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34255, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34303);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34303, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34381);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34381, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34382);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34382, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34520);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34520, 0, 0, 65536, 257, 0, '80694, 80815');

DELETE FROM `creature_addon` WHERE (`guid`=34521);
INSERT INTO `creature_addon` (`guid`, `path_id`, `mount`, `bytes1`, `bytes2`, `emote`, `auras`) VALUES 
(34521, 0, 0, 65536, 257, 0, '80694, 80815');









