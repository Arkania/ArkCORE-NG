

delete from smart_scripts where entryorguid in (-229482, -228358, -228357, -228356, -228355, -228353, -228352, -226832, -226831, -226830, -226829);
delete from smart_scripts where entryorguid in (-226828, -226827, -226826, -224129, -223985, -223984, -222402, -222401, -217775, -217776, -217777);
delete from smart_scripts where entryorguid in (-217778, -217779, -217780, -217781, -217782, -216253, -216251, -216250, -212242, -212234, -211596);
delete from smart_scripts where entryorguid in (-211527, -207620, -203896, -203801, -203627, -172448, -172447, -172441, -172440, -172425, -172423);
delete from smart_scripts where entryorguid in (-172421, -172417, -172415, -172414, -172389, -168415, -168414, -168413, -168412, -168411, -165699);
delete from smart_scripts where entryorguid in (-164223, -164222, -164066, -162515, -161833, -154912, -136223, -136222, -127471, -125002, -125000);
delete from smart_scripts where entryorguid in (-124996, -124995, -124987, -124977, -124975, -124974, -124971, -124970, -124969, -124968, -124967);
delete from smart_scripts where entryorguid in (-122418, -122417, -122416, -122415, -122414, -122413, -122412, -122411, -122410, -122409, -122408);
delete from smart_scripts where entryorguid in (-122407, -122406, -122405, -122404, -121628, -115976, -115974, -115965, -115959, -115948, -115947);
delete from smart_scripts where entryorguid in (-115946, -115945, -115927, -115926, -115925, -115923, -115922, -115920, -114831, -114829, -114115);
delete from smart_scripts where entryorguid in (-114112, -114111, -114110, -114101, -113878, -113876, -113874, -113483, -113482, -113481, -106918);
delete from smart_scripts where entryorguid in (-106917, -106915, -106914, -106913, -106912, -106911, -106910, -106909, -106908, -106901, -106900);
delete from smart_scripts where entryorguid in (-106898, -105997, -104535, -104534, -104070, -104069, -104068, -104065, -100094, -100089, -95068);
delete from smart_scripts where entryorguid in (-95055, -79183, -43289, -42283, -23716, -23715, -23714, -23712, -13623, -13615, -6983);

delete from smart_scripts where entryorguid in (124, 234, 295, 330, 390, 397, 440, 449, 452, 485, 501, 523, 589, 594, 639, 918, 1247, 1423, 1464, 1735);
delete from smart_scripts where entryorguid in (1737, 1738, 1742, 1743, 1745, 1746, 2209, 2210, 2352, 2388, 3212, 3216, 3217, 3219, 3220, 3221, 3222);
delete from smart_scripts where entryorguid in (3223, 3328, 3502, 3887, 3934, 4163, 4278, 4583, 4625, 4825, 4829, 4832, 4857, 4961, 4978, 5111, 5165);
delete from smart_scripts where entryorguid in (5167, 5688, 5725, 5814, 5953, 6243, 6272, 6373, 6374, 6497, 6727, 6734, 6735, 6736, 6738, 6739, 6740);
delete from smart_scripts where entryorguid in (6741, 6746, 6747, 6782, 6790, 6791, 6807, 6928, 6929, 6930, 7024, 7172, 7271, 7572, 7714, 7731, 7736);
delete from smart_scripts where entryorguid in (7744, 7955, 8436, 8479, 8879, 8931, 9356, 9460, 10268, 10307, 10316, 10363, 10435, 10436, 10437, 10438);
delete from smart_scripts where entryorguid in (10439, 10584, 10808, 10812, 10918, 11103, 11116, 11118, 11190, 11673, 12196, 12776, 13076, 13283);
delete from smart_scripts where entryorguid in (14347, 14387, 14890, 15174, 15184, 15260, 15302, 15397, 15420, 15433, 15760, 16042, 16206, 16208, 16209);
delete from smart_scripts where entryorguid in (16256, 16286, 16458, 16539, 16542, 16553, 16618, 16684, 16819 );

update creature_template set AIName="SmartAI" where entry in (27558,197, 253, 327, 643, 1493, 1497, 2003, 2391, 2921, 2981, 2991, 3144, 3301, 3584);
update creature_template set AIName="SmartAI" where entry in (3616, 3627, 3692, 3693, 3695, 3870, 4279, 4980, 4983, 5044, 5045, 5046, 5917, 6066, 6172);
update creature_template set AIName="SmartAI" where entry in (6177, 6266, 7802, 7804, 8284, 9117, 9546, 9935, 10578, 10583, 14354, 14368, 14390, 14875);
update creature_template set AIName="SmartAI" where entry in (14884, 15466, 15481, 16227, 16518, 16550 );


































