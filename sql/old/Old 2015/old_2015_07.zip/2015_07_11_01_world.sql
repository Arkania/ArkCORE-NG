
update creature_text set BroadcastTextID=14999 where entry=18209 and groupid=0 and id=0;
update creature_text set BroadcastTextID=15001 where entry=18209 and groupid=2 and id=0;

update creature_text set BroadcastTextID=14999 where entry=18210 and groupid=0 and id=0;
update creature_text set BroadcastTextID=15009 where entry=18210 and groupid=3 and id=0;
update creature_text set BroadcastTextID=15001 where entry=18210 and groupid=4 and id=0;

update creature_text set BroadcastTextID=34125 where entry=32913 and groupid=1 and id=1;

update creature_text set BroadcastTextID=33145 where entry=32865 and groupid=0 and id=0;
update creature_text set BroadcastTextID=33270 where entry=32865 and groupid=0 and id=1;
update creature_text set BroadcastTextID=34239 where entry=32865 and groupid=5 and id=0;
update creature_text set BroadcastTextID=34240 where entry=32865 and groupid=5 and id=1;
update creature_text set BroadcastTextID=33274 where entry=32865 and groupid=7 and id=0;

update creature_text set BroadcastTextID=13102 where entry=16063 and groupid=1 and id=1;
update creature_text set BroadcastTextID=13100 where entry=16063 and groupid=2 and id=0;
update creature_text set BroadcastTextID=13099 where entry=16063 and groupid=3 and id=0;

update creature_text set BroadcastTextID=31801 where entry=27654 and groupid=1 and id=0;
update creature_text set BroadcastTextID=31802 where entry=27654 and groupid=1 and id=1;
update creature_text set BroadcastTextID=31795 where entry=27654 and groupid=4 and id=1;

update creature_text set BroadcastTextID=17860 where entry=18731 and groupid=1 and id=0;
update creature_text set BroadcastTextID=17861 where entry=18731 and groupid=1 and id=1;
update creature_text set BroadcastTextID=17863 where entry=18731 and groupid=1 and id=2;
update creature_text set BroadcastTextID=17865 where entry=18731 and groupid=3 and id=1;
update creature_text set BroadcastTextID=17866 where entry=18731 and groupid=4 and id=0;

update creature_text set BroadcastTextID=21738 where entry=22949 and groupid=2 and id=0;
update creature_text set BroadcastTextID=21736 where entry=22949 and groupid=6 and id=0;
update creature_text set BroadcastTextID=21737 where entry=22949 and groupid=6 and id=0;

update creature_text set BroadcastTextID=14046 where entry=19523 and groupid=0 and id=0;
update creature_text set BroadcastTextID=16898 where entry=19523 and groupid=3 and id=0;
update creature_text set BroadcastTextID=16895 where entry=19523 and groupid=4 and id=0;
update creature_text set BroadcastTextID=16902 where entry=19523 and groupid=6 and id=0;

update creature_text set BroadcastTextID=35768 where entry=35451 and groupid=6 and id=0;

update creature_text set BroadcastTextID=29429 where entry=28030 and groupid=0 and id=0;
update creature_text set BroadcastTextID=29427 where entry=28030 and groupid=0 and id=1;
update creature_text set BroadcastTextID=29430 where entry=28030 and groupid=0 and id=2;
update creature_text set BroadcastTextID=29426 where entry=28030 and groupid=0 and id=3;
update creature_text set BroadcastTextID=29431 where entry=28030 and groupid=0 and id=4;
update creature_text set BroadcastTextID=29425 where entry=28030 and groupid=0 and id=5;
update creature_text set BroadcastTextID=29428 where entry=28030 and groupid=0 and id=6;
update creature_text set BroadcastTextID=29424 where entry=28030 and groupid=0 and id=7;

update creature_text set BroadcastTextID=7145 where entry=1853 and groupid=0 and id=0;

update creature_text set BroadcastTextID=24871 where entry=25678 and groupid=0 and id=2;
update creature_text set BroadcastTextID=24873 where entry=25678 and groupid=0 and id=3;
update creature_text set BroadcastTextID=24870 where entry=25678 and groupid=0 and id=6;

update creature_text set BroadcastTextID=35703 where entry=34995 and groupid=2 and id=0;
update creature_text set BroadcastTextID=35694 where entry=34995 and groupid=6 and id=0;
update creature_text set BroadcastTextID=35696 where entry=34995 and groupid=6 and id=1;
update creature_text set BroadcastTextID=35697 where entry=34995 and groupid=6 and id=2;
update creature_text set BroadcastTextID=35698 where entry=34995 and groupid=6 and id=3;

update creature_text set BroadcastTextID=35738 where entry=34497 and groupid=0 and id=0;
update creature_text set BroadcastTextID=35746 where entry=34497 and groupid=1 and id=0;
update creature_text set BroadcastTextID=35745 where entry=34497 and groupid=2 and id=0;
update creature_text set BroadcastTextID=34967 where entry=34497 and groupid=3 and id=0;
update creature_text set BroadcastTextID=34975 where entry=34497 and groupid=4 and id=0;
update creature_text set BroadcastTextID=35744 where entry=34497 and groupid=5 and id=0;
update creature_text set BroadcastTextID=35739 where entry=34497 and groupid=6 and id=0;
update creature_text set BroadcastTextID=35740 where entry=34497 and groupid=6 and id=1;
update creature_text set BroadcastTextID=35743 where entry=34497 and groupid=7 and id=0;

update creature_text set BroadcastTextID=35738 where entry=34496 and groupid=0 and id=0;
update creature_text set BroadcastTextID=35746 where entry=34496 and groupid=1 and id=0;
update creature_text set BroadcastTextID=35745 where entry=34496 and groupid=2 and id=0;
update creature_text set BroadcastTextID=34967 where entry=34496 and groupid=3 and id=0;
update creature_text set BroadcastTextID=34975 where entry=34496 and groupid=4 and id=0;
update creature_text set BroadcastTextID=35744 where entry=34496 and groupid=5 and id=0;
update creature_text set BroadcastTextID=35739 where entry=34496 and groupid=6 and id=0;
update creature_text set BroadcastTextID=35740 where entry=34496 and groupid=6 and id=1;
update creature_text set BroadcastTextID=35743 where entry=34496 and groupid=7 and id=0;

update creature_text set BroadcastTextID=19152 where entry=21502 and groupid=2 and id=0;

update creature_text set BroadcastTextID=27898 where entry=24405 and groupid=0 and id=0;

update creature_text set BroadcastTextID=19171 where entry=21409 and groupid=0 and id=0;
update creature_text set BroadcastTextID=19181 where entry=21409 and groupid=5 and id=0;

update creature_text set BroadcastTextID=24912 where entry=25618 and groupid=1 and id=0;
update creature_text set BroadcastTextID=24929 where entry=25618 and groupid=10 and id=0;

update creature_text set BroadcastTextID=22823 where entry=23661 and groupid=0 and id=4;
update creature_text set BroadcastTextID=22823 where entry=23662 and groupid=0 and id=4;
update creature_text set BroadcastTextID=22823 where entry=23663 and groupid=0 and id=4;
update creature_text set BroadcastTextID=22823 where entry=23664 and groupid=0 and id=4;
update creature_text set BroadcastTextID=22823 where entry=23665 and groupid=0 and id=4;
update creature_text set BroadcastTextID=22823 where entry=23666 and groupid=0 and id=4;
update creature_text set BroadcastTextID=22823 where entry=23667 and groupid=0 and id=4;
update creature_text set BroadcastTextID=22823 where entry=23668 and groupid=0 and id=4;
update creature_text set BroadcastTextID=22823 where entry=23670 and groupid=0 and id=1;


























