
-- Invis Aggrobehaviour
UPDATE `spell_dbc` SET `AttributesEx3`=`AttributesEx3`|0x00020000 WHERE `Id`=35009;

