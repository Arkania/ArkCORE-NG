
delete from creature_addon where guid in (22247, 22244, 22241, 22215, 22213, 22203, 22199, 22193, 22181, 22179, 22177);
delete from creature_addon where guid in (22146, 22142, 22128, 22122, 22121, 22100, 22096, 22081, 22063, 22042, 22025);
delete from creature_addon where guid in (22015, 21954, 21939, 21932, 21906, 21894, 21886, 21885, 21884, 21879, 21871);
delete from creature_addon where guid in (21853, 21847, 36397, 36393, 36388, 36385, 36380, 36366, 36365, 36350, 36348);
delete from creature_addon where guid in (36339, 36336, 36325, 36322, 36313, 36288, 36283, 36271, 36255, 36254, 36237);
delete from creature_addon where guid in (36228, 36226, 36221, 7155, 7154, 7153, 7152, 7151, 7150, 43496, 7149, 7138);
delete from creature_addon where guid in (7137, 43464, 7136, 43458, 7135, 7134, 7133, 7132, 7125, 43162, 43155, 43145);
delete from creature_addon where guid in (7124, 7123, 7122, 7121, 7120, 42943, 7057, 7056, 7055, 7054, 7052, 7051, 7039);
delete from creature_addon where guid in (42740, 7038, 7036, 7021, 7020, 7019, 6808, 6807, 6806, 6641, 6640, 6638, 6629);
delete from creature_addon where guid in (6611, 42284, 237815, 237816, 237817, 238154, 34532, 34528, 34523, 34522);
delete from creature_addon where guid in (34511, 34508, 34506, 34500, 34498, 34494, 34492, 34490, 34488, 34487, 34486);
delete from creature_addon where guid in (34477, 34469, 34466, 34464, 34463, 34462, 34449, 34446, 34440, 34425, 34423);
delete from creature_addon where guid in (34415, 34414, 34395, 34388, 34384, 34383, 34379, 34378, 34372, 34371, 34358);
delete from creature_addon where guid in (34357, 34352, 34348, 34343, 34330, 34329, 34321, 34319, 34315, 34313, 34310);
delete from creature_addon where guid in (34308, 34304, 34295, 34287, 34286, 34271, 34269, 34266, 34260, 34256, 34246);
delete from creature_addon where guid in (34243, 34241, 34240, 34231, 34226, 34223, 34221, 34206, 34204, 34203, 34196);
delete from creature_addon where guid in (34195, 34193, 34192, 34191, 34183, 34182, 34175, 34171, 34165, 34164, 34162);
delete from creature_addon where guid in (34161, 34154, 34153, 34152, 34135, 34130, 34121, 34118, 34114, 34111, 34107);
delete from creature_addon where guid in (34103, 34101, 34090, 34077, 34072, 34069, 34062, 34053, 34049, 34035, 34034);
delete from creature_addon where guid in (34032, 34031, 34027, 34024, 34023, 34011, 34005, 33999, 33998, 33996, 33995);
delete from creature_addon where guid in (33990, 33982, 33981, 33972, 33967, 33966, 33964, 33963, 33955, 33953, 33949);
delete from creature_addon where guid in (33946, 33942, 33931, 33929, 33927, 33922, 33921, 33914, 33913, 33905, 33904);
delete from creature_addon where guid in (33903, 33902, 33898, 33895, 33889, 33883, 33876, 33869, 33859, 33852, 34505);
delete from creature_addon where guid in (33842, 33841, 33835, 33831, 33829, 33826, 33825, 33812, 33811, 33809, 33806);
delete from creature_addon where guid in (33801, 33793, 33792, 33789, 33788, 33786, 33778, 33775, 33771, 33769, 33767);
delete from creature_addon where guid in (33765, 33763, 33759, 33753, 25023, 48177, 48181, 48194, 48206, 48218, 48223);
delete from creature_addon where guid in (48314, 48346, 48351, 48369, 48403, 48419, 48450, 48505, 48519, 48549, 48605);
delete from creature_addon where guid in (48655, 48719, 48733, 48753, 48773, 48785, 48798, 48896, 48905, 48916, 48941);
delete from creature_addon where guid in (48951, 48956, 49031, 49037, 49098, 49113, 49123, 49152, 49390, 49447, 49453);
delete from creature_addon where guid in (49520, 49549, 49575, 49585, 49620, 49622, 49656, 49692, 49693, 49797, 49816);
delete from creature_addon where guid in (49845, 49856, 37391, 61893, 62880, 69792, 257834, 80705, 69019, 68981, 68790);
delete from creature_addon where guid in (68609, 68479, 68270, 68205, 68084, 68007, 67830, 67828, 67775, 67747, 67683);
delete from creature_addon where guid in (67569, 67566, 67422, 67324, 66896, 124706, 208127, 208126, 208125, 203544);
delete from creature_addon where guid in (203545, 203546, 203547, 203548, 203549, 203550, 203552, 203556, 203557, 60849);
delete from creature_addon where guid in (1417, 44949, 44948, 6658, 6660, 60850, 26019, 25603, 13663, 13660, 13662);
delete from creature_addon where guid in (13661, 13651, 13658, 13659, 26527, 4432, 9250, 37155, 13652, 13653, 61035);
delete from creature_addon where guid in (258143, 258142, 257837, 257838, 25022);

update creature set MovementType=0 where guid in (237642, 34539, 34178, 48620, 48754, 49393, 49701, 49917, 24305, 50006);
update creature set MovementType=0 where guid in (50035, 50039, 49992, 37194, 88046, 88825, 88932, 90013, 90057, 189003);




