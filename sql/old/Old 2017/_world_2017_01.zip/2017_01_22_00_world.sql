
UPDATE creature_template  SET ScriptName="npc_wounded_sentinel_44617" WHERE entry=44617;
