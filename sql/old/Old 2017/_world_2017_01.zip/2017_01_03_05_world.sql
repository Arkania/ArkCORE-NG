
DELETE FROM creature_addon WHERE guid=245971;
INSERT INTO creature_addon VALUES 
(245971, 0, 0, 0, 2, 0, "68327");

DELETE FROM creature_addon WHERE guid=246039;
INSERT INTO creature_addon VALUES 
(246039, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=249595;
INSERT INTO creature_addon VALUES 
(249595, 0, 0, 0, 1, 0, "79058");

DELETE FROM creature_addon WHERE guid=245972;
INSERT INTO creature_addon VALUES 
(245972, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=245973;
INSERT INTO creature_addon VALUES 
(245973, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=245975;
INSERT INTO creature_addon VALUES 
(245975, 0, 0, 0, 1, 375, "12550 68327 78273");

DELETE FROM creature_addon WHERE guid=248315;
INSERT INTO creature_addon VALUES 
(248315, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=249705;
INSERT INTO creature_addon VALUES 
(249705, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=282937;
INSERT INTO creature_addon VALUES 
(282937, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=282935;
INSERT INTO creature_addon VALUES 
(282935, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=245782;
INSERT INTO creature_addon VALUES 
(245782, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=282938;
INSERT INTO creature_addon VALUES 
(282938, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=282939;
INSERT INTO creature_addon VALUES 
(282939, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=282940;
INSERT INTO creature_addon VALUES 
(282940, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=248255;
INSERT INTO creature_addon VALUES 
(248255, 0, 0, 0, 1, 333, "10022");

DELETE FROM creature_addon WHERE guid=245977;
INSERT INTO creature_addon VALUES 
(245977, 0, 0, 0, 1, 375, "68327");

DELETE FROM creature_addon WHERE guid=245978;
INSERT INTO creature_addon VALUES 
(245978, 0, 0, 0, 1, 0, "68327 80264");

DELETE FROM creature_addon WHERE guid=249703;
INSERT INTO creature_addon VALUES 
(249703, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=245788;
INSERT INTO creature_addon VALUES 
(245788, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=282946;
INSERT INTO creature_addon VALUES 
(282946, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET emote=0 WHERE guid=246036;
UPDATE creature_addon SET emote=0 WHERE guid=246037;
DELETE FROM creature_addon WHERE guid=282953;
INSERT INTO creature_addon VALUES 
(282953, 0, 0, 0, 1, 0, "80264");

DELETE FROM creature_addon WHERE guid=282954;
INSERT INTO creature_addon VALUES 
(282954, 0, 0, 0, 1, 0, "80264");

DELETE FROM creature_addon WHERE guid=282955;
INSERT INTO creature_addon VALUES 
(282955, 0, 0, 0, 1, 431, "80264");

DELETE FROM creature_addon WHERE guid=282956;
INSERT INTO creature_addon VALUES 
(282956, 0, 0, 0, 1, 0, "80264");

DELETE FROM creature_addon WHERE guid=282957;
INSERT INTO creature_addon VALUES 
(282957, 0, 0, 0, 1, 0, "80264");

DELETE FROM creature_addon WHERE guid=282958;
INSERT INTO creature_addon VALUES 
(282958, 0, 0, 0, 1, 0, "80264");

DELETE FROM creature_addon WHERE guid=282959;
INSERT INTO creature_addon VALUES 
(282959, 0, 0, 0, 1, 431, "80264");

DELETE FROM creature_addon WHERE guid=245781;
INSERT INTO creature_addon VALUES 
(245781, 0, 0, 0, 1, 0, "80264");

DELETE FROM creature_addon WHERE guid=246211;
INSERT INTO creature_addon VALUES 
(246211, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=282966;
INSERT INTO creature_addon VALUES 
(282966, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=246212;
INSERT INTO creature_addon VALUES 
(246212, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=246206;
INSERT INTO creature_addon VALUES 
(246206, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248941;
INSERT INTO creature_addon VALUES 
(248941, 0, 0, 0, 1, 431, "78273");

DELETE FROM creature_addon WHERE guid=249704;
INSERT INTO creature_addon VALUES 
(249704, 0, 0, 0, 1, 0, "78273");

DELETE FROM creature_addon WHERE guid=249702;
INSERT INTO creature_addon VALUES 
(249702, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=245787;
INSERT INTO creature_addon VALUES 
(245787, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=249395;
INSERT INTO creature_addon VALUES 
(249395, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=249383;
INSERT INTO creature_addon VALUES 
(249383, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=249382;
INSERT INTO creature_addon VALUES 
(249382, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=249393;
INSERT INTO creature_addon VALUES 
(249393, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=249392;
INSERT INTO creature_addon VALUES 
(249392, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=249381;
INSERT INTO creature_addon VALUES 
(249381, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=246020;
INSERT INTO creature_addon VALUES 
(246020, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282977;
INSERT INTO creature_addon VALUES 
(282977, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282978;
INSERT INTO creature_addon VALUES 
(282978, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247991;
INSERT INTO creature_addon VALUES 
(247991, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282979;
INSERT INTO creature_addon VALUES 
(282979, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246025;
INSERT INTO creature_addon VALUES 
(246025, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246015;
INSERT INTO creature_addon VALUES 
(246015, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245985;
INSERT INTO creature_addon VALUES 
(245985, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282980;
INSERT INTO creature_addon VALUES 
(282980, 0, 0, 0, 1, 69, "76354");

DELETE FROM creature_addon WHERE guid=247990;
INSERT INTO creature_addon VALUES 
(247990, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246016;
INSERT INTO creature_addon VALUES 
(246016, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247993;
INSERT INTO creature_addon VALUES 
(247993, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247996;
INSERT INTO creature_addon VALUES 
(247996, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246019;
INSERT INTO creature_addon VALUES 
(246019, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248004;
INSERT INTO creature_addon VALUES 
(248004, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247989;
INSERT INTO creature_addon VALUES 
(247989, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246023;
INSERT INTO creature_addon VALUES 
(246023, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282981;
INSERT INTO creature_addon VALUES 
(282981, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282982;
INSERT INTO creature_addon VALUES 
(282982, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282983;
INSERT INTO creature_addon VALUES 
(282983, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246011;
INSERT INTO creature_addon VALUES 
(246011, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282985;
INSERT INTO creature_addon VALUES 
(282985, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246018;
INSERT INTO creature_addon VALUES 
(246018, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248007;
INSERT INTO creature_addon VALUES 
(248007, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247974;
INSERT INTO creature_addon VALUES 
(247974, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247970;
INSERT INTO creature_addon VALUES 
(247970, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246021;
INSERT INTO creature_addon VALUES 
(246021, 0, 0, 0, 1, 69, "76354");

DELETE FROM creature_addon WHERE guid=247999;
INSERT INTO creature_addon VALUES 
(247999, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247983;
INSERT INTO creature_addon VALUES 
(247983, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246013;
INSERT INTO creature_addon VALUES 
(246013, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247975;
INSERT INTO creature_addon VALUES 
(247975, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246022;
INSERT INTO creature_addon VALUES 
(246022, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282986;
INSERT INTO creature_addon VALUES 
(282986, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246014;
INSERT INTO creature_addon VALUES 
(246014, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282987;
INSERT INTO creature_addon VALUES 
(282987, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247972;
INSERT INTO creature_addon VALUES 
(247972, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282988;
INSERT INTO creature_addon VALUES 
(282988, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248017;
INSERT INTO creature_addon VALUES 
(248017, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282989;
INSERT INTO creature_addon VALUES 
(282989, 0, 0, 0, 1, 69, "76354");

DELETE FROM creature_addon WHERE guid=247977;
INSERT INTO creature_addon VALUES 
(247977, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248010;
INSERT INTO creature_addon VALUES 
(248010, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248001;
INSERT INTO creature_addon VALUES 
(248001, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282991;
INSERT INTO creature_addon VALUES 
(282991, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=282992;
INSERT INTO creature_addon VALUES 
(282992, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=249608;
INSERT INTO creature_addon VALUES 
(249608, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=282993;
INSERT INTO creature_addon VALUES 
(282993, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=282994;
INSERT INTO creature_addon VALUES 
(282994, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=282995;
INSERT INTO creature_addon VALUES 
(282995, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249615;
INSERT INTO creature_addon VALUES 
(249615, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=282996;
INSERT INTO creature_addon VALUES 
(282996, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249624;
INSERT INTO creature_addon VALUES 
(249624, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249612;
INSERT INTO creature_addon VALUES 
(249612, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=282997;
INSERT INTO creature_addon VALUES 
(282997, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=282998;
INSERT INTO creature_addon VALUES 
(282998, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=282999;
INSERT INTO creature_addon VALUES 
(282999, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=283000;
INSERT INTO creature_addon VALUES 
(283000, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249686;
INSERT INTO creature_addon VALUES 
(249686, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=283001;
INSERT INTO creature_addon VALUES 
(283001, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=283002;
INSERT INTO creature_addon VALUES 
(283002, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=283003;
INSERT INTO creature_addon VALUES 
(283003, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249607;
INSERT INTO creature_addon VALUES 
(249607, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249524;
INSERT INTO creature_addon VALUES 
(249524, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=283004;
INSERT INTO creature_addon VALUES 
(283004, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249611;
INSERT INTO creature_addon VALUES 
(249611, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249606;
INSERT INTO creature_addon VALUES 
(249606, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=283005;
INSERT INTO creature_addon VALUES 
(283005, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=283006;
INSERT INTO creature_addon VALUES 
(283006, 0, 0, 0, 1, 0, "73558 73561 76354");

DELETE FROM creature_addon WHERE guid=249617;
INSERT INTO creature_addon VALUES 
(249617, 0, 0, 0, 1, 0, "73558 73561 76354");

UPDATE creature_addon SET auras="29266" WHERE guid=246088;
DELETE FROM creature_addon WHERE guid=248647;
INSERT INTO creature_addon VALUES 
(248647, 0, 0, 0, 1, 0, "51733");

DELETE FROM creature_addon WHERE guid=283009;
INSERT INTO creature_addon VALUES 
(283009, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=283010;
INSERT INTO creature_addon VALUES 
(283010, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247922;
INSERT INTO creature_addon VALUES 
(247922, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247934;
INSERT INTO creature_addon VALUES 
(247934, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=283011;
INSERT INTO creature_addon VALUES 
(283011, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=283013;
INSERT INTO creature_addon VALUES 
(283013, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247930;
INSERT INTO creature_addon VALUES 
(247930, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247940;
INSERT INTO creature_addon VALUES 
(247940, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247929;
INSERT INTO creature_addon VALUES 
(247929, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=283021;
INSERT INTO creature_addon VALUES 
(283021, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=283022;
INSERT INTO creature_addon VALUES 
(283022, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=283023;
INSERT INTO creature_addon VALUES 
(283023, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247919;
INSERT INTO creature_addon VALUES 
(247919, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247937;
INSERT INTO creature_addon VALUES 
(247937, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247913;
INSERT INTO creature_addon VALUES 
(247913, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247911;
INSERT INTO creature_addon VALUES 
(247911, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=283030;
INSERT INTO creature_addon VALUES 
(283030, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247916;
INSERT INTO creature_addon VALUES 
(247916, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=283033;
INSERT INTO creature_addon VALUES 
(283033, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246042;
INSERT INTO creature_addon VALUES 
(246042, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=278010;
INSERT INTO creature_addon VALUES 
(278010, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278022;
INSERT INTO creature_addon VALUES 
(278022, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278040;
INSERT INTO creature_addon VALUES 
(278040, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283319;
INSERT INTO creature_addon VALUES 
(283319, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283320;
INSERT INTO creature_addon VALUES 
(283320, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278083;
INSERT INTO creature_addon VALUES 
(278083, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278047;
INSERT INTO creature_addon VALUES 
(278047, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278095;
INSERT INTO creature_addon VALUES 
(278095, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278131;
INSERT INTO creature_addon VALUES 
(278131, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278101;
INSERT INTO creature_addon VALUES 
(278101, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278103;
INSERT INTO creature_addon VALUES 
(278103, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283321;
INSERT INTO creature_addon VALUES 
(283321, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283322;
INSERT INTO creature_addon VALUES 
(283322, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283323;
INSERT INTO creature_addon VALUES 
(283323, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278063;
INSERT INTO creature_addon VALUES 
(278063, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278132;
INSERT INTO creature_addon VALUES 
(278132, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283324;
INSERT INTO creature_addon VALUES 
(283324, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278026;
INSERT INTO creature_addon VALUES 
(278026, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283325;
INSERT INTO creature_addon VALUES 
(283325, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278109;
INSERT INTO creature_addon VALUES 
(278109, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283326;
INSERT INTO creature_addon VALUES 
(283326, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283327;
INSERT INTO creature_addon VALUES 
(283327, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283328;
INSERT INTO creature_addon VALUES 
(283328, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283329;
INSERT INTO creature_addon VALUES 
(283329, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278032;
INSERT INTO creature_addon VALUES 
(278032, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278019;
INSERT INTO creature_addon VALUES 
(278019, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278064;
INSERT INTO creature_addon VALUES 
(278064, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283330;
INSERT INTO creature_addon VALUES 
(283330, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278122;
INSERT INTO creature_addon VALUES 
(278122, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283331;
INSERT INTO creature_addon VALUES 
(283331, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278124;
INSERT INTO creature_addon VALUES 
(278124, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283332;
INSERT INTO creature_addon VALUES 
(283332, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278108;
INSERT INTO creature_addon VALUES 
(278108, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278091;
INSERT INTO creature_addon VALUES 
(278091, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283333;
INSERT INTO creature_addon VALUES 
(283333, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283334;
INSERT INTO creature_addon VALUES 
(283334, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278117;
INSERT INTO creature_addon VALUES 
(278117, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278126;
INSERT INTO creature_addon VALUES 
(278126, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283335;
INSERT INTO creature_addon VALUES 
(283335, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283336;
INSERT INTO creature_addon VALUES 
(283336, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278079;
INSERT INTO creature_addon VALUES 
(278079, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278009;
INSERT INTO creature_addon VALUES 
(278009, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278088;
INSERT INTO creature_addon VALUES 
(278088, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283337;
INSERT INTO creature_addon VALUES 
(283337, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278116;
INSERT INTO creature_addon VALUES 
(278116, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278123;
INSERT INTO creature_addon VALUES 
(278123, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278081;
INSERT INTO creature_addon VALUES 
(278081, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283338;
INSERT INTO creature_addon VALUES 
(283338, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283339;
INSERT INTO creature_addon VALUES 
(283339, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278056;
INSERT INTO creature_addon VALUES 
(278056, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278111;
INSERT INTO creature_addon VALUES 
(278111, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278073;
INSERT INTO creature_addon VALUES 
(278073, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283340;
INSERT INTO creature_addon VALUES 
(283340, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278027;
INSERT INTO creature_addon VALUES 
(278027, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278107;
INSERT INTO creature_addon VALUES 
(278107, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283341;
INSERT INTO creature_addon VALUES 
(283341, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278031;
INSERT INTO creature_addon VALUES 
(278031, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283342;
INSERT INTO creature_addon VALUES 
(283342, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278106;
INSERT INTO creature_addon VALUES 
(278106, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278018;
INSERT INTO creature_addon VALUES 
(278018, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278094;
INSERT INTO creature_addon VALUES 
(278094, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278113;
INSERT INTO creature_addon VALUES 
(278113, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283343;
INSERT INTO creature_addon VALUES 
(283343, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278115;
INSERT INTO creature_addon VALUES 
(278115, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283344;
INSERT INTO creature_addon VALUES 
(283344, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283345;
INSERT INTO creature_addon VALUES 
(283345, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278015;
INSERT INTO creature_addon VALUES 
(278015, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283346;
INSERT INTO creature_addon VALUES 
(283346, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278133;
INSERT INTO creature_addon VALUES 
(278133, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283347;
INSERT INTO creature_addon VALUES 
(283347, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278128;
INSERT INTO creature_addon VALUES 
(278128, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278028;
INSERT INTO creature_addon VALUES 
(278028, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278059;
INSERT INTO creature_addon VALUES 
(278059, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278121;
INSERT INTO creature_addon VALUES 
(278121, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278092;
INSERT INTO creature_addon VALUES 
(278092, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278045;
INSERT INTO creature_addon VALUES 
(278045, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278037;
INSERT INTO creature_addon VALUES 
(278037, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278061;
INSERT INTO creature_addon VALUES 
(278061, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278041;
INSERT INTO creature_addon VALUES 
(278041, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283348;
INSERT INTO creature_addon VALUES 
(283348, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283349;
INSERT INTO creature_addon VALUES 
(283349, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278057;
INSERT INTO creature_addon VALUES 
(278057, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283350;
INSERT INTO creature_addon VALUES 
(283350, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278039;
INSERT INTO creature_addon VALUES 
(278039, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278053;
INSERT INTO creature_addon VALUES 
(278053, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283351;
INSERT INTO creature_addon VALUES 
(283351, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283352;
INSERT INTO creature_addon VALUES 
(283352, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278050;
INSERT INTO creature_addon VALUES 
(278050, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278074;
INSERT INTO creature_addon VALUES 
(278074, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278025;
INSERT INTO creature_addon VALUES 
(278025, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283353;
INSERT INTO creature_addon VALUES 
(283353, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278077;
INSERT INTO creature_addon VALUES 
(278077, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278055;
INSERT INTO creature_addon VALUES 
(278055, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283354;
INSERT INTO creature_addon VALUES 
(283354, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278096;
INSERT INTO creature_addon VALUES 
(278096, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278089;
INSERT INTO creature_addon VALUES 
(278089, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278125;
INSERT INTO creature_addon VALUES 
(278125, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278087;
INSERT INTO creature_addon VALUES 
(278087, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283355;
INSERT INTO creature_addon VALUES 
(283355, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278084;
INSERT INTO creature_addon VALUES 
(278084, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278048;
INSERT INTO creature_addon VALUES 
(278048, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278093;
INSERT INTO creature_addon VALUES 
(278093, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283356;
INSERT INTO creature_addon VALUES 
(283356, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278129;
INSERT INTO creature_addon VALUES 
(278129, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278071;
INSERT INTO creature_addon VALUES 
(278071, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278118;
INSERT INTO creature_addon VALUES 
(278118, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283357;
INSERT INTO creature_addon VALUES 
(283357, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278075;
INSERT INTO creature_addon VALUES 
(278075, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278060;
INSERT INTO creature_addon VALUES 
(278060, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278058;
INSERT INTO creature_addon VALUES 
(278058, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283358;
INSERT INTO creature_addon VALUES 
(283358, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278072;
INSERT INTO creature_addon VALUES 
(278072, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278030;
INSERT INTO creature_addon VALUES 
(278030, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283359;
INSERT INTO creature_addon VALUES 
(283359, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283360;
INSERT INTO creature_addon VALUES 
(283360, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278120;
INSERT INTO creature_addon VALUES 
(278120, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283361;
INSERT INTO creature_addon VALUES 
(283361, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278100;
INSERT INTO creature_addon VALUES 
(278100, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278082;
INSERT INTO creature_addon VALUES 
(278082, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278054;
INSERT INTO creature_addon VALUES 
(278054, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283362;
INSERT INTO creature_addon VALUES 
(283362, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278090;
INSERT INTO creature_addon VALUES 
(278090, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283363;
INSERT INTO creature_addon VALUES 
(283363, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283364;
INSERT INTO creature_addon VALUES 
(283364, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283365;
INSERT INTO creature_addon VALUES 
(283365, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283366;
INSERT INTO creature_addon VALUES 
(283366, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278021;
INSERT INTO creature_addon VALUES 
(278021, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278119;
INSERT INTO creature_addon VALUES 
(278119, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283367;
INSERT INTO creature_addon VALUES 
(283367, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=278099;
INSERT INTO creature_addon VALUES 
(278099, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=283368;
INSERT INTO creature_addon VALUES 
(283368, 0, 0, 0, 1, 0, "66727");

DELETE FROM creature_addon WHERE guid=247821;
INSERT INTO creature_addon VALUES 
(247821, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283369;
INSERT INTO creature_addon VALUES 
(283369, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247797;
INSERT INTO creature_addon VALUES 
(247797, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247868;
INSERT INTO creature_addon VALUES 
(247868, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247795;
INSERT INTO creature_addon VALUES 
(247795, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247796;
INSERT INTO creature_addon VALUES 
(247796, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247794;
INSERT INTO creature_addon VALUES 
(247794, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283370;
INSERT INTO creature_addon VALUES 
(283370, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247792;
INSERT INTO creature_addon VALUES 
(247792, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283371;
INSERT INTO creature_addon VALUES 
(283371, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247815;
INSERT INTO creature_addon VALUES 
(247815, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283372;
INSERT INTO creature_addon VALUES 
(283372, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247813;
INSERT INTO creature_addon VALUES 
(247813, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283373;
INSERT INTO creature_addon VALUES 
(283373, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247822;
INSERT INTO creature_addon VALUES 
(247822, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247814;
INSERT INTO creature_addon VALUES 
(247814, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247858;
INSERT INTO creature_addon VALUES 
(247858, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283374;
INSERT INTO creature_addon VALUES 
(283374, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283375;
INSERT INTO creature_addon VALUES 
(283375, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283376;
INSERT INTO creature_addon VALUES 
(283376, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247819;
INSERT INTO creature_addon VALUES 
(247819, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283377;
INSERT INTO creature_addon VALUES 
(283377, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283378;
INSERT INTO creature_addon VALUES 
(283378, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283379;
INSERT INTO creature_addon VALUES 
(283379, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247812;
INSERT INTO creature_addon VALUES 
(247812, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283380;
INSERT INTO creature_addon VALUES 
(283380, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247793;
INSERT INTO creature_addon VALUES 
(247793, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247817;
INSERT INTO creature_addon VALUES 
(247817, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247866;
INSERT INTO creature_addon VALUES 
(247866, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247820;
INSERT INTO creature_addon VALUES 
(247820, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283381;
INSERT INTO creature_addon VALUES 
(283381, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283382;
INSERT INTO creature_addon VALUES 
(283382, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=283383;
INSERT INTO creature_addon VALUES 
(283383, 0, 0, 0, 1, 333, "68327");

DELETE FROM creature_addon WHERE guid=283384;
INSERT INTO creature_addon VALUES 
(283384, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=283385;
INSERT INTO creature_addon VALUES 
(283385, 0, 0, 0, 1, 234, "68327");

DELETE FROM creature_addon WHERE guid=246044;
INSERT INTO creature_addon VALUES 
(246044, 0, 0, 0, 1, 69, "68327");

DELETE FROM creature_addon WHERE guid=246043;
INSERT INTO creature_addon VALUES 
(246043, 0, 0, 8, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=248478;
INSERT INTO creature_addon VALUES 
(248478, 0, 0, 0, 1, 69, "68327");

DELETE FROM creature_addon WHERE guid=1735;
INSERT INTO creature_addon VALUES 
(1735, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=1736;
INSERT INTO creature_addon VALUES 
(1736, 0, 0, 65536, 1, 69, "");

DELETE FROM creature_addon WHERE guid=1734;
INSERT INTO creature_addon VALUES 
(1734, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=660;
INSERT INTO creature_addon VALUES 
(660, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=947;
INSERT INTO creature_addon VALUES 
(947, 0, 0, 65536, 1, 233, "");

DELETE FROM creature_addon WHERE guid=948;
INSERT INTO creature_addon VALUES 
(948, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=283391;
INSERT INTO creature_addon VALUES 
(283391, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=283390;
INSERT INTO creature_addon VALUES 
(283390, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=283393;
INSERT INTO creature_addon VALUES 
(283393, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=246783;
INSERT INTO creature_addon VALUES 
(246783, 0, 0, 0, 2, 0, "68207");

DELETE FROM creature_addon WHERE guid=246090;
INSERT INTO creature_addon VALUES 
(246090, 0, 0, 0, 2, 0, "");

DELETE FROM creature_addon WHERE guid=246089;
INSERT INTO creature_addon VALUES 
(246089, 0, 0, 0, 2, 0, "");

DELETE FROM creature_addon WHERE guid=247260;
INSERT INTO creature_addon VALUES 
(247260, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283593;
INSERT INTO creature_addon VALUES 
(283593, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283594;
INSERT INTO creature_addon VALUES 
(283594, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247263;
INSERT INTO creature_addon VALUES 
(247263, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247262;
INSERT INTO creature_addon VALUES 
(247262, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283595;
INSERT INTO creature_addon VALUES 
(283595, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247247;
INSERT INTO creature_addon VALUES 
(247247, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247209;
INSERT INTO creature_addon VALUES 
(247209, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283596;
INSERT INTO creature_addon VALUES 
(283596, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283597;
INSERT INTO creature_addon VALUES 
(283597, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247266;
INSERT INTO creature_addon VALUES 
(247266, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247244;
INSERT INTO creature_addon VALUES 
(247244, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247235;
INSERT INTO creature_addon VALUES 
(247235, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247265;
INSERT INTO creature_addon VALUES 
(247265, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283598;
INSERT INTO creature_addon VALUES 
(283598, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247213;
INSERT INTO creature_addon VALUES 
(247213, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283599;
INSERT INTO creature_addon VALUES 
(283599, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283600;
INSERT INTO creature_addon VALUES 
(283600, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283601;
INSERT INTO creature_addon VALUES 
(283601, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247258;
INSERT INTO creature_addon VALUES 
(247258, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283602;
INSERT INTO creature_addon VALUES 
(283602, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247264;
INSERT INTO creature_addon VALUES 
(247264, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283603;
INSERT INTO creature_addon VALUES 
(283603, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247205;
INSERT INTO creature_addon VALUES 
(247205, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247248;
INSERT INTO creature_addon VALUES 
(247248, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283604;
INSERT INTO creature_addon VALUES 
(283604, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247219;
INSERT INTO creature_addon VALUES 
(247219, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247242;
INSERT INTO creature_addon VALUES 
(247242, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247252;
INSERT INTO creature_addon VALUES 
(247252, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247241;
INSERT INTO creature_addon VALUES 
(247241, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247214;
INSERT INTO creature_addon VALUES 
(247214, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283605;
INSERT INTO creature_addon VALUES 
(283605, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247212;
INSERT INTO creature_addon VALUES 
(247212, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247255;
INSERT INTO creature_addon VALUES 
(247255, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283606;
INSERT INTO creature_addon VALUES 
(283606, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283607;
INSERT INTO creature_addon VALUES 
(283607, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283608;
INSERT INTO creature_addon VALUES 
(283608, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283609;
INSERT INTO creature_addon VALUES 
(283609, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247210;
INSERT INTO creature_addon VALUES 
(247210, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247203;
INSERT INTO creature_addon VALUES 
(247203, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283610;
INSERT INTO creature_addon VALUES 
(283610, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283611;
INSERT INTO creature_addon VALUES 
(283611, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283612;
INSERT INTO creature_addon VALUES 
(283612, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247201;
INSERT INTO creature_addon VALUES 
(247201, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283613;
INSERT INTO creature_addon VALUES 
(283613, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247236;
INSERT INTO creature_addon VALUES 
(247236, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=247232;
INSERT INTO creature_addon VALUES 
(247232, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283614;
INSERT INTO creature_addon VALUES 
(283614, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283615;
INSERT INTO creature_addon VALUES 
(283615, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=283616;
INSERT INTO creature_addon VALUES 
(283616, 0, 0, 0, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=246053;
INSERT INTO creature_addon VALUES 
(246053, 0, 0, 0, 2, 0, "68327");

DELETE FROM creature_addon WHERE guid=248286;
INSERT INTO creature_addon VALUES 
(248286, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248392;
INSERT INTO creature_addon VALUES 
(248392, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283617;
INSERT INTO creature_addon VALUES 
(283617, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248336;
INSERT INTO creature_addon VALUES 
(248336, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248342;
INSERT INTO creature_addon VALUES 
(248342, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283618;
INSERT INTO creature_addon VALUES 
(283618, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283619;
INSERT INTO creature_addon VALUES 
(283619, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248284;
INSERT INTO creature_addon VALUES 
(248284, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283620;
INSERT INTO creature_addon VALUES 
(283620, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283621;
INSERT INTO creature_addon VALUES 
(283621, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283622;
INSERT INTO creature_addon VALUES 
(283622, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283623;
INSERT INTO creature_addon VALUES 
(283623, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248280;
INSERT INTO creature_addon VALUES 
(248280, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283624;
INSERT INTO creature_addon VALUES 
(283624, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283625;
INSERT INTO creature_addon VALUES 
(283625, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283626;
INSERT INTO creature_addon VALUES 
(283626, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248272;
INSERT INTO creature_addon VALUES 
(248272, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283627;
INSERT INTO creature_addon VALUES 
(283627, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283628;
INSERT INTO creature_addon VALUES 
(283628, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248328;
INSERT INTO creature_addon VALUES 
(248328, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283629;
INSERT INTO creature_addon VALUES 
(283629, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283630;
INSERT INTO creature_addon VALUES 
(283630, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248302;
INSERT INTO creature_addon VALUES 
(248302, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283631;
INSERT INTO creature_addon VALUES 
(283631, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283632;
INSERT INTO creature_addon VALUES 
(283632, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283633;
INSERT INTO creature_addon VALUES 
(283633, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248273;
INSERT INTO creature_addon VALUES 
(248273, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283634;
INSERT INTO creature_addon VALUES 
(283634, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283635;
INSERT INTO creature_addon VALUES 
(283635, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283636;
INSERT INTO creature_addon VALUES 
(283636, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283637;
INSERT INTO creature_addon VALUES 
(283637, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283638;
INSERT INTO creature_addon VALUES 
(283638, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248326;
INSERT INTO creature_addon VALUES 
(248326, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283640;
INSERT INTO creature_addon VALUES 
(283640, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248457;
INSERT INTO creature_addon VALUES 
(248457, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283641;
INSERT INTO creature_addon VALUES 
(283641, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283642;
INSERT INTO creature_addon VALUES 
(283642, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283643;
INSERT INTO creature_addon VALUES 
(283643, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283644;
INSERT INTO creature_addon VALUES 
(283644, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283645;
INSERT INTO creature_addon VALUES 
(283645, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283646;
INSERT INTO creature_addon VALUES 
(283646, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283647;
INSERT INTO creature_addon VALUES 
(283647, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283648;
INSERT INTO creature_addon VALUES 
(283648, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283649;
INSERT INTO creature_addon VALUES 
(283649, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283650;
INSERT INTO creature_addon VALUES 
(283650, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283651;
INSERT INTO creature_addon VALUES 
(283651, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248323;
INSERT INTO creature_addon VALUES 
(248323, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283652;
INSERT INTO creature_addon VALUES 
(283652, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248298;
INSERT INTO creature_addon VALUES 
(248298, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283653;
INSERT INTO creature_addon VALUES 
(283653, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283654;
INSERT INTO creature_addon VALUES 
(283654, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283655;
INSERT INTO creature_addon VALUES 
(283655, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283656;
INSERT INTO creature_addon VALUES 
(283656, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283657;
INSERT INTO creature_addon VALUES 
(283657, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248285;
INSERT INTO creature_addon VALUES 
(248285, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248339;
INSERT INTO creature_addon VALUES 
(248339, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283658;
INSERT INTO creature_addon VALUES 
(283658, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283659;
INSERT INTO creature_addon VALUES 
(283659, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283660;
INSERT INTO creature_addon VALUES 
(283660, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283661;
INSERT INTO creature_addon VALUES 
(283661, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283662;
INSERT INTO creature_addon VALUES 
(283662, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283663;
INSERT INTO creature_addon VALUES 
(283663, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248341;
INSERT INTO creature_addon VALUES 
(248341, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283664;
INSERT INTO creature_addon VALUES 
(283664, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283639;
INSERT INTO creature_addon VALUES 
(283639, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283666;
INSERT INTO creature_addon VALUES 
(283666, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283667;
INSERT INTO creature_addon VALUES 
(283667, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283668;
INSERT INTO creature_addon VALUES 
(283668, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283669;
INSERT INTO creature_addon VALUES 
(283669, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283670;
INSERT INTO creature_addon VALUES 
(283670, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283671;
INSERT INTO creature_addon VALUES 
(283671, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283672;
INSERT INTO creature_addon VALUES 
(283672, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283673;
INSERT INTO creature_addon VALUES 
(283673, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283674;
INSERT INTO creature_addon VALUES 
(283674, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283675;
INSERT INTO creature_addon VALUES 
(283675, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283676;
INSERT INTO creature_addon VALUES 
(283676, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248279;
INSERT INTO creature_addon VALUES 
(248279, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283677;
INSERT INTO creature_addon VALUES 
(283677, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283678;
INSERT INTO creature_addon VALUES 
(283678, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283679;
INSERT INTO creature_addon VALUES 
(283679, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283680;
INSERT INTO creature_addon VALUES 
(283680, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283681;
INSERT INTO creature_addon VALUES 
(283681, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283682;
INSERT INTO creature_addon VALUES 
(283682, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283683;
INSERT INTO creature_addon VALUES 
(283683, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283684;
INSERT INTO creature_addon VALUES 
(283684, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283685;
INSERT INTO creature_addon VALUES 
(283685, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283686;
INSERT INTO creature_addon VALUES 
(283686, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283687;
INSERT INTO creature_addon VALUES 
(283687, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283688;
INSERT INTO creature_addon VALUES 
(283688, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283689;
INSERT INTO creature_addon VALUES 
(283689, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283690;
INSERT INTO creature_addon VALUES 
(283690, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283691;
INSERT INTO creature_addon VALUES 
(283691, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283692;
INSERT INTO creature_addon VALUES 
(283692, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283693;
INSERT INTO creature_addon VALUES 
(283693, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283694;
INSERT INTO creature_addon VALUES 
(283694, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283695;
INSERT INTO creature_addon VALUES 
(283695, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283696;
INSERT INTO creature_addon VALUES 
(283696, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283697;
INSERT INTO creature_addon VALUES 
(283697, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283698;
INSERT INTO creature_addon VALUES 
(283698, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283699;
INSERT INTO creature_addon VALUES 
(283699, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283700;
INSERT INTO creature_addon VALUES 
(283700, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248533;
INSERT INTO creature_addon VALUES 
(248533, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283701;
INSERT INTO creature_addon VALUES 
(283701, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283702;
INSERT INTO creature_addon VALUES 
(283702, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283703;
INSERT INTO creature_addon VALUES 
(283703, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283704;
INSERT INTO creature_addon VALUES 
(283704, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283705;
INSERT INTO creature_addon VALUES 
(283705, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283706;
INSERT INTO creature_addon VALUES 
(283706, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283707;
INSERT INTO creature_addon VALUES 
(283707, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283708;
INSERT INTO creature_addon VALUES 
(283708, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283709;
INSERT INTO creature_addon VALUES 
(283709, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283710;
INSERT INTO creature_addon VALUES 
(283710, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283711;
INSERT INTO creature_addon VALUES 
(283711, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283712;
INSERT INTO creature_addon VALUES 
(283712, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283713;
INSERT INTO creature_addon VALUES 
(283713, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283714;
INSERT INTO creature_addon VALUES 
(283714, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283715;
INSERT INTO creature_addon VALUES 
(283715, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283716;
INSERT INTO creature_addon VALUES 
(283716, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283717;
INSERT INTO creature_addon VALUES 
(283717, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283718;
INSERT INTO creature_addon VALUES 
(283718, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283719;
INSERT INTO creature_addon VALUES 
(283719, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283720;
INSERT INTO creature_addon VALUES 
(283720, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283721;
INSERT INTO creature_addon VALUES 
(283721, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283722;
INSERT INTO creature_addon VALUES 
(283722, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283723;
INSERT INTO creature_addon VALUES 
(283723, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283724;
INSERT INTO creature_addon VALUES 
(283724, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283725;
INSERT INTO creature_addon VALUES 
(283725, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283726;
INSERT INTO creature_addon VALUES 
(283726, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283727;
INSERT INTO creature_addon VALUES 
(283727, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283728;
INSERT INTO creature_addon VALUES 
(283728, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283729;
INSERT INTO creature_addon VALUES 
(283729, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283730;
INSERT INTO creature_addon VALUES 
(283730, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283731;
INSERT INTO creature_addon VALUES 
(283731, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283732;
INSERT INTO creature_addon VALUES 
(283732, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283733;
INSERT INTO creature_addon VALUES 
(283733, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283735;
INSERT INTO creature_addon VALUES 
(283735, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283736;
INSERT INTO creature_addon VALUES 
(283736, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283737;
INSERT INTO creature_addon VALUES 
(283737, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283738;
INSERT INTO creature_addon VALUES 
(283738, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283739;
INSERT INTO creature_addon VALUES 
(283739, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283740;
INSERT INTO creature_addon VALUES 
(283740, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283741;
INSERT INTO creature_addon VALUES 
(283741, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283742;
INSERT INTO creature_addon VALUES 
(283742, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283743;
INSERT INTO creature_addon VALUES 
(283743, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283744;
INSERT INTO creature_addon VALUES 
(283744, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283745;
INSERT INTO creature_addon VALUES 
(283745, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283746;
INSERT INTO creature_addon VALUES 
(283746, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283747;
INSERT INTO creature_addon VALUES 
(283747, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283748;
INSERT INTO creature_addon VALUES 
(283748, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283749;
INSERT INTO creature_addon VALUES 
(283749, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283750;
INSERT INTO creature_addon VALUES 
(283750, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283751;
INSERT INTO creature_addon VALUES 
(283751, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283752;
INSERT INTO creature_addon VALUES 
(283752, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283753;
INSERT INTO creature_addon VALUES 
(283753, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283754;
INSERT INTO creature_addon VALUES 
(283754, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283755;
INSERT INTO creature_addon VALUES 
(283755, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283756;
INSERT INTO creature_addon VALUES 
(283756, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283757;
INSERT INTO creature_addon VALUES 
(283757, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283758;
INSERT INTO creature_addon VALUES 
(283758, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283759;
INSERT INTO creature_addon VALUES 
(283759, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248532;
INSERT INTO creature_addon VALUES 
(248532, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283760;
INSERT INTO creature_addon VALUES 
(283760, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248531;
INSERT INTO creature_addon VALUES 
(248531, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283761;
INSERT INTO creature_addon VALUES 
(283761, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283762;
INSERT INTO creature_addon VALUES 
(283762, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283763;
INSERT INTO creature_addon VALUES 
(283763, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283764;
INSERT INTO creature_addon VALUES 
(283764, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283765;
INSERT INTO creature_addon VALUES 
(283765, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283766;
INSERT INTO creature_addon VALUES 
(283766, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283767;
INSERT INTO creature_addon VALUES 
(283767, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283768;
INSERT INTO creature_addon VALUES 
(283768, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283769;
INSERT INTO creature_addon VALUES 
(283769, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283770;
INSERT INTO creature_addon VALUES 
(283770, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283771;
INSERT INTO creature_addon VALUES 
(283771, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283772;
INSERT INTO creature_addon VALUES 
(283772, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283773;
INSERT INTO creature_addon VALUES 
(283773, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283774;
INSERT INTO creature_addon VALUES 
(283774, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283775;
INSERT INTO creature_addon VALUES 
(283775, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283776;
INSERT INTO creature_addon VALUES 
(283776, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283777;
INSERT INTO creature_addon VALUES 
(283777, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283778;
INSERT INTO creature_addon VALUES 
(283778, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283779;
INSERT INTO creature_addon VALUES 
(283779, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283780;
INSERT INTO creature_addon VALUES 
(283780, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283781;
INSERT INTO creature_addon VALUES 
(283781, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283782;
INSERT INTO creature_addon VALUES 
(283782, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283783;
INSERT INTO creature_addon VALUES 
(283783, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283784;
INSERT INTO creature_addon VALUES 
(283784, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283785;
INSERT INTO creature_addon VALUES 
(283785, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283786;
INSERT INTO creature_addon VALUES 
(283786, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283787;
INSERT INTO creature_addon VALUES 
(283787, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283788;
INSERT INTO creature_addon VALUES 
(283788, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283789;
INSERT INTO creature_addon VALUES 
(283789, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283790;
INSERT INTO creature_addon VALUES 
(283790, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283791;
INSERT INTO creature_addon VALUES 
(283791, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283792;
INSERT INTO creature_addon VALUES 
(283792, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283793;
INSERT INTO creature_addon VALUES 
(283793, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283794;
INSERT INTO creature_addon VALUES 
(283794, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283795;
INSERT INTO creature_addon VALUES 
(283795, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248526;
INSERT INTO creature_addon VALUES 
(248526, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283796;
INSERT INTO creature_addon VALUES 
(283796, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283797;
INSERT INTO creature_addon VALUES 
(283797, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283798;
INSERT INTO creature_addon VALUES 
(283798, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283799;
INSERT INTO creature_addon VALUES 
(283799, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283800;
INSERT INTO creature_addon VALUES 
(283800, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283801;
INSERT INTO creature_addon VALUES 
(283801, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283802;
INSERT INTO creature_addon VALUES 
(283802, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283803;
INSERT INTO creature_addon VALUES 
(283803, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283804;
INSERT INTO creature_addon VALUES 
(283804, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283805;
INSERT INTO creature_addon VALUES 
(283805, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283806;
INSERT INTO creature_addon VALUES 
(283806, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283807;
INSERT INTO creature_addon VALUES 
(283807, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283808;
INSERT INTO creature_addon VALUES 
(283808, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283809;
INSERT INTO creature_addon VALUES 
(283809, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283810;
INSERT INTO creature_addon VALUES 
(283810, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283811;
INSERT INTO creature_addon VALUES 
(283811, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283812;
INSERT INTO creature_addon VALUES 
(283812, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283813;
INSERT INTO creature_addon VALUES 
(283813, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283814;
INSERT INTO creature_addon VALUES 
(283814, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283815;
INSERT INTO creature_addon VALUES 
(283815, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283816;
INSERT INTO creature_addon VALUES 
(283816, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283817;
INSERT INTO creature_addon VALUES 
(283817, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283818;
INSERT INTO creature_addon VALUES 
(283818, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283819;
INSERT INTO creature_addon VALUES 
(283819, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283820;
INSERT INTO creature_addon VALUES 
(283820, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283821;
INSERT INTO creature_addon VALUES 
(283821, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283822;
INSERT INTO creature_addon VALUES 
(283822, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283823;
INSERT INTO creature_addon VALUES 
(283823, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283824;
INSERT INTO creature_addon VALUES 
(283824, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283826;
INSERT INTO creature_addon VALUES 
(283826, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283827;
INSERT INTO creature_addon VALUES 
(283827, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283828;
INSERT INTO creature_addon VALUES 
(283828, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283829;
INSERT INTO creature_addon VALUES 
(283829, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283830;
INSERT INTO creature_addon VALUES 
(283830, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283831;
INSERT INTO creature_addon VALUES 
(283831, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283832;
INSERT INTO creature_addon VALUES 
(283832, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283833;
INSERT INTO creature_addon VALUES 
(283833, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283834;
INSERT INTO creature_addon VALUES 
(283834, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283835;
INSERT INTO creature_addon VALUES 
(283835, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283836;
INSERT INTO creature_addon VALUES 
(283836, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283837;
INSERT INTO creature_addon VALUES 
(283837, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283838;
INSERT INTO creature_addon VALUES 
(283838, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283839;
INSERT INTO creature_addon VALUES 
(283839, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283840;
INSERT INTO creature_addon VALUES 
(283840, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283841;
INSERT INTO creature_addon VALUES 
(283841, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283842;
INSERT INTO creature_addon VALUES 
(283842, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283843;
INSERT INTO creature_addon VALUES 
(283843, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283844;
INSERT INTO creature_addon VALUES 
(283844, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283845;
INSERT INTO creature_addon VALUES 
(283845, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283846;
INSERT INTO creature_addon VALUES 
(283846, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283847;
INSERT INTO creature_addon VALUES 
(283847, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283848;
INSERT INTO creature_addon VALUES 
(283848, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283849;
INSERT INTO creature_addon VALUES 
(283849, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283850;
INSERT INTO creature_addon VALUES 
(283850, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283851;
INSERT INTO creature_addon VALUES 
(283851, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283852;
INSERT INTO creature_addon VALUES 
(283852, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283853;
INSERT INTO creature_addon VALUES 
(283853, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283854;
INSERT INTO creature_addon VALUES 
(283854, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283855;
INSERT INTO creature_addon VALUES 
(283855, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283856;
INSERT INTO creature_addon VALUES 
(283856, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283857;
INSERT INTO creature_addon VALUES 
(283857, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283858;
INSERT INTO creature_addon VALUES 
(283858, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283859;
INSERT INTO creature_addon VALUES 
(283859, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283860;
INSERT INTO creature_addon VALUES 
(283860, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283861;
INSERT INTO creature_addon VALUES 
(283861, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283862;
INSERT INTO creature_addon VALUES 
(283862, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249232;
INSERT INTO creature_addon VALUES 
(249232, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249221;
INSERT INTO creature_addon VALUES 
(249221, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283863;
INSERT INTO creature_addon VALUES 
(283863, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249227;
INSERT INTO creature_addon VALUES 
(249227, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=283864;
INSERT INTO creature_addon VALUES 
(283864, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249223;
INSERT INTO creature_addon VALUES 
(249223, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249217;
INSERT INTO creature_addon VALUES 
(249217, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=248936;
INSERT INTO creature_addon VALUES 
(248936, 0, 0, 0, 1, 412, "45111");

DELETE FROM creature_addon WHERE guid=248843;
INSERT INTO creature_addon VALUES 
(248843, 0, 0, 1, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248842;
INSERT INTO creature_addon VALUES 
(248842, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=283872;
INSERT INTO creature_addon VALUES 
(283872, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248852;
INSERT INTO creature_addon VALUES 
(248852, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248879;
INSERT INTO creature_addon VALUES 
(248879, 0, 0, 0, 1, 10, "45111");

DELETE FROM creature_addon WHERE guid=248853;
INSERT INTO creature_addon VALUES 
(248853, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248848;
INSERT INTO creature_addon VALUES 
(248848, 0, 0, 0, 1, 412, "45111");

DELETE FROM creature_addon WHERE guid=283870;
INSERT INTO creature_addon VALUES 
(283870, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=283871;
INSERT INTO creature_addon VALUES 
(283871, 0, 0, 1, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248939;
INSERT INTO creature_addon VALUES 
(248939, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=283876;
INSERT INTO creature_addon VALUES 
(283876, 0, 0, 1, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248938;
INSERT INTO creature_addon VALUES 
(248938, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248878;
INSERT INTO creature_addon VALUES 
(248878, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248851;
INSERT INTO creature_addon VALUES 
(248851, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=283869;
INSERT INTO creature_addon VALUES 
(283869, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248395;
INSERT INTO creature_addon VALUES 
(248395, 0, 0, 1, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248900;
INSERT INTO creature_addon VALUES 
(248900, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248899;
INSERT INTO creature_addon VALUES 
(248899, 0, 0, 0, 1, 10, "45111");

DELETE FROM creature_addon WHERE guid=248814;
INSERT INTO creature_addon VALUES 
(248814, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=283873;
INSERT INTO creature_addon VALUES 
(283873, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248397;
INSERT INTO creature_addon VALUES 
(248397, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=283874;
INSERT INTO creature_addon VALUES 
(283874, 0, 0, 0, 1, 412, "45111");

DELETE FROM creature_addon WHERE guid=248409;
INSERT INTO creature_addon VALUES 
(248409, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248960;
INSERT INTO creature_addon VALUES 
(248960, 0, 0, 0, 1, 10, "45111");

DELETE FROM creature_addon WHERE guid=283875;
INSERT INTO creature_addon VALUES 
(283875, 0, 0, 0, 1, 412, "45111");

DELETE FROM creature_addon WHERE guid=248849;
INSERT INTO creature_addon VALUES 
(248849, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248827;
INSERT INTO creature_addon VALUES 
(248827, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=248396;
INSERT INTO creature_addon VALUES 
(248396, 0, 0, 0, 1, 0, "45111");

DELETE FROM creature_addon WHERE guid=283877;
INSERT INTO creature_addon VALUES 
(283877, 0, 0, 0, 1, 0, "90317 75773");

DELETE FROM creature_addon WHERE guid=283878;
INSERT INTO creature_addon VALUES 
(283878, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283879;
INSERT INTO creature_addon VALUES 
(283879, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283880;
INSERT INTO creature_addon VALUES 
(283880, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283881;
INSERT INTO creature_addon VALUES 
(283881, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283882;
INSERT INTO creature_addon VALUES 
(283882, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283883;
INSERT INTO creature_addon VALUES 
(283883, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283884;
INSERT INTO creature_addon VALUES 
(283884, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245325;
INSERT INTO creature_addon VALUES 
(245325, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283885;
INSERT INTO creature_addon VALUES 
(283885, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283886;
INSERT INTO creature_addon VALUES 
(283886, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283887;
INSERT INTO creature_addon VALUES 
(283887, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283888;
INSERT INTO creature_addon VALUES 
(283888, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283889;
INSERT INTO creature_addon VALUES 
(283889, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283890;
INSERT INTO creature_addon VALUES 
(283890, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283891;
INSERT INTO creature_addon VALUES 
(283891, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283892;
INSERT INTO creature_addon VALUES 
(283892, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283893;
INSERT INTO creature_addon VALUES 
(283893, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283894;
INSERT INTO creature_addon VALUES 
(283894, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283895;
INSERT INTO creature_addon VALUES 
(283895, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283896;
INSERT INTO creature_addon VALUES 
(283896, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245317;
INSERT INTO creature_addon VALUES 
(245317, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283897;
INSERT INTO creature_addon VALUES 
(283897, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245327;
INSERT INTO creature_addon VALUES 
(245327, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283898;
INSERT INTO creature_addon VALUES 
(283898, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245335;
INSERT INTO creature_addon VALUES 
(245335, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245340;
INSERT INTO creature_addon VALUES 
(245340, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283899;
INSERT INTO creature_addon VALUES 
(283899, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283900;
INSERT INTO creature_addon VALUES 
(283900, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245336;
INSERT INTO creature_addon VALUES 
(245336, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283901;
INSERT INTO creature_addon VALUES 
(283901, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245332;
INSERT INTO creature_addon VALUES 
(245332, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283902;
INSERT INTO creature_addon VALUES 
(283902, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283903;
INSERT INTO creature_addon VALUES 
(283903, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283904;
INSERT INTO creature_addon VALUES 
(283904, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283905;
INSERT INTO creature_addon VALUES 
(283905, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283906;
INSERT INTO creature_addon VALUES 
(283906, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283907;
INSERT INTO creature_addon VALUES 
(283907, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245338;
INSERT INTO creature_addon VALUES 
(245338, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245347;
INSERT INTO creature_addon VALUES 
(245347, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245322;
INSERT INTO creature_addon VALUES 
(245322, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283908;
INSERT INTO creature_addon VALUES 
(283908, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283909;
INSERT INTO creature_addon VALUES 
(283909, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245319;
INSERT INTO creature_addon VALUES 
(245319, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245331;
INSERT INTO creature_addon VALUES 
(245331, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245326;
INSERT INTO creature_addon VALUES 
(245326, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283910;
INSERT INTO creature_addon VALUES 
(283910, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283911;
INSERT INTO creature_addon VALUES 
(283911, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283912;
INSERT INTO creature_addon VALUES 
(283912, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283913;
INSERT INTO creature_addon VALUES 
(283913, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245339;
INSERT INTO creature_addon VALUES 
(245339, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283914;
INSERT INTO creature_addon VALUES 
(283914, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283915;
INSERT INTO creature_addon VALUES 
(283915, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283916;
INSERT INTO creature_addon VALUES 
(283916, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283917;
INSERT INTO creature_addon VALUES 
(283917, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283918;
INSERT INTO creature_addon VALUES 
(283918, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283919;
INSERT INTO creature_addon VALUES 
(283919, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283920;
INSERT INTO creature_addon VALUES 
(283920, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245330;
INSERT INTO creature_addon VALUES 
(245330, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283921;
INSERT INTO creature_addon VALUES 
(283921, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283922;
INSERT INTO creature_addon VALUES 
(283922, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283923;
INSERT INTO creature_addon VALUES 
(283923, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283924;
INSERT INTO creature_addon VALUES 
(283924, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283925;
INSERT INTO creature_addon VALUES 
(283925, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283926;
INSERT INTO creature_addon VALUES 
(283926, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245329;
INSERT INTO creature_addon VALUES 
(245329, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283927;
INSERT INTO creature_addon VALUES 
(283927, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283928;
INSERT INTO creature_addon VALUES 
(283928, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283929;
INSERT INTO creature_addon VALUES 
(283929, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283930;
INSERT INTO creature_addon VALUES 
(283930, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283931;
INSERT INTO creature_addon VALUES 
(283931, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283932;
INSERT INTO creature_addon VALUES 
(283932, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245334;
INSERT INTO creature_addon VALUES 
(245334, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245333;
INSERT INTO creature_addon VALUES 
(245333, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245346;
INSERT INTO creature_addon VALUES 
(245346, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245328;
INSERT INTO creature_addon VALUES 
(245328, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245344;
INSERT INTO creature_addon VALUES 
(245344, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283933;
INSERT INTO creature_addon VALUES 
(283933, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283934;
INSERT INTO creature_addon VALUES 
(283934, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283935;
INSERT INTO creature_addon VALUES 
(283935, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283936;
INSERT INTO creature_addon VALUES 
(283936, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283937;
INSERT INTO creature_addon VALUES 
(283937, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283938;
INSERT INTO creature_addon VALUES 
(283938, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283939;
INSERT INTO creature_addon VALUES 
(283939, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283940;
INSERT INTO creature_addon VALUES 
(283940, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283941;
INSERT INTO creature_addon VALUES 
(283941, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283942;
INSERT INTO creature_addon VALUES 
(283942, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283943;
INSERT INTO creature_addon VALUES 
(283943, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283944;
INSERT INTO creature_addon VALUES 
(283944, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283945;
INSERT INTO creature_addon VALUES 
(283945, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283946;
INSERT INTO creature_addon VALUES 
(283946, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283947;
INSERT INTO creature_addon VALUES 
(283947, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283948;
INSERT INTO creature_addon VALUES 
(283948, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245323;
INSERT INTO creature_addon VALUES 
(245323, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283949;
INSERT INTO creature_addon VALUES 
(283949, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=283976;
INSERT INTO creature_addon VALUES 
(283976, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=283977;
INSERT INTO creature_addon VALUES 
(283977, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=283978;
INSERT INTO creature_addon VALUES 
(283978, 0, 0, 0, 1, 0, "71416 95913");

UPDATE creature_addon SET path_id=246213, auras="71416 95913" WHERE guid=246213;
DELETE FROM creature_addon WHERE guid=245821;
INSERT INTO creature_addon VALUES 
(245821, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=283981;
INSERT INTO creature_addon VALUES 
(283981, 0, 0, 0, 1, 69, "90318");

DELETE FROM creature_addon WHERE guid=283982;
INSERT INTO creature_addon VALUES 
(283982, 0, 0, 0, 1, 0, "90316 76136");

DELETE FROM creature_addon WHERE guid=249507;
INSERT INTO creature_addon VALUES 
(249507, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249499;
INSERT INTO creature_addon VALUES 
(249499, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249489;
INSERT INTO creature_addon VALUES 
(249489, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249494;
INSERT INTO creature_addon VALUES 
(249494, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249473;
INSERT INTO creature_addon VALUES 
(249473, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249472;
INSERT INTO creature_addon VALUES 
(249472, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249471;
INSERT INTO creature_addon VALUES 
(249471, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249477;
INSERT INTO creature_addon VALUES 
(249477, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249497;
INSERT INTO creature_addon VALUES 
(249497, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249470;
INSERT INTO creature_addon VALUES 
(249470, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249502;
INSERT INTO creature_addon VALUES 
(249502, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249476;
INSERT INTO creature_addon VALUES 
(249476, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249469;
INSERT INTO creature_addon VALUES 
(249469, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249475;
INSERT INTO creature_addon VALUES 
(249475, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249468;
INSERT INTO creature_addon VALUES 
(249468, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249487;
INSERT INTO creature_addon VALUES 
(249487, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249504;
INSERT INTO creature_addon VALUES 
(249504, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249484;
INSERT INTO creature_addon VALUES 
(249484, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249478;
INSERT INTO creature_addon VALUES 
(249478, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=249474;
INSERT INTO creature_addon VALUES 
(249474, 0, 0, 0, 1, 0, "68295");

DELETE FROM creature_addon WHERE guid=283989;
INSERT INTO creature_addon VALUES 
(283989, 0, 0, 0, 1, 0, "66146");

DELETE FROM creature_addon WHERE guid=18587;
INSERT INTO creature_addon VALUES 
(18587, 0, 0, 65537, 1, 0, "66405");

DELETE FROM creature_addon WHERE guid=18588;
INSERT INTO creature_addon VALUES 
(18588, 0, 0, 65536, 1, 0, "66403");

DELETE FROM creature_addon WHERE guid=248354;
INSERT INTO creature_addon VALUES 
(248354, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=284028;
INSERT INTO creature_addon VALUES 
(284028, 0, 0, 0, 1, 0, "83470");

DELETE FROM creature_addon WHERE guid=284026;
INSERT INTO creature_addon VALUES 
(284026, 0, 0, 0, 1, 0, "83470");

DELETE FROM creature_addon WHERE guid=284022;
INSERT INTO creature_addon VALUES 
(284022, 0, 0, 0, 1, 0, "83470");

DELETE FROM creature_addon WHERE guid=284023;
INSERT INTO creature_addon VALUES 
(284023, 0, 0, 0, 1, 0, "83470");

DELETE FROM creature_addon WHERE guid=284025;
INSERT INTO creature_addon VALUES 
(284025, 0, 0, 0, 1, 0, "83470");

DELETE FROM creature_addon WHERE guid=245784;
INSERT INTO creature_addon VALUES 
(245784, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245785;
INSERT INTO creature_addon VALUES 
(245785, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245786;
INSERT INTO creature_addon VALUES 
(245786, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245783;
INSERT INTO creature_addon VALUES 
(245783, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48564;
INSERT INTO creature_addon VALUES 
(48564, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48798;
INSERT INTO creature_addon VALUES 
(48798, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48519;
INSERT INTO creature_addon VALUES 
(48519, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48655;
INSERT INTO creature_addon VALUES 
(48655, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48605;
INSERT INTO creature_addon VALUES 
(48605, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48549;
INSERT INTO creature_addon VALUES 
(48549, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48450;
INSERT INTO creature_addon VALUES 
(48450, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48719;
INSERT INTO creature_addon VALUES 
(48719, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48714;
INSERT INTO creature_addon VALUES 
(48714, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48773;
INSERT INTO creature_addon VALUES 
(48773, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48733;
INSERT INTO creature_addon VALUES 
(48733, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48757;
INSERT INTO creature_addon VALUES 
(48757, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48419;
INSERT INTO creature_addon VALUES 
(48419, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=48753;
INSERT INTO creature_addon VALUES 
(48753, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=246757;
INSERT INTO creature_addon VALUES 
(246757, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284054;
INSERT INTO creature_addon VALUES 
(284054, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246774;
INSERT INTO creature_addon VALUES 
(246774, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284055;
INSERT INTO creature_addon VALUES 
(284055, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284056;
INSERT INTO creature_addon VALUES 
(284056, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284057;
INSERT INTO creature_addon VALUES 
(284057, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246775;
INSERT INTO creature_addon VALUES 
(246775, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284058;
INSERT INTO creature_addon VALUES 
(284058, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246777;
INSERT INTO creature_addon VALUES 
(246777, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246773;
INSERT INTO creature_addon VALUES 
(246773, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246769;
INSERT INTO creature_addon VALUES 
(246769, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246756;
INSERT INTO creature_addon VALUES 
(246756, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284059;
INSERT INTO creature_addon VALUES 
(284059, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284060;
INSERT INTO creature_addon VALUES 
(284060, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284061;
INSERT INTO creature_addon VALUES 
(284061, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246776;
INSERT INTO creature_addon VALUES 
(246776, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284062;
INSERT INTO creature_addon VALUES 
(284062, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284063;
INSERT INTO creature_addon VALUES 
(284063, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246758;
INSERT INTO creature_addon VALUES 
(246758, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284064;
INSERT INTO creature_addon VALUES 
(284064, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284065;
INSERT INTO creature_addon VALUES 
(284065, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246772;
INSERT INTO creature_addon VALUES 
(246772, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284066;
INSERT INTO creature_addon VALUES 
(284066, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284067;
INSERT INTO creature_addon VALUES 
(284067, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284068;
INSERT INTO creature_addon VALUES 
(284068, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=246778;
INSERT INTO creature_addon VALUES 
(246778, 0, 0, 0, 1, 0, "73871");

DELETE FROM creature_addon WHERE guid=284142;
INSERT INTO creature_addon VALUES 
(284142, 0, 0, 8, 2, 0, "68327");

DELETE FROM creature_addon WHERE guid=246054;
INSERT INTO creature_addon VALUES 
(246054, 0, 0, 8, 2, 0, "68327");

DELETE FROM creature_addon WHERE guid=18589;
INSERT INTO creature_addon VALUES 
(18589, 0, 0, 65536, 1, 0, "66404");

DELETE FROM creature_addon WHERE guid=247902;
INSERT INTO creature_addon VALUES 
(247902, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=284144;
INSERT INTO creature_addon VALUES 
(284144, 0, 0, 50397184, 1, 0, "70086 89476");

DELETE FROM creature_addon WHERE guid=246120;
INSERT INTO creature_addon VALUES 
(246120, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246115;
INSERT INTO creature_addon VALUES 
(246115, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284145;
INSERT INTO creature_addon VALUES 
(284145, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284146;
INSERT INTO creature_addon VALUES 
(284146, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246141;
INSERT INTO creature_addon VALUES 
(246141, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284147;
INSERT INTO creature_addon VALUES 
(284147, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284148;
INSERT INTO creature_addon VALUES 
(284148, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284149;
INSERT INTO creature_addon VALUES 
(284149, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284165;
INSERT INTO creature_addon VALUES 
(284165, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284150;
INSERT INTO creature_addon VALUES 
(284150, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246140;
INSERT INTO creature_addon VALUES 
(246140, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284151;
INSERT INTO creature_addon VALUES 
(284151, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284152;
INSERT INTO creature_addon VALUES 
(284152, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284153;
INSERT INTO creature_addon VALUES 
(284153, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246148;
INSERT INTO creature_addon VALUES 
(246148, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284154;
INSERT INTO creature_addon VALUES 
(284154, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246118;
INSERT INTO creature_addon VALUES 
(246118, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284155;
INSERT INTO creature_addon VALUES 
(284155, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284156;
INSERT INTO creature_addon VALUES 
(284156, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246125;
INSERT INTO creature_addon VALUES 
(246125, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246137;
INSERT INTO creature_addon VALUES 
(246137, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284157;
INSERT INTO creature_addon VALUES 
(284157, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284160;
INSERT INTO creature_addon VALUES 
(284160, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284161;
INSERT INTO creature_addon VALUES 
(284161, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284162;
INSERT INTO creature_addon VALUES 
(284162, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284163;
INSERT INTO creature_addon VALUES 
(284163, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246119;
INSERT INTO creature_addon VALUES 
(246119, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284164;
INSERT INTO creature_addon VALUES 
(284164, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246127;
INSERT INTO creature_addon VALUES 
(246127, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246108;
INSERT INTO creature_addon VALUES 
(246108, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246142;
INSERT INTO creature_addon VALUES 
(246142, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284167;
INSERT INTO creature_addon VALUES 
(284167, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284168;
INSERT INTO creature_addon VALUES 
(284168, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284169;
INSERT INTO creature_addon VALUES 
(284169, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284170;
INSERT INTO creature_addon VALUES 
(284170, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284171;
INSERT INTO creature_addon VALUES 
(284171, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246111;
INSERT INTO creature_addon VALUES 
(246111, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284172;
INSERT INTO creature_addon VALUES 
(284172, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284173;
INSERT INTO creature_addon VALUES 
(284173, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284174;
INSERT INTO creature_addon VALUES 
(284174, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284176;
INSERT INTO creature_addon VALUES 
(284176, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284177;
INSERT INTO creature_addon VALUES 
(284177, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246114;
INSERT INTO creature_addon VALUES 
(246114, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284180;
INSERT INTO creature_addon VALUES 
(284180, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284181;
INSERT INTO creature_addon VALUES 
(284181, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284182;
INSERT INTO creature_addon VALUES 
(284182, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246124;
INSERT INTO creature_addon VALUES 
(246124, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284179;
INSERT INTO creature_addon VALUES 
(284179, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284184;
INSERT INTO creature_addon VALUES 
(284184, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284175;
INSERT INTO creature_addon VALUES 
(284175, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246102;
INSERT INTO creature_addon VALUES 
(246102, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246113;
INSERT INTO creature_addon VALUES 
(246113, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284186;
INSERT INTO creature_addon VALUES 
(284186, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246097;
INSERT INTO creature_addon VALUES 
(246097, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246099;
INSERT INTO creature_addon VALUES 
(246099, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246121;
INSERT INTO creature_addon VALUES 
(246121, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284187;
INSERT INTO creature_addon VALUES 
(284187, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246146;
INSERT INTO creature_addon VALUES 
(246146, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284188;
INSERT INTO creature_addon VALUES 
(284188, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284158;
INSERT INTO creature_addon VALUES 
(284158, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246101;
INSERT INTO creature_addon VALUES 
(246101, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284159;
INSERT INTO creature_addon VALUES 
(284159, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246100;
INSERT INTO creature_addon VALUES 
(246100, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246117;
INSERT INTO creature_addon VALUES 
(246117, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284191;
INSERT INTO creature_addon VALUES 
(284191, 0, 0, 0, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246134;
INSERT INTO creature_addon VALUES 
(246134, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=284192;
INSERT INTO creature_addon VALUES 
(284192, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246116;
INSERT INTO creature_addon VALUES 
(246116, 0, 0, 196608, 1, 0, "68327 68322");

DELETE FROM creature_addon WHERE guid=246126;
INSERT INTO creature_addon VALUES 
(246126, 0, 0, 196608, 1, 0, "68327 68322");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=249000;
DELETE FROM creature_addon WHERE guid=284193;
INSERT INTO creature_addon VALUES 
(284193, 0, 0, 0, 1, 333, "29266");

DELETE FROM creature_addon WHERE guid=284194;
INSERT INTO creature_addon VALUES 
(284194, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=284195;
INSERT INTO creature_addon VALUES 
(284195, 0, 0, 0, 1, 333, "29266");

DELETE FROM creature_addon WHERE guid=284196;
INSERT INTO creature_addon VALUES 
(284196, 0, 0, 0, 1, 333, "29266");

DELETE FROM creature_addon WHERE guid=284197;
INSERT INTO creature_addon VALUES 
(284197, 0, 0, 0, 1, 333, "29266");

DELETE FROM creature_addon WHERE guid=284198;
INSERT INTO creature_addon VALUES 
(284198, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=284199;
INSERT INTO creature_addon VALUES 
(284199, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=284200;
INSERT INTO creature_addon VALUES 
(284200, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=284201;
INSERT INTO creature_addon VALUES 
(284201, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=284202;
INSERT INTO creature_addon VALUES 
(284202, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=284203;
INSERT INTO creature_addon VALUES 
(284203, 0, 0, 0, 1, 333, "29266");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=249006;
DELETE FROM creature_addon WHERE guid=284204;
INSERT INTO creature_addon VALUES 
(284204, 0, 0, 0, 1, 333, "29266");

DELETE FROM creature_addon WHERE guid=284205;
INSERT INTO creature_addon VALUES 
(284205, 0, 0, 0, 1, 333, "29266");

UPDATE creature_addon SET auras="29266" WHERE guid=248991;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248994;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248992;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=249002;
DELETE FROM creature_addon WHERE guid=284206;
INSERT INTO creature_addon VALUES 
(284206, 0, 0, 0, 1, 333, "29266");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=249007;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248997;
DELETE FROM creature_addon WHERE guid=284207;
INSERT INTO creature_addon VALUES 
(284207, 0, 0, 0, 1, 333, "29266");

DELETE FROM creature_addon WHERE guid=284208;
INSERT INTO creature_addon VALUES 
(284208, 0, 0, 0, 1, 0, "29266");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=249008;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=249001;
UPDATE creature_addon SET auras="29266" WHERE guid=248996;
UPDATE creature_addon SET path_id=248999, auras="29266" WHERE guid=248999;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248995;
DELETE FROM creature_addon WHERE guid=284209;
INSERT INTO creature_addon VALUES 
(284209, 0, 0, 0, 1, 0, "29266");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248990;
DELETE FROM creature_addon WHERE guid=284210;
INSERT INTO creature_addon VALUES 
(284210, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=284211;
INSERT INTO creature_addon VALUES 
(284211, 0, 0, 0, 1, 333, "29266");

DELETE FROM creature_addon WHERE guid=284212;
INSERT INTO creature_addon VALUES 
(284212, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=284213;
INSERT INTO creature_addon VALUES 
(284213, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=246150;
INSERT INTO creature_addon VALUES 
(246150, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246157;
INSERT INTO creature_addon VALUES 
(246157, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246156;
INSERT INTO creature_addon VALUES 
(246156, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246151;
INSERT INTO creature_addon VALUES 
(246151, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246169;
INSERT INTO creature_addon VALUES 
(246169, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246163;
INSERT INTO creature_addon VALUES 
(246163, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246152;
INSERT INTO creature_addon VALUES 
(246152, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284219;
INSERT INTO creature_addon VALUES 
(284219, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246164;
INSERT INTO creature_addon VALUES 
(246164, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246158;
INSERT INTO creature_addon VALUES 
(246158, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246154;
INSERT INTO creature_addon VALUES 
(246154, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284230;
INSERT INTO creature_addon VALUES 
(284230, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247900;
INSERT INTO creature_addon VALUES 
(247900, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284232;
INSERT INTO creature_addon VALUES 
(284232, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247887;
INSERT INTO creature_addon VALUES 
(247887, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284233;
INSERT INTO creature_addon VALUES 
(284233, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284234;
INSERT INTO creature_addon VALUES 
(284234, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284235;
INSERT INTO creature_addon VALUES 
(284235, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247886;
INSERT INTO creature_addon VALUES 
(247886, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284238;
INSERT INTO creature_addon VALUES 
(284238, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247885;
INSERT INTO creature_addon VALUES 
(247885, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284239;
INSERT INTO creature_addon VALUES 
(284239, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247888;
INSERT INTO creature_addon VALUES 
(247888, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284240;
INSERT INTO creature_addon VALUES 
(284240, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284241;
INSERT INTO creature_addon VALUES 
(284241, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284242;
INSERT INTO creature_addon VALUES 
(284242, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247874;
INSERT INTO creature_addon VALUES 
(247874, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247882;
INSERT INTO creature_addon VALUES 
(247882, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247876;
INSERT INTO creature_addon VALUES 
(247876, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247893;
INSERT INTO creature_addon VALUES 
(247893, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284245;
INSERT INTO creature_addon VALUES 
(284245, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284246;
INSERT INTO creature_addon VALUES 
(284246, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247898;
INSERT INTO creature_addon VALUES 
(247898, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284247;
INSERT INTO creature_addon VALUES 
(284247, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247892;
INSERT INTO creature_addon VALUES 
(247892, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247894;
INSERT INTO creature_addon VALUES 
(247894, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284249;
INSERT INTO creature_addon VALUES 
(284249, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284250;
INSERT INTO creature_addon VALUES 
(284250, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284251;
INSERT INTO creature_addon VALUES 
(284251, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247897;
INSERT INTO creature_addon VALUES 
(247897, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284252;
INSERT INTO creature_addon VALUES 
(284252, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247884;
INSERT INTO creature_addon VALUES 
(247884, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284231;
INSERT INTO creature_addon VALUES 
(284231, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284237;
INSERT INTO creature_addon VALUES 
(284237, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247877;
INSERT INTO creature_addon VALUES 
(247877, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284256;
INSERT INTO creature_addon VALUES 
(284256, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284257;
INSERT INTO creature_addon VALUES 
(284257, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284258;
INSERT INTO creature_addon VALUES 
(284258, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284259;
INSERT INTO creature_addon VALUES 
(284259, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284236;
INSERT INTO creature_addon VALUES 
(284236, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=284262;
INSERT INTO creature_addon VALUES 
(284262, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247875;
INSERT INTO creature_addon VALUES 
(247875, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=247881;
INSERT INTO creature_addon VALUES 
(247881, 0, 0, 0, 1, 0, "73926");

DELETE FROM creature_addon WHERE guid=246093;
INSERT INTO creature_addon VALUES 
(246093, 0, 0, 0, 1, 333, "68327");

DELETE FROM creature_addon WHERE guid=284354;
INSERT INTO creature_addon VALUES 
(284354, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284356;
INSERT INTO creature_addon VALUES 
(284356, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284360;
INSERT INTO creature_addon VALUES 
(284360, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284363;
INSERT INTO creature_addon VALUES 
(284363, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284369;
INSERT INTO creature_addon VALUES 
(284369, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284370;
INSERT INTO creature_addon VALUES 
(284370, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=245407;
INSERT INTO creature_addon VALUES 
(245407, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284361;
INSERT INTO creature_addon VALUES 
(284361, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284374;
INSERT INTO creature_addon VALUES 
(284374, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284355;
INSERT INTO creature_addon VALUES 
(284355, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=245381;
INSERT INTO creature_addon VALUES 
(245381, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=245417;
INSERT INTO creature_addon VALUES 
(245417, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=245396;
INSERT INTO creature_addon VALUES 
(245396, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=245413;
INSERT INTO creature_addon VALUES 
(245413, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=245377;
INSERT INTO creature_addon VALUES 
(245377, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284373;
INSERT INTO creature_addon VALUES 
(284373, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=245401;
INSERT INTO creature_addon VALUES 
(245401, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246168;
INSERT INTO creature_addon VALUES 
(246168, 0, 0, 0, 1, 133, "");

DELETE FROM creature_addon WHERE guid=1773;
INSERT INTO creature_addon VALUES 
(1773, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=1775;
INSERT INTO creature_addon VALUES 
(1775, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=1767;
INSERT INTO creature_addon VALUES 
(1767, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=1766;
INSERT INTO creature_addon VALUES 
(1766, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=248344;
INSERT INTO creature_addon VALUES 
(248344, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=248345;
INSERT INTO creature_addon VALUES 
(248345, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=248343;
INSERT INTO creature_addon VALUES 
(248343, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246096;
INSERT INTO creature_addon VALUES 
(246096, 0, 0, 0, 1, 468, "");

DELETE FROM creature_addon WHERE guid=284430;
INSERT INTO creature_addon VALUES 
(284430, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=284431;
INSERT INTO creature_addon VALUES 
(284431, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=284433;
INSERT INTO creature_addon VALUES 
(284433, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284434;
INSERT INTO creature_addon VALUES 
(284434, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247526;
INSERT INTO creature_addon VALUES 
(247526, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=247525;
INSERT INTO creature_addon VALUES 
(247525, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=284440;
INSERT INTO creature_addon VALUES 
(284440, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284441;
INSERT INTO creature_addon VALUES 
(284441, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=247532;
INSERT INTO creature_addon VALUES 
(247532, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=284443;
INSERT INTO creature_addon VALUES 
(284443, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284444;
INSERT INTO creature_addon VALUES 
(284444, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247496;
INSERT INTO creature_addon VALUES 
(247496, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247523;
INSERT INTO creature_addon VALUES 
(247523, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=247495;
INSERT INTO creature_addon VALUES 
(247495, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247516;
INSERT INTO creature_addon VALUES 
(247516, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=284449;
INSERT INTO creature_addon VALUES 
(284449, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284450;
INSERT INTO creature_addon VALUES 
(284450, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247528;
INSERT INTO creature_addon VALUES 
(247528, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=284454;
INSERT INTO creature_addon VALUES 
(284454, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247515;
INSERT INTO creature_addon VALUES 
(247515, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247517;
INSERT INTO creature_addon VALUES 
(247517, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=247527;
INSERT INTO creature_addon VALUES 
(247527, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247544;
INSERT INTO creature_addon VALUES 
(247544, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=247514;
INSERT INTO creature_addon VALUES 
(247514, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284465;
INSERT INTO creature_addon VALUES 
(284465, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284466;
INSERT INTO creature_addon VALUES 
(284466, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284467;
INSERT INTO creature_addon VALUES 
(284467, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284468;
INSERT INTO creature_addon VALUES 
(284468, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284469;
INSERT INTO creature_addon VALUES 
(284469, 0, 0, 0, 1, 69, "");

UPDATE creature_addon SET bytes1=8 WHERE guid=242562;
UPDATE creature_addon SET emote=0 WHERE guid=248309;
UPDATE creature_addon SET bytes1=4 WHERE guid=250030;
UPDATE creature_addon SET bytes1=4 WHERE guid=250036;
UPDATE creature_addon SET bytes1=8 WHERE guid=233894;
UPDATE creature_addon SET bytes1=8 WHERE guid=233892;
UPDATE creature_addon SET bytes1=4 WHERE guid=249342;
UPDATE creature_addon SET bytes1=8 WHERE guid=241797;
UPDATE creature_addon SET bytes1=4 WHERE guid=250063;
UPDATE creature_addon SET bytes1=8 WHERE guid=240484;
UPDATE creature_addon SET bytes1=4 WHERE guid=250072;
UPDATE creature_addon SET bytes1=8 WHERE guid=241800;
UPDATE creature_addon SET bytes1=8 WHERE guid=240482;
DELETE FROM creature_addon WHERE guid=284470;
INSERT INTO creature_addon VALUES 
(284470, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET bytes1=4 WHERE guid=248805;
UPDATE creature_addon SET bytes1=8 WHERE guid=233881;
UPDATE creature_addon SET bytes1=4 WHERE guid=248321;
UPDATE creature_addon SET bytes1=4 WHERE guid=250047;
UPDATE creature_addon SET bytes1=8 WHERE guid=233848;
UPDATE creature_addon SET emote=0 WHERE guid=243266;
UPDATE creature_addon SET bytes1=4 WHERE guid=249027;
UPDATE creature_addon SET bytes1=4 WHERE guid=250251;
UPDATE creature_addon SET bytes1=8 WHERE guid=239623;
UPDATE creature_addon SET bytes1=8 WHERE guid=238154;
UPDATE creature_addon SET bytes1=8 WHERE guid=237877;
UPDATE creature_addon SET bytes1=4 WHERE guid=249498;
UPDATE creature_addon SET bytes1=4 WHERE guid=250255;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248052;
UPDATE creature_addon SET bytes1=4 WHERE guid=249503;
DELETE FROM creature_addon WHERE guid=284471;
INSERT INTO creature_addon VALUES 
(284471, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET bytes1=8 WHERE guid=239095;
UPDATE creature_addon SET bytes1=8 WHERE guid=240464;
DELETE FROM creature_addon WHERE guid=284472;
INSERT INTO creature_addon VALUES 
(284472, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET bytes1=4 WHERE guid=250227;
UPDATE creature_addon SET bytes1=8 WHERE guid=238057;
UPDATE creature_addon SET bytes1=8 WHERE guid=242294;
UPDATE creature_addon SET bytes1=4 WHERE guid=249125;
UPDATE creature_addon SET bytes1=8 WHERE guid=246782;
UPDATE creature_addon SET bytes1=4 WHERE guid=250082;
UPDATE creature_addon SET bytes1=8 WHERE guid=239093;
UPDATE creature_addon SET bytes1=8 WHERE guid=240573;
UPDATE creature_addon SET emote=0 WHERE guid=245962;
UPDATE creature_addon SET bytes1=4 WHERE guid=248391;
UPDATE creature_addon SET bytes1=4 WHERE guid=250741;
UPDATE creature_addon SET bytes1=4 WHERE guid=250791;
UPDATE creature_addon SET bytes1=8 WHERE guid=240598;
UPDATE creature_addon SET bytes1=8 WHERE guid=240566;
UPDATE creature_addon SET bytes1=4 WHERE guid=248455;
UPDATE creature_addon SET bytes1=4 WHERE guid=250931;
UPDATE creature_addon SET bytes1=8 WHERE guid=240540;
UPDATE creature_addon SET bytes1=4 WHERE guid=250778;
UPDATE creature_addon SET bytes1=8 WHERE guid=242922;
UPDATE creature_addon SET bytes1=8 WHERE guid=240526;
UPDATE creature_addon SET bytes1=8 WHERE guid=245280;
UPDATE creature_addon SET bytes1=8 WHERE guid=242182;
UPDATE creature_addon SET bytes1=4 WHERE guid=250017;
DELETE FROM creature_addon WHERE guid=284473;
INSERT INTO creature_addon VALUES 
(284473, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET bytes1=8 WHERE guid=239097;
UPDATE creature_addon SET bytes1=8 WHERE guid=241306;
UPDATE creature_addon SET bytes1=4 WHERE guid=250816;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248082;
UPDATE creature_addon SET bytes1=4 WHERE guid=250231;
DELETE FROM creature_addon WHERE guid=284474;
INSERT INTO creature_addon VALUES 
(284474, 0, 0, 1, 1, 0, "");

UPDATE creature_addon SET bytes1=4 WHERE guid=249045;
UPDATE creature_addon SET bytes1=8, emote=0 WHERE guid=240756;
DELETE FROM creature_addon WHERE guid=284475;
INSERT INTO creature_addon VALUES 
(284475, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248062;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248063;
DELETE FROM creature_addon WHERE guid=284476;
INSERT INTO creature_addon VALUES 
(284476, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248081;
DELETE FROM creature_addon WHERE guid=284477;
INSERT INTO creature_addon VALUES 
(284477, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=284478;
INSERT INTO creature_addon VALUES 
(284478, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET emote=0 WHERE guid=177307;
UPDATE creature_addon SET path_id=248059, emote=0, auras="29266" WHERE guid=248059;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248060;
UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248054;
DELETE FROM creature_addon WHERE guid=284479;
INSERT INTO creature_addon VALUES 
(284479, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248051;
DELETE FROM creature_addon WHERE guid=284480;
INSERT INTO creature_addon VALUES 
(284480, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=284481;
INSERT INTO creature_addon VALUES 
(284481, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=284482;
INSERT INTO creature_addon VALUES 
(284482, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248055;
DELETE FROM creature_addon WHERE guid=284483;
INSERT INTO creature_addon VALUES 
(284483, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=284484;
INSERT INTO creature_addon VALUES 
(284484, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=284485;
INSERT INTO creature_addon VALUES 
(284485, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET emote=0, auras="29266" WHERE guid=248058;
DELETE FROM creature_addon WHERE guid=284486;
INSERT INTO creature_addon VALUES 
(284486, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET auras="29266" WHERE guid=248084;
UPDATE creature_addon SET auras="29266" WHERE guid=248089;
UPDATE creature_addon SET auras="29266" WHERE guid=248090;
UPDATE creature_addon SET auras="29266" WHERE guid=248086;
UPDATE creature_addon SET auras="29266" WHERE guid=248092;
UPDATE creature_addon SET auras="29266" WHERE guid=248085;
UPDATE creature_addon SET auras="29266" WHERE guid=248091;
DELETE FROM creature_addon WHERE guid=284489;
INSERT INTO creature_addon VALUES 
(284489, 0, 0, 0, 1, 431, "");

UPDATE creature_addon SET auras="29266" WHERE guid=248056;
DELETE FROM creature_addon WHERE guid=284492;
INSERT INTO creature_addon VALUES 
(284492, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=284493;
INSERT INTO creature_addon VALUES 
(284493, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=284494;
INSERT INTO creature_addon VALUES 
(284494, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=284495;
INSERT INTO creature_addon VALUES 
(284495, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=284496;
INSERT INTO creature_addon VALUES 
(284496, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=284497;
INSERT INTO creature_addon VALUES 
(284497, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=284498;
INSERT INTO creature_addon VALUES 
(284498, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=284499;
INSERT INTO creature_addon VALUES 
(284499, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246661;
INSERT INTO creature_addon VALUES 
(246661, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=245970;
INSERT INTO creature_addon VALUES 
(245970, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=246031;
INSERT INTO creature_addon VALUES 
(246031, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=284500;
INSERT INTO creature_addon VALUES 
(284500, 0, 0, 0, 1, 234, "68327");

DELETE FROM creature_addon WHERE guid=246029;
INSERT INTO creature_addon VALUES 
(246029, 0, 0, 1, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=246028;
INSERT INTO creature_addon VALUES 
(246028, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=284501;
INSERT INTO creature_addon VALUES 
(284501, 0, 0, 0, 1, 234, "68327");

DELETE FROM creature_addon WHERE guid=246026;
INSERT INTO creature_addon VALUES 
(246026, 0, 0, 1, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=245981;
INSERT INTO creature_addon VALUES 
(245981, 0, 0, 0, 1, 69, "68327");

DELETE FROM creature_addon WHERE guid=245969;
INSERT INTO creature_addon VALUES 
(245969, 0, 0, 1, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=246027;
INSERT INTO creature_addon VALUES 
(246027, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=245966;
INSERT INTO creature_addon VALUES 
(245966, 0, 0, 1, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=249042;
INSERT INTO creature_addon VALUES 
(249042, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249091;
INSERT INTO creature_addon VALUES 
(249091, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249166;
INSERT INTO creature_addon VALUES 
(249166, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284511;
INSERT INTO creature_addon VALUES 
(284511, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249110;
INSERT INTO creature_addon VALUES 
(249110, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249038;
INSERT INTO creature_addon VALUES 
(249038, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=284532;
INSERT INTO creature_addon VALUES 
(284532, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284533;
INSERT INTO creature_addon VALUES 
(284533, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249333;
INSERT INTO creature_addon VALUES 
(249333, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284535;
INSERT INTO creature_addon VALUES 
(284535, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284536;
INSERT INTO creature_addon VALUES 
(284536, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249063;
INSERT INTO creature_addon VALUES 
(249063, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284537;
INSERT INTO creature_addon VALUES 
(284537, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249456;
INSERT INTO creature_addon VALUES 
(249456, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249446;
INSERT INTO creature_addon VALUES 
(249446, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249114;
INSERT INTO creature_addon VALUES 
(249114, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249113;
INSERT INTO creature_addon VALUES 
(249113, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249071;
INSERT INTO creature_addon VALUES 
(249071, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249069;
INSERT INTO creature_addon VALUES 
(249069, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284548;
INSERT INTO creature_addon VALUES 
(284548, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249064;
INSERT INTO creature_addon VALUES 
(249064, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249068;
INSERT INTO creature_addon VALUES 
(249068, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284550;
INSERT INTO creature_addon VALUES 
(284550, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284551;
INSERT INTO creature_addon VALUES 
(284551, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284552;
INSERT INTO creature_addon VALUES 
(284552, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284553;
INSERT INTO creature_addon VALUES 
(284553, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284554;
INSERT INTO creature_addon VALUES 
(284554, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249077;
INSERT INTO creature_addon VALUES 
(249077, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249076;
INSERT INTO creature_addon VALUES 
(249076, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284561;
INSERT INTO creature_addon VALUES 
(284561, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249454;
INSERT INTO creature_addon VALUES 
(249454, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284570;
INSERT INTO creature_addon VALUES 
(284570, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284571;
INSERT INTO creature_addon VALUES 
(284571, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284573;
INSERT INTO creature_addon VALUES 
(284573, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249062;
INSERT INTO creature_addon VALUES 
(249062, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249070;
INSERT INTO creature_addon VALUES 
(249070, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284574;
INSERT INTO creature_addon VALUES 
(284574, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284575;
INSERT INTO creature_addon VALUES 
(284575, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249046;
INSERT INTO creature_addon VALUES 
(249046, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284576;
INSERT INTO creature_addon VALUES 
(284576, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284580;
INSERT INTO creature_addon VALUES 
(284580, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249072;
INSERT INTO creature_addon VALUES 
(249072, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249247;
INSERT INTO creature_addon VALUES 
(249247, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284584;
INSERT INTO creature_addon VALUES 
(284584, 0, 0, 50331648, 1, 420, "");

DELETE FROM creature_addon WHERE guid=249292;
INSERT INTO creature_addon VALUES 
(249292, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284587;
INSERT INTO creature_addon VALUES 
(284587, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284607;
INSERT INTO creature_addon VALUES 
(284607, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284608;
INSERT INTO creature_addon VALUES 
(284608, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249065;
INSERT INTO creature_addon VALUES 
(249065, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284613;
INSERT INTO creature_addon VALUES 
(284613, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284615;
INSERT INTO creature_addon VALUES 
(284615, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249080;
INSERT INTO creature_addon VALUES 
(249080, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284621;
INSERT INTO creature_addon VALUES 
(284621, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=249318;
INSERT INTO creature_addon VALUES 
(249318, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284630;
INSERT INTO creature_addon VALUES 
(284630, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284639;
INSERT INTO creature_addon VALUES 
(284639, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284640;
INSERT INTO creature_addon VALUES 
(284640, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=249296;
INSERT INTO creature_addon VALUES 
(249296, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284641;
INSERT INTO creature_addon VALUES 
(284641, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284642;
INSERT INTO creature_addon VALUES 
(284642, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249294;
INSERT INTO creature_addon VALUES 
(249294, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249235;
INSERT INTO creature_addon VALUES 
(249235, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284646;
INSERT INTO creature_addon VALUES 
(284646, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245974;
INSERT INTO creature_addon VALUES 
(245974, 0, 0, 1, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=245961;
INSERT INTO creature_addon VALUES 
(245961, 0, 0, 0, 1, 0, "76356");

DELETE FROM creature_addon WHERE guid=245751;
INSERT INTO creature_addon VALUES 
(245751, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=248902;
INSERT INTO creature_addon VALUES 
(248902, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245645;
INSERT INTO creature_addon VALUES 
(245645, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245649;
INSERT INTO creature_addon VALUES 
(245649, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245680;
INSERT INTO creature_addon VALUES 
(245680, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=284703;
INSERT INTO creature_addon VALUES 
(284703, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245704;
INSERT INTO creature_addon VALUES 
(245704, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284705;
INSERT INTO creature_addon VALUES 
(284705, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284710;
INSERT INTO creature_addon VALUES 
(284710, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245655;
INSERT INTO creature_addon VALUES 
(245655, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284717;
INSERT INTO creature_addon VALUES 
(284717, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245696;
INSERT INTO creature_addon VALUES 
(245696, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245708;
INSERT INTO creature_addon VALUES 
(245708, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245707;
INSERT INTO creature_addon VALUES 
(245707, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284723;
INSERT INTO creature_addon VALUES 
(284723, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245711;
INSERT INTO creature_addon VALUES 
(245711, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245688;
INSERT INTO creature_addon VALUES 
(245688, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245713;
INSERT INTO creature_addon VALUES 
(245713, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=248951;
INSERT INTO creature_addon VALUES 
(248951, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245682;
INSERT INTO creature_addon VALUES 
(245682, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245723;
INSERT INTO creature_addon VALUES 
(245723, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=245727;
INSERT INTO creature_addon VALUES 
(245727, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284737;
INSERT INTO creature_addon VALUES 
(284737, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284742;
INSERT INTO creature_addon VALUES 
(284742, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284743;
INSERT INTO creature_addon VALUES 
(284743, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=248950;
INSERT INTO creature_addon VALUES 
(248950, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245693;
INSERT INTO creature_addon VALUES 
(245693, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284744;
INSERT INTO creature_addon VALUES 
(284744, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245714;
INSERT INTO creature_addon VALUES 
(245714, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245701;
INSERT INTO creature_addon VALUES 
(245701, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284755;
INSERT INTO creature_addon VALUES 
(284755, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284757;
INSERT INTO creature_addon VALUES 
(284757, 0, 0, 0, 1, 234, "");

DELETE FROM creature_addon WHERE guid=284760;
INSERT INTO creature_addon VALUES 
(284760, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245668;
INSERT INTO creature_addon VALUES 
(245668, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284774;
INSERT INTO creature_addon VALUES 
(284774, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284797;
INSERT INTO creature_addon VALUES 
(284797, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=248901;
INSERT INTO creature_addon VALUES 
(248901, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=248947;
INSERT INTO creature_addon VALUES 
(248947, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245684;
INSERT INTO creature_addon VALUES 
(245684, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284799;
INSERT INTO creature_addon VALUES 
(284799, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245722;
INSERT INTO creature_addon VALUES 
(245722, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=284807;
INSERT INTO creature_addon VALUES 
(284807, 0, 0, 50331648, 1, 420, "");

DELETE FROM creature_addon WHERE guid=284809;
INSERT INTO creature_addon VALUES 
(284809, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284811;
INSERT INTO creature_addon VALUES 
(284811, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=248832;
INSERT INTO creature_addon VALUES 
(248832, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284832;
INSERT INTO creature_addon VALUES 
(284832, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245690;
INSERT INTO creature_addon VALUES 
(245690, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=6685;
INSERT INTO creature_addon VALUES 
(6685, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=7017;
INSERT INTO creature_addon VALUES 
(7017, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=7019;
INSERT INTO creature_addon VALUES 
(7019, 0, 0, 65536, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246669;
INSERT INTO creature_addon VALUES 
(246669, 0, 0, 0, 1, 0, "72126 72055");

DELETE FROM creature_addon WHERE guid=249616;
INSERT INTO creature_addon VALUES 
(249616, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=248348;
INSERT INTO creature_addon VALUES 
(248348, 0, 29681, 0, 1, 0, "");

DELETE FROM creature_addon WHERE guid=284845;
INSERT INTO creature_addon VALUES 
(284845, 0, 0, 0, 1, 0, "71423 89125");

DELETE FROM creature_addon WHERE guid=284849;
INSERT INTO creature_addon VALUES 
(284849, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247962;
INSERT INTO creature_addon VALUES 
(247962, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247949;
INSERT INTO creature_addon VALUES 
(247949, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247961;
INSERT INTO creature_addon VALUES 
(247961, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=284850;
INSERT INTO creature_addon VALUES 
(284850, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247965;
INSERT INTO creature_addon VALUES 
(247965, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=284851;
INSERT INTO creature_addon VALUES 
(284851, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=284852;
INSERT INTO creature_addon VALUES 
(284852, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=284853;
INSERT INTO creature_addon VALUES 
(284853, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247953;
INSERT INTO creature_addon VALUES 
(247953, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247952;
INSERT INTO creature_addon VALUES 
(247952, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247959;
INSERT INTO creature_addon VALUES 
(247959, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=284854;
INSERT INTO creature_addon VALUES 
(284854, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247948;
INSERT INTO creature_addon VALUES 
(247948, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247957;
INSERT INTO creature_addon VALUES 
(247957, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=247966;
INSERT INTO creature_addon VALUES 
(247966, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=284855;
INSERT INTO creature_addon VALUES 
(284855, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=249060;
INSERT INTO creature_addon VALUES 
(249060, 0, 0, 65536, 1, 0, "90366");

DELETE FROM creature_addon WHERE guid=284857;
INSERT INTO creature_addon VALUES 
(284857, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246224;
INSERT INTO creature_addon VALUES 
(246224, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246234;
INSERT INTO creature_addon VALUES 
(246234, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246253;
INSERT INTO creature_addon VALUES 
(246253, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284866;
INSERT INTO creature_addon VALUES 
(284866, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284867;
INSERT INTO creature_addon VALUES 
(284867, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246249;
INSERT INTO creature_addon VALUES 
(246249, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=247482;
INSERT INTO creature_addon VALUES 
(247482, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246241;
INSERT INTO creature_addon VALUES 
(246241, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284868;
INSERT INTO creature_addon VALUES 
(284868, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246232;
INSERT INTO creature_addon VALUES 
(246232, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246257;
INSERT INTO creature_addon VALUES 
(246257, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284870;
INSERT INTO creature_addon VALUES 
(284870, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246247;
INSERT INTO creature_addon VALUES 
(246247, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=284876;
INSERT INTO creature_addon VALUES 
(284876, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=249018;
INSERT INTO creature_addon VALUES 
(249018, 0, 0, 65536, 1, 0, "82022 82023");

DELETE FROM creature_addon WHERE guid=248436;
INSERT INTO creature_addon VALUES 
(248436, 0, 0, 0, 1, 0, "90814");

DELETE FROM creature_addon WHERE guid=245652;
INSERT INTO creature_addon VALUES 
(245652, 0, 0, 0, 1, 0, "90816");

DELETE FROM creature_addon WHERE guid=248437;
INSERT INTO creature_addon VALUES 
(248437, 0, 0, 0, 1, 0, "90818");

DELETE FROM creature_addon WHERE guid=48844;
INSERT INTO creature_addon VALUES 
(48844, 0, 29681, 0, 1, 0, "");

DELETE FROM creature_addon WHERE guid=958;
INSERT INTO creature_addon VALUES 
(958, 0, 0, 0, 1, 0, "13787 74036");

DELETE FROM creature_addon WHERE guid=954;
INSERT INTO creature_addon VALUES 
(954, 0, 0, 0, 1, 0, "13787 74036");

DELETE FROM creature_addon WHERE guid=957;
INSERT INTO creature_addon VALUES 
(957, 0, 0, 0, 1, 375, "13787 74036");

DELETE FROM creature_addon WHERE guid=959;
INSERT INTO creature_addon VALUES 
(959, 0, 0, 0, 1, 0, "13787 74036");

DELETE FROM creature_addon WHERE guid=284880;
INSERT INTO creature_addon VALUES 
(284880, 0, 0, 0, 1, 0, "13787 74036");

DELETE FROM creature_addon WHERE guid=1789;
INSERT INTO creature_addon VALUES 
(1789, 0, 0, 0, 1, 0, "74038 79058");

DELETE FROM creature_addon WHERE guid=1787;
INSERT INTO creature_addon VALUES 
(1787, 0, 0, 0, 1, 375, "74038 79058");

DELETE FROM creature_addon WHERE guid=1788;
INSERT INTO creature_addon VALUES 
(1788, 0, 0, 0, 1, 0, "74038 79058");

DELETE FROM creature_addon WHERE guid=245296;
INSERT INTO creature_addon VALUES 
(245296, 0, 0, 0, 1, 0, "74038 79058");

DELETE FROM creature_addon WHERE guid=1850;
INSERT INTO creature_addon VALUES 
(1850, 0, 0, 0, 1, 0, "12550 78273 79058");

DELETE FROM creature_addon WHERE guid=1848;
INSERT INTO creature_addon VALUES 
(1848, 0, 0, 0, 1, 0, "12550 78273 79058");

DELETE FROM creature_addon WHERE guid=1849;
INSERT INTO creature_addon VALUES 
(1849, 0, 0, 0, 1, 333, "12550 78273 79058");

DELETE FROM creature_addon WHERE guid=1817;
INSERT INTO creature_addon VALUES 
(1817, 0, 0, 0, 1, 0, "13864");

DELETE FROM creature_addon WHERE guid=1816;
INSERT INTO creature_addon VALUES 
(1816, 0, 0, 0, 1, 375, "13864");

DELETE FROM creature_addon WHERE guid=245291;
INSERT INTO creature_addon VALUES 
(245291, 0, 0, 0, 1, 0, "13864");

DELETE FROM creature_addon WHERE guid=1993;
INSERT INTO creature_addon VALUES 
(1993, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=1906;
INSERT INTO creature_addon VALUES 
(1906, 0, 0, 0, 285212673, 0, "7165");

DELETE FROM creature_addon WHERE guid=1905;
INSERT INTO creature_addon VALUES 
(1905, 0, 0, 0, 1, 0, "7165");

DELETE FROM creature_addon WHERE guid=1904;
INSERT INTO creature_addon VALUES 
(1904, 0, 0, 0, 285212673, 0, "7165");

DELETE FROM creature_addon WHERE guid=245292;
INSERT INTO creature_addon VALUES 
(245292, 0, 0, 0, 285212673, 0, "7165");

DELETE FROM creature_addon WHERE guid=284896;
INSERT INTO creature_addon VALUES 
(284896, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245813;
INSERT INTO creature_addon VALUES 
(245813, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245809;
INSERT INTO creature_addon VALUES 
(245809, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=284900;
INSERT INTO creature_addon VALUES 
(284900, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245420;
INSERT INTO creature_addon VALUES 
(245420, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=284901;
INSERT INTO creature_addon VALUES 
(284901, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245455;
INSERT INTO creature_addon VALUES 
(245455, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245430;
INSERT INTO creature_addon VALUES 
(245430, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245426;
INSERT INTO creature_addon VALUES 
(245426, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245456;
INSERT INTO creature_addon VALUES 
(245456, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=284902;
INSERT INTO creature_addon VALUES 
(284902, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245443;
INSERT INTO creature_addon VALUES 
(245443, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=284903;
INSERT INTO creature_addon VALUES 
(284903, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=284905;
INSERT INTO creature_addon VALUES 
(284905, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245440;
INSERT INTO creature_addon VALUES 
(245440, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=284907;
INSERT INTO creature_addon VALUES 
(284907, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=284904;
INSERT INTO creature_addon VALUES 
(284904, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245448;
INSERT INTO creature_addon VALUES 
(245448, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=284909;
INSERT INTO creature_addon VALUES 
(284909, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=284913;
INSERT INTO creature_addon VALUES 
(284913, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=284914;
INSERT INTO creature_addon VALUES 
(284914, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=284915;
INSERT INTO creature_addon VALUES 
(284915, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=284912;
INSERT INTO creature_addon VALUES 
(284912, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245435;
INSERT INTO creature_addon VALUES 
(245435, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=284916;
INSERT INTO creature_addon VALUES 
(284916, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=284898;
INSERT INTO creature_addon VALUES 
(284898, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245790;
INSERT INTO creature_addon VALUES 
(245790, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=284918;
INSERT INTO creature_addon VALUES 
(284918, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284919;
INSERT INTO creature_addon VALUES 
(284919, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248518;
INSERT INTO creature_addon VALUES 
(248518, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284920;
INSERT INTO creature_addon VALUES 
(284920, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284921;
INSERT INTO creature_addon VALUES 
(284921, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284922;
INSERT INTO creature_addon VALUES 
(284922, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284923;
INSERT INTO creature_addon VALUES 
(284923, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284924;
INSERT INTO creature_addon VALUES 
(284924, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284925;
INSERT INTO creature_addon VALUES 
(284925, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284926;
INSERT INTO creature_addon VALUES 
(284926, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284927;
INSERT INTO creature_addon VALUES 
(284927, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284928;
INSERT INTO creature_addon VALUES 
(284928, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284929;
INSERT INTO creature_addon VALUES 
(284929, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284930;
INSERT INTO creature_addon VALUES 
(284930, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284931;
INSERT INTO creature_addon VALUES 
(284931, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284932;
INSERT INTO creature_addon VALUES 
(284932, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284933;
INSERT INTO creature_addon VALUES 
(284933, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284934;
INSERT INTO creature_addon VALUES 
(284934, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284935;
INSERT INTO creature_addon VALUES 
(284935, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284936;
INSERT INTO creature_addon VALUES 
(284936, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284937;
INSERT INTO creature_addon VALUES 
(284937, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284938;
INSERT INTO creature_addon VALUES 
(284938, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284939;
INSERT INTO creature_addon VALUES 
(284939, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284940;
INSERT INTO creature_addon VALUES 
(284940, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284941;
INSERT INTO creature_addon VALUES 
(284941, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284942;
INSERT INTO creature_addon VALUES 
(284942, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284943;
INSERT INTO creature_addon VALUES 
(284943, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284944;
INSERT INTO creature_addon VALUES 
(284944, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284945;
INSERT INTO creature_addon VALUES 
(284945, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284946;
INSERT INTO creature_addon VALUES 
(284946, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284947;
INSERT INTO creature_addon VALUES 
(284947, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284948;
INSERT INTO creature_addon VALUES 
(284948, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284949;
INSERT INTO creature_addon VALUES 
(284949, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284950;
INSERT INTO creature_addon VALUES 
(284950, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284951;
INSERT INTO creature_addon VALUES 
(284951, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248791;
INSERT INTO creature_addon VALUES 
(248791, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284952;
INSERT INTO creature_addon VALUES 
(284952, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248777;
INSERT INTO creature_addon VALUES 
(248777, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284953;
INSERT INTO creature_addon VALUES 
(284953, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284954;
INSERT INTO creature_addon VALUES 
(284954, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284955;
INSERT INTO creature_addon VALUES 
(284955, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284956;
INSERT INTO creature_addon VALUES 
(284956, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284957;
INSERT INTO creature_addon VALUES 
(284957, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284958;
INSERT INTO creature_addon VALUES 
(284958, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284959;
INSERT INTO creature_addon VALUES 
(284959, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284960;
INSERT INTO creature_addon VALUES 
(284960, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284961;
INSERT INTO creature_addon VALUES 
(284961, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248793;
INSERT INTO creature_addon VALUES 
(248793, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284962;
INSERT INTO creature_addon VALUES 
(284962, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248789;
INSERT INTO creature_addon VALUES 
(248789, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248795;
INSERT INTO creature_addon VALUES 
(248795, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284963;
INSERT INTO creature_addon VALUES 
(284963, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284964;
INSERT INTO creature_addon VALUES 
(284964, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284965;
INSERT INTO creature_addon VALUES 
(284965, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284966;
INSERT INTO creature_addon VALUES 
(284966, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284967;
INSERT INTO creature_addon VALUES 
(284967, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248389;
INSERT INTO creature_addon VALUES 
(248389, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248780;
INSERT INTO creature_addon VALUES 
(248780, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284968;
INSERT INTO creature_addon VALUES 
(284968, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284969;
INSERT INTO creature_addon VALUES 
(284969, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284970;
INSERT INTO creature_addon VALUES 
(284970, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284971;
INSERT INTO creature_addon VALUES 
(284971, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284972;
INSERT INTO creature_addon VALUES 
(284972, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284973;
INSERT INTO creature_addon VALUES 
(284973, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284974;
INSERT INTO creature_addon VALUES 
(284974, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284975;
INSERT INTO creature_addon VALUES 
(284975, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284976;
INSERT INTO creature_addon VALUES 
(284976, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284977;
INSERT INTO creature_addon VALUES 
(284977, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284978;
INSERT INTO creature_addon VALUES 
(284978, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284979;
INSERT INTO creature_addon VALUES 
(284979, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284980;
INSERT INTO creature_addon VALUES 
(284980, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284981;
INSERT INTO creature_addon VALUES 
(284981, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284982;
INSERT INTO creature_addon VALUES 
(284982, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284983;
INSERT INTO creature_addon VALUES 
(284983, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284984;
INSERT INTO creature_addon VALUES 
(284984, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284985;
INSERT INTO creature_addon VALUES 
(284985, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248390;
INSERT INTO creature_addon VALUES 
(248390, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284986;
INSERT INTO creature_addon VALUES 
(284986, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284987;
INSERT INTO creature_addon VALUES 
(284987, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284988;
INSERT INTO creature_addon VALUES 
(284988, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284989;
INSERT INTO creature_addon VALUES 
(284989, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284990;
INSERT INTO creature_addon VALUES 
(284990, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284991;
INSERT INTO creature_addon VALUES 
(284991, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284992;
INSERT INTO creature_addon VALUES 
(284992, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284993;
INSERT INTO creature_addon VALUES 
(284993, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248792;
INSERT INTO creature_addon VALUES 
(248792, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284994;
INSERT INTO creature_addon VALUES 
(284994, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284995;
INSERT INTO creature_addon VALUES 
(284995, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284996;
INSERT INTO creature_addon VALUES 
(284996, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284997;
INSERT INTO creature_addon VALUES 
(284997, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284998;
INSERT INTO creature_addon VALUES 
(284998, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=284999;
INSERT INTO creature_addon VALUES 
(284999, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285000;
INSERT INTO creature_addon VALUES 
(285000, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285001;
INSERT INTO creature_addon VALUES 
(285001, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285002;
INSERT INTO creature_addon VALUES 
(285002, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285003;
INSERT INTO creature_addon VALUES 
(285003, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285004;
INSERT INTO creature_addon VALUES 
(285004, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285005;
INSERT INTO creature_addon VALUES 
(285005, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285006;
INSERT INTO creature_addon VALUES 
(285006, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285007;
INSERT INTO creature_addon VALUES 
(285007, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285008;
INSERT INTO creature_addon VALUES 
(285008, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285009;
INSERT INTO creature_addon VALUES 
(285009, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285010;
INSERT INTO creature_addon VALUES 
(285010, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285011;
INSERT INTO creature_addon VALUES 
(285011, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285012;
INSERT INTO creature_addon VALUES 
(285012, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285013;
INSERT INTO creature_addon VALUES 
(285013, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285014;
INSERT INTO creature_addon VALUES 
(285014, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285015;
INSERT INTO creature_addon VALUES 
(285015, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285016;
INSERT INTO creature_addon VALUES 
(285016, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285017;
INSERT INTO creature_addon VALUES 
(285017, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248378;
INSERT INTO creature_addon VALUES 
(248378, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248377;
INSERT INTO creature_addon VALUES 
(248377, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285018;
INSERT INTO creature_addon VALUES 
(285018, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285019;
INSERT INTO creature_addon VALUES 
(285019, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285020;
INSERT INTO creature_addon VALUES 
(285020, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285021;
INSERT INTO creature_addon VALUES 
(285021, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285022;
INSERT INTO creature_addon VALUES 
(285022, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285023;
INSERT INTO creature_addon VALUES 
(285023, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285024;
INSERT INTO creature_addon VALUES 
(285024, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285025;
INSERT INTO creature_addon VALUES 
(285025, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285026;
INSERT INTO creature_addon VALUES 
(285026, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285027;
INSERT INTO creature_addon VALUES 
(285027, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285028;
INSERT INTO creature_addon VALUES 
(285028, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285029;
INSERT INTO creature_addon VALUES 
(285029, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285030;
INSERT INTO creature_addon VALUES 
(285030, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285031;
INSERT INTO creature_addon VALUES 
(285031, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285032;
INSERT INTO creature_addon VALUES 
(285032, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285033;
INSERT INTO creature_addon VALUES 
(285033, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285034;
INSERT INTO creature_addon VALUES 
(285034, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285035;
INSERT INTO creature_addon VALUES 
(285035, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285036;
INSERT INTO creature_addon VALUES 
(285036, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285037;
INSERT INTO creature_addon VALUES 
(285037, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=246406;
INSERT INTO creature_addon VALUES 
(246406, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285038;
INSERT INTO creature_addon VALUES 
(285038, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285039;
INSERT INTO creature_addon VALUES 
(285039, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285040;
INSERT INTO creature_addon VALUES 
(285040, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285041;
INSERT INTO creature_addon VALUES 
(285041, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285042;
INSERT INTO creature_addon VALUES 
(285042, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285043;
INSERT INTO creature_addon VALUES 
(285043, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285044;
INSERT INTO creature_addon VALUES 
(285044, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285045;
INSERT INTO creature_addon VALUES 
(285045, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285046;
INSERT INTO creature_addon VALUES 
(285046, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285047;
INSERT INTO creature_addon VALUES 
(285047, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285048;
INSERT INTO creature_addon VALUES 
(285048, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285049;
INSERT INTO creature_addon VALUES 
(285049, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285050;
INSERT INTO creature_addon VALUES 
(285050, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285051;
INSERT INTO creature_addon VALUES 
(285051, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285052;
INSERT INTO creature_addon VALUES 
(285052, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285053;
INSERT INTO creature_addon VALUES 
(285053, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285054;
INSERT INTO creature_addon VALUES 
(285054, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285055;
INSERT INTO creature_addon VALUES 
(285055, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285056;
INSERT INTO creature_addon VALUES 
(285056, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285057;
INSERT INTO creature_addon VALUES 
(285057, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285058;
INSERT INTO creature_addon VALUES 
(285058, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285059;
INSERT INTO creature_addon VALUES 
(285059, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285060;
INSERT INTO creature_addon VALUES 
(285060, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285061;
INSERT INTO creature_addon VALUES 
(285061, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285062;
INSERT INTO creature_addon VALUES 
(285062, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285063;
INSERT INTO creature_addon VALUES 
(285063, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285064;
INSERT INTO creature_addon VALUES 
(285064, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285065;
INSERT INTO creature_addon VALUES 
(285065, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285066;
INSERT INTO creature_addon VALUES 
(285066, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285067;
INSERT INTO creature_addon VALUES 
(285067, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285068;
INSERT INTO creature_addon VALUES 
(285068, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285069;
INSERT INTO creature_addon VALUES 
(285069, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285070;
INSERT INTO creature_addon VALUES 
(285070, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285071;
INSERT INTO creature_addon VALUES 
(285071, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285072;
INSERT INTO creature_addon VALUES 
(285072, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285073;
INSERT INTO creature_addon VALUES 
(285073, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285074;
INSERT INTO creature_addon VALUES 
(285074, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285075;
INSERT INTO creature_addon VALUES 
(285075, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285076;
INSERT INTO creature_addon VALUES 
(285076, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285077;
INSERT INTO creature_addon VALUES 
(285077, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285078;
INSERT INTO creature_addon VALUES 
(285078, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285079;
INSERT INTO creature_addon VALUES 
(285079, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285080;
INSERT INTO creature_addon VALUES 
(285080, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285081;
INSERT INTO creature_addon VALUES 
(285081, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285082;
INSERT INTO creature_addon VALUES 
(285082, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285083;
INSERT INTO creature_addon VALUES 
(285083, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285084;
INSERT INTO creature_addon VALUES 
(285084, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285085;
INSERT INTO creature_addon VALUES 
(285085, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285086;
INSERT INTO creature_addon VALUES 
(285086, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285087;
INSERT INTO creature_addon VALUES 
(285087, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285088;
INSERT INTO creature_addon VALUES 
(285088, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285089;
INSERT INTO creature_addon VALUES 
(285089, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285090;
INSERT INTO creature_addon VALUES 
(285090, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285091;
INSERT INTO creature_addon VALUES 
(285091, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285092;
INSERT INTO creature_addon VALUES 
(285092, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285093;
INSERT INTO creature_addon VALUES 
(285093, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285094;
INSERT INTO creature_addon VALUES 
(285094, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285095;
INSERT INTO creature_addon VALUES 
(285095, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285096;
INSERT INTO creature_addon VALUES 
(285096, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285097;
INSERT INTO creature_addon VALUES 
(285097, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285098;
INSERT INTO creature_addon VALUES 
(285098, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285099;
INSERT INTO creature_addon VALUES 
(285099, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285100;
INSERT INTO creature_addon VALUES 
(285100, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285101;
INSERT INTO creature_addon VALUES 
(285101, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285102;
INSERT INTO creature_addon VALUES 
(285102, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285103;
INSERT INTO creature_addon VALUES 
(285103, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285104;
INSERT INTO creature_addon VALUES 
(285104, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285105;
INSERT INTO creature_addon VALUES 
(285105, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285106;
INSERT INTO creature_addon VALUES 
(285106, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285107;
INSERT INTO creature_addon VALUES 
(285107, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285108;
INSERT INTO creature_addon VALUES 
(285108, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285109;
INSERT INTO creature_addon VALUES 
(285109, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285110;
INSERT INTO creature_addon VALUES 
(285110, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285111;
INSERT INTO creature_addon VALUES 
(285111, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285112;
INSERT INTO creature_addon VALUES 
(285112, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285113;
INSERT INTO creature_addon VALUES 
(285113, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285114;
INSERT INTO creature_addon VALUES 
(285114, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285115;
INSERT INTO creature_addon VALUES 
(285115, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285116;
INSERT INTO creature_addon VALUES 
(285116, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285117;
INSERT INTO creature_addon VALUES 
(285117, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285118;
INSERT INTO creature_addon VALUES 
(285118, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285119;
INSERT INTO creature_addon VALUES 
(285119, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285120;
INSERT INTO creature_addon VALUES 
(285120, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285121;
INSERT INTO creature_addon VALUES 
(285121, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285122;
INSERT INTO creature_addon VALUES 
(285122, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285123;
INSERT INTO creature_addon VALUES 
(285123, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285124;
INSERT INTO creature_addon VALUES 
(285124, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285125;
INSERT INTO creature_addon VALUES 
(285125, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285126;
INSERT INTO creature_addon VALUES 
(285126, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285127;
INSERT INTO creature_addon VALUES 
(285127, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285128;
INSERT INTO creature_addon VALUES 
(285128, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285129;
INSERT INTO creature_addon VALUES 
(285129, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285130;
INSERT INTO creature_addon VALUES 
(285130, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285131;
INSERT INTO creature_addon VALUES 
(285131, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285132;
INSERT INTO creature_addon VALUES 
(285132, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285133;
INSERT INTO creature_addon VALUES 
(285133, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285134;
INSERT INTO creature_addon VALUES 
(285134, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285135;
INSERT INTO creature_addon VALUES 
(285135, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285136;
INSERT INTO creature_addon VALUES 
(285136, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285137;
INSERT INTO creature_addon VALUES 
(285137, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285138;
INSERT INTO creature_addon VALUES 
(285138, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285139;
INSERT INTO creature_addon VALUES 
(285139, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285140;
INSERT INTO creature_addon VALUES 
(285140, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285141;
INSERT INTO creature_addon VALUES 
(285141, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285142;
INSERT INTO creature_addon VALUES 
(285142, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285143;
INSERT INTO creature_addon VALUES 
(285143, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285144;
INSERT INTO creature_addon VALUES 
(285144, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285145;
INSERT INTO creature_addon VALUES 
(285145, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285146;
INSERT INTO creature_addon VALUES 
(285146, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285147;
INSERT INTO creature_addon VALUES 
(285147, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285148;
INSERT INTO creature_addon VALUES 
(285148, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285149;
INSERT INTO creature_addon VALUES 
(285149, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285150;
INSERT INTO creature_addon VALUES 
(285150, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285151;
INSERT INTO creature_addon VALUES 
(285151, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285152;
INSERT INTO creature_addon VALUES 
(285152, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285153;
INSERT INTO creature_addon VALUES 
(285153, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285154;
INSERT INTO creature_addon VALUES 
(285154, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285155;
INSERT INTO creature_addon VALUES 
(285155, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285156;
INSERT INTO creature_addon VALUES 
(285156, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285157;
INSERT INTO creature_addon VALUES 
(285157, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285158;
INSERT INTO creature_addon VALUES 
(285158, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285159;
INSERT INTO creature_addon VALUES 
(285159, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285160;
INSERT INTO creature_addon VALUES 
(285160, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285161;
INSERT INTO creature_addon VALUES 
(285161, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285162;
INSERT INTO creature_addon VALUES 
(285162, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285163;
INSERT INTO creature_addon VALUES 
(285163, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285164;
INSERT INTO creature_addon VALUES 
(285164, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285165;
INSERT INTO creature_addon VALUES 
(285165, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285166;
INSERT INTO creature_addon VALUES 
(285166, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285167;
INSERT INTO creature_addon VALUES 
(285167, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285168;
INSERT INTO creature_addon VALUES 
(285168, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285169;
INSERT INTO creature_addon VALUES 
(285169, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285170;
INSERT INTO creature_addon VALUES 
(285170, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285171;
INSERT INTO creature_addon VALUES 
(285171, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285172;
INSERT INTO creature_addon VALUES 
(285172, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285173;
INSERT INTO creature_addon VALUES 
(285173, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285174;
INSERT INTO creature_addon VALUES 
(285174, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285175;
INSERT INTO creature_addon VALUES 
(285175, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285176;
INSERT INTO creature_addon VALUES 
(285176, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285177;
INSERT INTO creature_addon VALUES 
(285177, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285178;
INSERT INTO creature_addon VALUES 
(285178, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285179;
INSERT INTO creature_addon VALUES 
(285179, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285180;
INSERT INTO creature_addon VALUES 
(285180, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285181;
INSERT INTO creature_addon VALUES 
(285181, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285182;
INSERT INTO creature_addon VALUES 
(285182, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285183;
INSERT INTO creature_addon VALUES 
(285183, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285184;
INSERT INTO creature_addon VALUES 
(285184, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285185;
INSERT INTO creature_addon VALUES 
(285185, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285186;
INSERT INTO creature_addon VALUES 
(285186, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285187;
INSERT INTO creature_addon VALUES 
(285187, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285188;
INSERT INTO creature_addon VALUES 
(285188, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285189;
INSERT INTO creature_addon VALUES 
(285189, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285190;
INSERT INTO creature_addon VALUES 
(285190, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285191;
INSERT INTO creature_addon VALUES 
(285191, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285192;
INSERT INTO creature_addon VALUES 
(285192, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285193;
INSERT INTO creature_addon VALUES 
(285193, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285194;
INSERT INTO creature_addon VALUES 
(285194, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285195;
INSERT INTO creature_addon VALUES 
(285195, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285196;
INSERT INTO creature_addon VALUES 
(285196, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285197;
INSERT INTO creature_addon VALUES 
(285197, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285198;
INSERT INTO creature_addon VALUES 
(285198, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285199;
INSERT INTO creature_addon VALUES 
(285199, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285200;
INSERT INTO creature_addon VALUES 
(285200, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285201;
INSERT INTO creature_addon VALUES 
(285201, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285202;
INSERT INTO creature_addon VALUES 
(285202, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285203;
INSERT INTO creature_addon VALUES 
(285203, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285204;
INSERT INTO creature_addon VALUES 
(285204, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285205;
INSERT INTO creature_addon VALUES 
(285205, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285206;
INSERT INTO creature_addon VALUES 
(285206, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285207;
INSERT INTO creature_addon VALUES 
(285207, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285208;
INSERT INTO creature_addon VALUES 
(285208, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285209;
INSERT INTO creature_addon VALUES 
(285209, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285210;
INSERT INTO creature_addon VALUES 
(285210, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285211;
INSERT INTO creature_addon VALUES 
(285211, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285212;
INSERT INTO creature_addon VALUES 
(285212, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285213;
INSERT INTO creature_addon VALUES 
(285213, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285214;
INSERT INTO creature_addon VALUES 
(285214, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285215;
INSERT INTO creature_addon VALUES 
(285215, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285216;
INSERT INTO creature_addon VALUES 
(285216, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285217;
INSERT INTO creature_addon VALUES 
(285217, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285218;
INSERT INTO creature_addon VALUES 
(285218, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285219;
INSERT INTO creature_addon VALUES 
(285219, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285220;
INSERT INTO creature_addon VALUES 
(285220, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285221;
INSERT INTO creature_addon VALUES 
(285221, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285222;
INSERT INTO creature_addon VALUES 
(285222, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285223;
INSERT INTO creature_addon VALUES 
(285223, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285224;
INSERT INTO creature_addon VALUES 
(285224, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285225;
INSERT INTO creature_addon VALUES 
(285225, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285226;
INSERT INTO creature_addon VALUES 
(285226, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248794;
INSERT INTO creature_addon VALUES 
(248794, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285227;
INSERT INTO creature_addon VALUES 
(285227, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285228;
INSERT INTO creature_addon VALUES 
(285228, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285229;
INSERT INTO creature_addon VALUES 
(285229, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285230;
INSERT INTO creature_addon VALUES 
(285230, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285231;
INSERT INTO creature_addon VALUES 
(285231, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248351;
INSERT INTO creature_addon VALUES 
(248351, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285232;
INSERT INTO creature_addon VALUES 
(285232, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285233;
INSERT INTO creature_addon VALUES 
(285233, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285234;
INSERT INTO creature_addon VALUES 
(285234, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285235;
INSERT INTO creature_addon VALUES 
(285235, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285236;
INSERT INTO creature_addon VALUES 
(285236, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285237;
INSERT INTO creature_addon VALUES 
(285237, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285238;
INSERT INTO creature_addon VALUES 
(285238, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285239;
INSERT INTO creature_addon VALUES 
(285239, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285240;
INSERT INTO creature_addon VALUES 
(285240, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285241;
INSERT INTO creature_addon VALUES 
(285241, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285242;
INSERT INTO creature_addon VALUES 
(285242, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285243;
INSERT INTO creature_addon VALUES 
(285243, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285244;
INSERT INTO creature_addon VALUES 
(285244, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285245;
INSERT INTO creature_addon VALUES 
(285245, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285246;
INSERT INTO creature_addon VALUES 
(285246, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285247;
INSERT INTO creature_addon VALUES 
(285247, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285248;
INSERT INTO creature_addon VALUES 
(285248, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285249;
INSERT INTO creature_addon VALUES 
(285249, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285250;
INSERT INTO creature_addon VALUES 
(285250, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285251;
INSERT INTO creature_addon VALUES 
(285251, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285252;
INSERT INTO creature_addon VALUES 
(285252, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285253;
INSERT INTO creature_addon VALUES 
(285253, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285254;
INSERT INTO creature_addon VALUES 
(285254, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248371;
INSERT INTO creature_addon VALUES 
(248371, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285255;
INSERT INTO creature_addon VALUES 
(285255, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285256;
INSERT INTO creature_addon VALUES 
(285256, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285257;
INSERT INTO creature_addon VALUES 
(285257, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285258;
INSERT INTO creature_addon VALUES 
(285258, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285259;
INSERT INTO creature_addon VALUES 
(285259, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285260;
INSERT INTO creature_addon VALUES 
(285260, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285261;
INSERT INTO creature_addon VALUES 
(285261, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285262;
INSERT INTO creature_addon VALUES 
(285262, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285263;
INSERT INTO creature_addon VALUES 
(285263, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=246405;
INSERT INTO creature_addon VALUES 
(246405, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285264;
INSERT INTO creature_addon VALUES 
(285264, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248382;
INSERT INTO creature_addon VALUES 
(248382, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285265;
INSERT INTO creature_addon VALUES 
(285265, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285266;
INSERT INTO creature_addon VALUES 
(285266, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285267;
INSERT INTO creature_addon VALUES 
(285267, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285268;
INSERT INTO creature_addon VALUES 
(285268, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285269;
INSERT INTO creature_addon VALUES 
(285269, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285270;
INSERT INTO creature_addon VALUES 
(285270, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285271;
INSERT INTO creature_addon VALUES 
(285271, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285272;
INSERT INTO creature_addon VALUES 
(285272, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285273;
INSERT INTO creature_addon VALUES 
(285273, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285274;
INSERT INTO creature_addon VALUES 
(285274, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285275;
INSERT INTO creature_addon VALUES 
(285275, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285276;
INSERT INTO creature_addon VALUES 
(285276, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285277;
INSERT INTO creature_addon VALUES 
(285277, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285278;
INSERT INTO creature_addon VALUES 
(285278, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285279;
INSERT INTO creature_addon VALUES 
(285279, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285280;
INSERT INTO creature_addon VALUES 
(285280, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285281;
INSERT INTO creature_addon VALUES 
(285281, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=248381;
INSERT INTO creature_addon VALUES 
(248381, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285282;
INSERT INTO creature_addon VALUES 
(285282, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285283;
INSERT INTO creature_addon VALUES 
(285283, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285284;
INSERT INTO creature_addon VALUES 
(285284, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285285;
INSERT INTO creature_addon VALUES 
(285285, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285286;
INSERT INTO creature_addon VALUES 
(285286, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285287;
INSERT INTO creature_addon VALUES 
(285287, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285288;
INSERT INTO creature_addon VALUES 
(285288, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285289;
INSERT INTO creature_addon VALUES 
(285289, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285290;
INSERT INTO creature_addon VALUES 
(285290, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285291;
INSERT INTO creature_addon VALUES 
(285291, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285292;
INSERT INTO creature_addon VALUES 
(285292, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=246402;
INSERT INTO creature_addon VALUES 
(246402, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285293;
INSERT INTO creature_addon VALUES 
(285293, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285294;
INSERT INTO creature_addon VALUES 
(285294, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285295;
INSERT INTO creature_addon VALUES 
(285295, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285296;
INSERT INTO creature_addon VALUES 
(285296, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285297;
INSERT INTO creature_addon VALUES 
(285297, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285298;
INSERT INTO creature_addon VALUES 
(285298, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285299;
INSERT INTO creature_addon VALUES 
(285299, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285300;
INSERT INTO creature_addon VALUES 
(285300, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=246412;
INSERT INTO creature_addon VALUES 
(246412, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285301;
INSERT INTO creature_addon VALUES 
(285301, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285302;
INSERT INTO creature_addon VALUES 
(285302, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285303;
INSERT INTO creature_addon VALUES 
(285303, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285304;
INSERT INTO creature_addon VALUES 
(285304, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285305;
INSERT INTO creature_addon VALUES 
(285305, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285306;
INSERT INTO creature_addon VALUES 
(285306, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285307;
INSERT INTO creature_addon VALUES 
(285307, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285308;
INSERT INTO creature_addon VALUES 
(285308, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285309;
INSERT INTO creature_addon VALUES 
(285309, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285310;
INSERT INTO creature_addon VALUES 
(285310, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285311;
INSERT INTO creature_addon VALUES 
(285311, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285312;
INSERT INTO creature_addon VALUES 
(285312, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285313;
INSERT INTO creature_addon VALUES 
(285313, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285314;
INSERT INTO creature_addon VALUES 
(285314, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285315;
INSERT INTO creature_addon VALUES 
(285315, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285317;
INSERT INTO creature_addon VALUES 
(285317, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285318;
INSERT INTO creature_addon VALUES 
(285318, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285319;
INSERT INTO creature_addon VALUES 
(285319, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285320;
INSERT INTO creature_addon VALUES 
(285320, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285321;
INSERT INTO creature_addon VALUES 
(285321, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285322;
INSERT INTO creature_addon VALUES 
(285322, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285323;
INSERT INTO creature_addon VALUES 
(285323, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285324;
INSERT INTO creature_addon VALUES 
(285324, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285325;
INSERT INTO creature_addon VALUES 
(285325, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285326;
INSERT INTO creature_addon VALUES 
(285326, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285327;
INSERT INTO creature_addon VALUES 
(285327, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=246413;
INSERT INTO creature_addon VALUES 
(246413, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285328;
INSERT INTO creature_addon VALUES 
(285328, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285329;
INSERT INTO creature_addon VALUES 
(285329, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285330;
INSERT INTO creature_addon VALUES 
(285330, 0, 0, 0, 1, 0, "29266 71333");

DELETE FROM creature_addon WHERE guid=285331;
INSERT INTO creature_addon VALUES 
(285331, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245799;
INSERT INTO creature_addon VALUES 
(245799, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=285334;
INSERT INTO creature_addon VALUES 
(285334, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=285335;
INSERT INTO creature_addon VALUES 
(285335, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285337;
INSERT INTO creature_addon VALUES 
(285337, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245427;
INSERT INTO creature_addon VALUES 
(245427, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285338;
INSERT INTO creature_addon VALUES 
(285338, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245422;
INSERT INTO creature_addon VALUES 
(245422, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245428;
INSERT INTO creature_addon VALUES 
(245428, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285340;
INSERT INTO creature_addon VALUES 
(285340, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285341;
INSERT INTO creature_addon VALUES 
(285341, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245450;
INSERT INTO creature_addon VALUES 
(245450, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245449;
INSERT INTO creature_addon VALUES 
(245449, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245441;
INSERT INTO creature_addon VALUES 
(245441, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285342;
INSERT INTO creature_addon VALUES 
(285342, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285344;
INSERT INTO creature_addon VALUES 
(285344, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245452;
INSERT INTO creature_addon VALUES 
(245452, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245282;
INSERT INTO creature_addon VALUES 
(245282, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245439;
INSERT INTO creature_addon VALUES 
(245439, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285346;
INSERT INTO creature_addon VALUES 
(285346, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285339;
INSERT INTO creature_addon VALUES 
(285339, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285348;
INSERT INTO creature_addon VALUES 
(285348, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285343;
INSERT INTO creature_addon VALUES 
(285343, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=245444;
INSERT INTO creature_addon VALUES 
(245444, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=285350;
INSERT INTO creature_addon VALUES 
(285350, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=245815;
INSERT INTO creature_addon VALUES 
(245815, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285351;
INSERT INTO creature_addon VALUES 
(285351, 0, 0, 0, 1, 423, "");

DELETE FROM creature_addon WHERE guid=285352;
INSERT INTO creature_addon VALUES 
(285352, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=285353;
INSERT INTO creature_addon VALUES 
(285353, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285354;
INSERT INTO creature_addon VALUES 
(285354, 0, 0, 0, 1, 69, "68327");

DELETE FROM creature_addon WHERE guid=285355;
INSERT INTO creature_addon VALUES 
(285355, 0, 0, 8, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285356;
INSERT INTO creature_addon VALUES 
(285356, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285357;
INSERT INTO creature_addon VALUES 
(285357, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=246045;
INSERT INTO creature_addon VALUES 
(246045, 0, 0, 0, 1, 234, "68327");

DELETE FROM creature_addon WHERE guid=285358;
INSERT INTO creature_addon VALUES 
(285358, 0, 0, 0, 1, 69, "68327");

DELETE FROM creature_addon WHERE guid=285377;
INSERT INTO creature_addon VALUES 
(285377, 0, 0, 65536, 1, 0, "10848");

DELETE FROM creature_addon WHERE guid=285378;
INSERT INTO creature_addon VALUES 
(285378, 0, 0, 65536, 1, 0, "10848");

DELETE FROM creature_addon WHERE guid=285379;
INSERT INTO creature_addon VALUES 
(285379, 0, 0, 65536, 1, 0, "10848");

DELETE FROM creature_addon WHERE guid=285380;
INSERT INTO creature_addon VALUES 
(285380, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285381;
INSERT INTO creature_addon VALUES 
(285381, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285382;
INSERT INTO creature_addon VALUES 
(285382, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285383;
INSERT INTO creature_addon VALUES 
(285383, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285384;
INSERT INTO creature_addon VALUES 
(285384, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285385;
INSERT INTO creature_addon VALUES 
(285385, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285386;
INSERT INTO creature_addon VALUES 
(285386, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285387;
INSERT INTO creature_addon VALUES 
(285387, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285388;
INSERT INTO creature_addon VALUES 
(285388, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285389;
INSERT INTO creature_addon VALUES 
(285389, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285390;
INSERT INTO creature_addon VALUES 
(285390, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285391;
INSERT INTO creature_addon VALUES 
(285391, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285392;
INSERT INTO creature_addon VALUES 
(285392, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285393;
INSERT INTO creature_addon VALUES 
(285393, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285394;
INSERT INTO creature_addon VALUES 
(285394, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285395;
INSERT INTO creature_addon VALUES 
(285395, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285396;
INSERT INTO creature_addon VALUES 
(285396, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285397;
INSERT INTO creature_addon VALUES 
(285397, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285398;
INSERT INTO creature_addon VALUES 
(285398, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285399;
INSERT INTO creature_addon VALUES 
(285399, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285400;
INSERT INTO creature_addon VALUES 
(285400, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285401;
INSERT INTO creature_addon VALUES 
(285401, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285402;
INSERT INTO creature_addon VALUES 
(285402, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285403;
INSERT INTO creature_addon VALUES 
(285403, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285404;
INSERT INTO creature_addon VALUES 
(285404, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285405;
INSERT INTO creature_addon VALUES 
(285405, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285406;
INSERT INTO creature_addon VALUES 
(285406, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285407;
INSERT INTO creature_addon VALUES 
(285407, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285408;
INSERT INTO creature_addon VALUES 
(285408, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285409;
INSERT INTO creature_addon VALUES 
(285409, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285410;
INSERT INTO creature_addon VALUES 
(285410, 0, 0, 0, 257, 0, "");

DELETE FROM creature_addon WHERE guid=285411;
INSERT INTO creature_addon VALUES 
(285411, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285414;
INSERT INTO creature_addon VALUES 
(285414, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245904;
INSERT INTO creature_addon VALUES 
(245904, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285415;
INSERT INTO creature_addon VALUES 
(285415, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285416;
INSERT INTO creature_addon VALUES 
(285416, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245907;
INSERT INTO creature_addon VALUES 
(245907, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285417;
INSERT INTO creature_addon VALUES 
(285417, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245902;
INSERT INTO creature_addon VALUES 
(245902, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285420;
INSERT INTO creature_addon VALUES 
(285420, 0, 25871, 0, 1, 416, "");

DELETE FROM creature_addon WHERE guid=285421;
INSERT INTO creature_addon VALUES 
(285421, 0, 25871, 0, 1, 416, "");

DELETE FROM creature_addon WHERE guid=245819;
INSERT INTO creature_addon VALUES 
(245819, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285422;
INSERT INTO creature_addon VALUES 
(285422, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285418;
INSERT INTO creature_addon VALUES 
(285418, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285423;
INSERT INTO creature_addon VALUES 
(285423, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245818;
INSERT INTO creature_addon VALUES 
(245818, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285424;
INSERT INTO creature_addon VALUES 
(285424, 0, 25871, 0, 1, 416, "");

DELETE FROM creature_addon WHERE guid=245900;
INSERT INTO creature_addon VALUES 
(245900, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245911;
INSERT INTO creature_addon VALUES 
(245911, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245910;
INSERT INTO creature_addon VALUES 
(245910, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285426;
INSERT INTO creature_addon VALUES 
(285426, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245912;
INSERT INTO creature_addon VALUES 
(245912, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285427;
INSERT INTO creature_addon VALUES 
(285427, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245909;
INSERT INTO creature_addon VALUES 
(245909, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245816;
INSERT INTO creature_addon VALUES 
(245816, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245908;
INSERT INTO creature_addon VALUES 
(245908, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245901;
INSERT INTO creature_addon VALUES 
(245901, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245903;
INSERT INTO creature_addon VALUES 
(245903, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285428;
INSERT INTO creature_addon VALUES 
(285428, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285429;
INSERT INTO creature_addon VALUES 
(285429, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=248759;
INSERT INTO creature_addon VALUES 
(248759, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285430;
INSERT INTO creature_addon VALUES 
(285430, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245803;
INSERT INTO creature_addon VALUES 
(245803, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=285431;
INSERT INTO creature_addon VALUES 
(285431, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=285432;
INSERT INTO creature_addon VALUES 
(285432, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245807;
INSERT INTO creature_addon VALUES 
(245807, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245804;
INSERT INTO creature_addon VALUES 
(245804, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=285434;
INSERT INTO creature_addon VALUES 
(285434, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=285435;
INSERT INTO creature_addon VALUES 
(285435, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245800;
INSERT INTO creature_addon VALUES 
(245800, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245806;
INSERT INTO creature_addon VALUES 
(245806, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=35504;
INSERT INTO creature_addon VALUES 
(35504, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36271;
INSERT INTO creature_addon VALUES 
(36271, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=35840;
INSERT INTO creature_addon VALUES 
(35840, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36393;
INSERT INTO creature_addon VALUES 
(36393, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36221;
INSERT INTO creature_addon VALUES 
(36221, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34528;
INSERT INTO creature_addon VALUES 
(34528, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=35445;
INSERT INTO creature_addon VALUES 
(35445, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36283;
INSERT INTO creature_addon VALUES 
(36283, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34449;
INSERT INTO creature_addon VALUES 
(34449, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36322;
INSERT INTO creature_addon VALUES 
(36322, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34508;
INSERT INTO creature_addon VALUES 
(34508, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34621;
INSERT INTO creature_addon VALUES 
(34621, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=35616;
INSERT INTO creature_addon VALUES 
(35616, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=35802;
INSERT INTO creature_addon VALUES 
(35802, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34500;
INSERT INTO creature_addon VALUES 
(34500, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36325;
INSERT INTO creature_addon VALUES 
(36325, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34775;
INSERT INTO creature_addon VALUES 
(34775, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=35706;
INSERT INTO creature_addon VALUES 
(35706, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34970;
INSERT INTO creature_addon VALUES 
(34970, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34494;
INSERT INTO creature_addon VALUES 
(34494, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34974;
INSERT INTO creature_addon VALUES 
(34974, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34498;
INSERT INTO creature_addon VALUES 
(34498, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34819;
INSERT INTO creature_addon VALUES 
(34819, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36350;
INSERT INTO creature_addon VALUES 
(36350, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36226;
INSERT INTO creature_addon VALUES 
(36226, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36397;
INSERT INTO creature_addon VALUES 
(36397, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36899;
INSERT INTO creature_addon VALUES 
(36899, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=36348;
INSERT INTO creature_addon VALUES 
(36348, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=34492;
INSERT INTO creature_addon VALUES 
(34492, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=249195;
INSERT INTO creature_addon VALUES 
(249195, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=249199;
INSERT INTO creature_addon VALUES 
(249199, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=249193;
INSERT INTO creature_addon VALUES 
(249193, 0, 0, 0, 1, 10, "");

DELETE FROM creature_addon WHERE guid=42279;
INSERT INTO creature_addon VALUES 
(42279, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=42284;
INSERT INTO creature_addon VALUES 
(42284, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=42740;
INSERT INTO creature_addon VALUES 
(42740, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=285463;
INSERT INTO creature_addon VALUES 
(285463, 0, 29681, 0, 1, 0, "");

DELETE FROM creature_addon WHERE guid=285464;
INSERT INTO creature_addon VALUES 
(285464, 0, 29681, 0, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245957;
INSERT INTO creature_addon VALUES 
(245957, 0, 29681, 0, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245822;
INSERT INTO creature_addon VALUES 
(245822, 0, 29681, 0, 1, 0, "");

DELETE FROM creature_addon WHERE guid=246518;
INSERT INTO creature_addon VALUES 
(246518, 0, 1244, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=246470;
INSERT INTO creature_addon VALUES 
(246470, 0, 1244, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=285465;
INSERT INTO creature_addon VALUES 
(285465, 0, 1244, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=246479;
INSERT INTO creature_addon VALUES 
(246479, 0, 0, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=246509;
INSERT INTO creature_addon VALUES 
(246509, 0, 1244, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=246477;
INSERT INTO creature_addon VALUES 
(246477, 0, 1244, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=246475;
INSERT INTO creature_addon VALUES 
(246475, 0, 1244, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=285466;
INSERT INTO creature_addon VALUES 
(285466, 0, 0, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=285467;
INSERT INTO creature_addon VALUES 
(285467, 0, 1244, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=246506;
INSERT INTO creature_addon VALUES 
(246506, 0, 0, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=246546;
INSERT INTO creature_addon VALUES 
(246546, 0, 0, 0, 1, 0, "12550 72381");

DELETE FROM creature_addon WHERE guid=246455;
INSERT INTO creature_addon VALUES 
(246455, 0, 0, 0, 1, 333, "85370");

DELETE FROM creature_addon WHERE guid=246443;
INSERT INTO creature_addon VALUES 
(246443, 0, 0, 0, 1, 0, "85370");

DELETE FROM creature_addon WHERE guid=285469;
INSERT INTO creature_addon VALUES 
(285469, 0, 0, 0, 1, 333, "85370");

DELETE FROM creature_addon WHERE guid=246454;
INSERT INTO creature_addon VALUES 
(246454, 0, 0, 0, 1, 333, "85370");

DELETE FROM creature_addon WHERE guid=246466;
INSERT INTO creature_addon VALUES 
(246466, 0, 0, 0, 1, 333, "85370");

DELETE FROM creature_addon WHERE guid=246463;
INSERT INTO creature_addon VALUES 
(246463, 0, 0, 0, 1, 333, "85370");

DELETE FROM creature_addon WHERE guid=285468;
INSERT INTO creature_addon VALUES 
(285468, 0, 0, 0, 1, 333, "85370");

DELETE FROM creature_addon WHERE guid=246445;
INSERT INTO creature_addon VALUES 
(246445, 0, 0, 0, 1, 333, "85370");

DELETE FROM creature_addon WHERE guid=285471;
INSERT INTO creature_addon VALUES 
(285471, 0, 0, 0, 1, 333, "85370");

DELETE FROM creature_addon WHERE guid=285472;
INSERT INTO creature_addon VALUES 
(285472, 0, 0, 0, 1, 0, "85370");

DELETE FROM creature_addon WHERE guid=285473;
INSERT INTO creature_addon VALUES 
(285473, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=285474;
INSERT INTO creature_addon VALUES 
(285474, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=285475;
INSERT INTO creature_addon VALUES 
(285475, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=285476;
INSERT INTO creature_addon VALUES 
(285476, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=246191;
INSERT INTO creature_addon VALUES 
(246191, 0, 0, 0, 1, 233, "68327");

DELETE FROM creature_addon WHERE guid=247725;
INSERT INTO creature_addon VALUES 
(247725, 0, 0, 0, 1, 69, "68327");

DELETE FROM creature_addon WHERE guid=247740;
INSERT INTO creature_addon VALUES 
(247740, 0, 0, 0, 1, 233, "68327");

DELETE FROM creature_addon WHERE guid=247728;
INSERT INTO creature_addon VALUES 
(247728, 0, 0, 0, 1, 233, "68327");

DELETE FROM creature_addon WHERE guid=247731;
INSERT INTO creature_addon VALUES 
(247731, 0, 0, 0, 1, 233, "68327");

DELETE FROM creature_addon WHERE guid=247732;
INSERT INTO creature_addon VALUES 
(247732, 0, 0, 0, 1, 233, "68327");

DELETE FROM creature_addon WHERE guid=247730;
INSERT INTO creature_addon VALUES 
(247730, 0, 0, 0, 1, 233, "68327");

DELETE FROM creature_addon WHERE guid=246193;
INSERT INTO creature_addon VALUES 
(246193, 0, 0, 0, 1, 233, "68327");

DELETE FROM creature_addon WHERE guid=246187;
INSERT INTO creature_addon VALUES 
(246187, 0, 0, 0, 1, 233, "68327");

DELETE FROM creature_addon WHERE guid=48314;
INSERT INTO creature_addon VALUES 
(48314, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=249546;
INSERT INTO creature_addon VALUES 
(249546, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249531;
INSERT INTO creature_addon VALUES 
(249531, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249530;
INSERT INTO creature_addon VALUES 
(249530, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249525;
INSERT INTO creature_addon VALUES 
(249525, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249528;
INSERT INTO creature_addon VALUES 
(249528, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249529;
INSERT INTO creature_addon VALUES 
(249529, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249534;
INSERT INTO creature_addon VALUES 
(249534, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249533;
INSERT INTO creature_addon VALUES 
(249533, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249532;
INSERT INTO creature_addon VALUES 
(249532, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249526;
INSERT INTO creature_addon VALUES 
(249526, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=246754;
INSERT INTO creature_addon VALUES 
(246754, 0, 0, 0, 285212673, 0, "7165");

DELETE FROM creature_addon WHERE guid=246752;
INSERT INTO creature_addon VALUES 
(246752, 0, 0, 0, 285212673, 0, "7165");

DELETE FROM creature_addon WHERE guid=246753;
INSERT INTO creature_addon VALUES 
(246753, 0, 0, 0, 285212673, 0, "7165");

DELETE FROM creature_addon WHERE guid=245299;
INSERT INTO creature_addon VALUES 
(245299, 0, 0, 0, 285212673, 0, "7165");

DELETE FROM creature_addon WHERE guid=245544;
INSERT INTO creature_addon VALUES 
(245544, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245474;
INSERT INTO creature_addon VALUES 
(245474, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245549;
INSERT INTO creature_addon VALUES 
(245549, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245511;
INSERT INTO creature_addon VALUES 
(245511, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245557;
INSERT INTO creature_addon VALUES 
(245557, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245550;
INSERT INTO creature_addon VALUES 
(245550, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285477;
INSERT INTO creature_addon VALUES 
(285477, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285487;
INSERT INTO creature_addon VALUES 
(285487, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285479;
INSERT INTO creature_addon VALUES 
(285479, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245495;
INSERT INTO creature_addon VALUES 
(245495, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245509;
INSERT INTO creature_addon VALUES 
(245509, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245478;
INSERT INTO creature_addon VALUES 
(245478, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245502;
INSERT INTO creature_addon VALUES 
(245502, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245559;
INSERT INTO creature_addon VALUES 
(245559, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245522;
INSERT INTO creature_addon VALUES 
(245522, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245497;
INSERT INTO creature_addon VALUES 
(245497, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245483;
INSERT INTO creature_addon VALUES 
(245483, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245525;
INSERT INTO creature_addon VALUES 
(245525, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285480;
INSERT INTO creature_addon VALUES 
(285480, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245524;
INSERT INTO creature_addon VALUES 
(245524, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245528;
INSERT INTO creature_addon VALUES 
(245528, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285481;
INSERT INTO creature_addon VALUES 
(285481, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285478;
INSERT INTO creature_addon VALUES 
(285478, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245523;
INSERT INTO creature_addon VALUES 
(245523, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245505;
INSERT INTO creature_addon VALUES 
(245505, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245518;
INSERT INTO creature_addon VALUES 
(245518, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285482;
INSERT INTO creature_addon VALUES 
(285482, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245526;
INSERT INTO creature_addon VALUES 
(245526, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245555;
INSERT INTO creature_addon VALUES 
(245555, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285483;
INSERT INTO creature_addon VALUES 
(285483, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285484;
INSERT INTO creature_addon VALUES 
(285484, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285485;
INSERT INTO creature_addon VALUES 
(285485, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245551;
INSERT INTO creature_addon VALUES 
(245551, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245482;
INSERT INTO creature_addon VALUES 
(245482, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245485;
INSERT INTO creature_addon VALUES 
(245485, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245558;
INSERT INTO creature_addon VALUES 
(245558, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285486;
INSERT INTO creature_addon VALUES 
(285486, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245493;
INSERT INTO creature_addon VALUES 
(245493, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245504;
INSERT INTO creature_addon VALUES 
(245504, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285488;
INSERT INTO creature_addon VALUES 
(285488, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245472;
INSERT INTO creature_addon VALUES 
(245472, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285489;
INSERT INTO creature_addon VALUES 
(285489, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245536;
INSERT INTO creature_addon VALUES 
(245536, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245500;
INSERT INTO creature_addon VALUES 
(245500, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245480;
INSERT INTO creature_addon VALUES 
(245480, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=285490;
INSERT INTO creature_addon VALUES 
(285490, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=245489;
INSERT INTO creature_addon VALUES 
(245489, 0, 0, 0, 1, 465, "");

DELETE FROM creature_addon WHERE guid=249527;
INSERT INTO creature_addon VALUES 
(249527, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=249233;
INSERT INTO creature_addon VALUES 
(249233, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249219;
INSERT INTO creature_addon VALUES 
(249219, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249212;
INSERT INTO creature_addon VALUES 
(249212, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249213;
INSERT INTO creature_addon VALUES 
(249213, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249211;
INSERT INTO creature_addon VALUES 
(249211, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249218;
INSERT INTO creature_addon VALUES 
(249218, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249230;
INSERT INTO creature_addon VALUES 
(249230, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249214;
INSERT INTO creature_addon VALUES 
(249214, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249228;
INSERT INTO creature_addon VALUES 
(249228, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249216;
INSERT INTO creature_addon VALUES 
(249216, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249210;
INSERT INTO creature_addon VALUES 
(249210, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=249222;
INSERT INTO creature_addon VALUES 
(249222, 0, 0, 0, 1, 0, "29266 87259");

DELETE FROM creature_addon WHERE guid=46716;
INSERT INTO creature_addon VALUES 
(46716, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=46592;
INSERT INTO creature_addon VALUES 
(46592, 0, 0, 0, 1, 64, "");

DELETE FROM creature_addon WHERE guid=46282;
INSERT INTO creature_addon VALUES 
(46282, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=46433;
INSERT INTO creature_addon VALUES 
(46433, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=46703;
INSERT INTO creature_addon VALUES 
(46703, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=46687;
INSERT INTO creature_addon VALUES 
(46687, 0, 0, 0, 1, 64, "");

DELETE FROM creature_addon WHERE guid=46578;
INSERT INTO creature_addon VALUES 
(46578, 0, 0, 0, 1, 64, "");

DELETE FROM creature_addon WHERE guid=46529;
INSERT INTO creature_addon VALUES 
(46529, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=46658;
INSERT INTO creature_addon VALUES 
(46658, 0, 0, 0, 1, 64, "");

DELETE FROM creature_addon WHERE guid=46537;
INSERT INTO creature_addon VALUES 
(46537, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=46684;
INSERT INTO creature_addon VALUES 
(46684, 0, 0, 0, 1, 64, "");

DELETE FROM creature_addon WHERE guid=46420;
INSERT INTO creature_addon VALUES 
(46420, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=46354;
INSERT INTO creature_addon VALUES 
(46354, 0, 0, 0, 1, 64, "");

DELETE FROM creature_addon WHERE guid=46596;
INSERT INTO creature_addon VALUES 
(46596, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=46376;
INSERT INTO creature_addon VALUES 
(46376, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=46411;
INSERT INTO creature_addon VALUES 
(46411, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=46821;
INSERT INTO creature_addon VALUES 
(46821, 0, 0, 0, 1, 64, "");

DELETE FROM creature_addon WHERE guid=285491;
INSERT INTO creature_addon VALUES 
(285491, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=285492;
INSERT INTO creature_addon VALUES 
(285492, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248931;
INSERT INTO creature_addon VALUES 
(248931, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285493;
INSERT INTO creature_addon VALUES 
(285493, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=248877;
INSERT INTO creature_addon VALUES 
(248877, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248875;
INSERT INTO creature_addon VALUES 
(248875, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248876;
INSERT INTO creature_addon VALUES 
(248876, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=248925;
INSERT INTO creature_addon VALUES 
(248925, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248937;
INSERT INTO creature_addon VALUES 
(248937, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248935;
INSERT INTO creature_addon VALUES 
(248935, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248847;
INSERT INTO creature_addon VALUES 
(248847, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248928;
INSERT INTO creature_addon VALUES 
(248928, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248930;
INSERT INTO creature_addon VALUES 
(248930, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285498;
INSERT INTO creature_addon VALUES 
(285498, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248940;
INSERT INTO creature_addon VALUES 
(248940, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=285499;
INSERT INTO creature_addon VALUES 
(285499, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285500;
INSERT INTO creature_addon VALUES 
(285500, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285501;
INSERT INTO creature_addon VALUES 
(285501, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=248394;
INSERT INTO creature_addon VALUES 
(248394, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285502;
INSERT INTO creature_addon VALUES 
(285502, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285503;
INSERT INTO creature_addon VALUES 
(285503, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=247282;
INSERT INTO creature_addon VALUES 
(247282, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247275;
INSERT INTO creature_addon VALUES 
(247275, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285571;
INSERT INTO creature_addon VALUES 
(285571, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285572;
INSERT INTO creature_addon VALUES 
(285572, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285573;
INSERT INTO creature_addon VALUES 
(285573, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285574;
INSERT INTO creature_addon VALUES 
(285574, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247287;
INSERT INTO creature_addon VALUES 
(247287, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247306;
INSERT INTO creature_addon VALUES 
(247306, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247311;
INSERT INTO creature_addon VALUES 
(247311, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247292;
INSERT INTO creature_addon VALUES 
(247292, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285575;
INSERT INTO creature_addon VALUES 
(285575, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247283;
INSERT INTO creature_addon VALUES 
(247283, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247307;
INSERT INTO creature_addon VALUES 
(247307, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247294;
INSERT INTO creature_addon VALUES 
(247294, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285576;
INSERT INTO creature_addon VALUES 
(285576, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285577;
INSERT INTO creature_addon VALUES 
(285577, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285578;
INSERT INTO creature_addon VALUES 
(285578, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247280;
INSERT INTO creature_addon VALUES 
(247280, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=285579;
INSERT INTO creature_addon VALUES 
(285579, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247284;
INSERT INTO creature_addon VALUES 
(247284, 0, 0, 50331648, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246035;
INSERT INTO creature_addon VALUES 
(246035, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=245963;
INSERT INTO creature_addon VALUES 
(245963, 0, 0, 65541, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249467;
INSERT INTO creature_addon VALUES 
(249467, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=247563;
INSERT INTO creature_addon VALUES 
(247563, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247566;
INSERT INTO creature_addon VALUES 
(247566, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247581;
INSERT INTO creature_addon VALUES 
(247581, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247574;
INSERT INTO creature_addon VALUES 
(247574, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=285608;
INSERT INTO creature_addon VALUES 
(285608, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247564;
INSERT INTO creature_addon VALUES 
(247564, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=285609;
INSERT INTO creature_addon VALUES 
(285609, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=285610;
INSERT INTO creature_addon VALUES 
(285610, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247565;
INSERT INTO creature_addon VALUES 
(247565, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247571;
INSERT INTO creature_addon VALUES 
(247571, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247559;
INSERT INTO creature_addon VALUES 
(247559, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247558;
INSERT INTO creature_addon VALUES 
(247558, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247556;
INSERT INTO creature_addon VALUES 
(247556, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247570;
INSERT INTO creature_addon VALUES 
(247570, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247561;
INSERT INTO creature_addon VALUES 
(247561, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247573;
INSERT INTO creature_addon VALUES 
(247573, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=285614;
INSERT INTO creature_addon VALUES 
(285614, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247562;
INSERT INTO creature_addon VALUES 
(247562, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247560;
INSERT INTO creature_addon VALUES 
(247560, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247569;
INSERT INTO creature_addon VALUES 
(247569, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=285615;
INSERT INTO creature_addon VALUES 
(285615, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=285617;
INSERT INTO creature_addon VALUES 
(285617, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=285620;
INSERT INTO creature_addon VALUES 
(285620, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247567;
INSERT INTO creature_addon VALUES 
(247567, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=247557;
INSERT INTO creature_addon VALUES 
(247557, 0, 0, 0, 1, 0, "72518 72522");

DELETE FROM creature_addon WHERE guid=245853;
INSERT INTO creature_addon VALUES 
(245853, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285622;
INSERT INTO creature_addon VALUES 
(285622, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285624;
INSERT INTO creature_addon VALUES 
(285624, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245849;
INSERT INTO creature_addon VALUES 
(245849, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285631;
INSERT INTO creature_addon VALUES 
(285631, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285638;
INSERT INTO creature_addon VALUES 
(285638, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285641;
INSERT INTO creature_addon VALUES 
(285641, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245851;
INSERT INTO creature_addon VALUES 
(245851, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245882;
INSERT INTO creature_addon VALUES 
(245882, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=245846;
INSERT INTO creature_addon VALUES 
(245846, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=246556;
INSERT INTO creature_addon VALUES 
(246556, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285643;
INSERT INTO creature_addon VALUES 
(285643, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285644;
INSERT INTO creature_addon VALUES 
(285644, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=285647;
INSERT INTO creature_addon VALUES 
(285647, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=2132;
INSERT INTO creature_addon VALUES 
(2132, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=2135;
INSERT INTO creature_addon VALUES 
(2135, 0, 0, 0, 1, 333, "");

DELETE FROM creature_addon WHERE guid=2134;
INSERT INTO creature_addon VALUES 
(2134, 0, 0, 65536, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285652;
INSERT INTO creature_addon VALUES 
(285652, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=245885;
INSERT INTO creature_addon VALUES 
(245885, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=285653;
INSERT INTO creature_addon VALUES 
(285653, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=246058;
INSERT INTO creature_addon VALUES 
(246058, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=246057;
INSERT INTO creature_addon VALUES 
(246057, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=285654;
INSERT INTO creature_addon VALUES 
(285654, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=246264;
INSERT INTO creature_addon VALUES 
(246264, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=246263;
INSERT INTO creature_addon VALUES 
(246263, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=285655;
INSERT INTO creature_addon VALUES 
(285655, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=285656;
INSERT INTO creature_addon VALUES 
(285656, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246086;
INSERT INTO creature_addon VALUES 
(246086, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285657;
INSERT INTO creature_addon VALUES 
(285657, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285658;
INSERT INTO creature_addon VALUES 
(285658, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246085;
INSERT INTO creature_addon VALUES 
(246085, 0, 0, 0, 1, 234, "");

DELETE FROM creature_addon WHERE guid=285662;
INSERT INTO creature_addon VALUES 
(285662, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285663;
INSERT INTO creature_addon VALUES 
(285663, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246084;
INSERT INTO creature_addon VALUES 
(246084, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=245960;
INSERT INTO creature_addon VALUES 
(245960, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=245976;
INSERT INTO creature_addon VALUES 
(245976, 0, 0, 0, 1, 69, "68327");

DELETE FROM creature_addon WHERE guid=246046;
INSERT INTO creature_addon VALUES 
(246046, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285665;
INSERT INTO creature_addon VALUES 
(285665, 0, 0, 0, 1, 0, "90909");

DELETE FROM creature_addon WHERE guid=285666;
INSERT INTO creature_addon VALUES 
(285666, 0, 0, 0, 1, 0, "90909");

DELETE FROM creature_addon WHERE guid=249194;
INSERT INTO creature_addon VALUES 
(249194, 0, 0, 0, 1, 0, "90909");

DELETE FROM creature_addon WHERE guid=249200;
INSERT INTO creature_addon VALUES 
(249200, 0, 0, 0, 1, 0, "89842");

DELETE FROM creature_addon WHERE guid=249188;
INSERT INTO creature_addon VALUES 
(249188, 0, 0, 0, 1, 0, "89842");

DELETE FROM creature_addon WHERE guid=249196;
INSERT INTO creature_addon VALUES 
(249196, 0, 0, 0, 1, 0, "89842");

DELETE FROM creature_addon WHERE guid=285676;
INSERT INTO creature_addon VALUES 
(285676, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=285677;
INSERT INTO creature_addon VALUES 
(285677, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=246513;
INSERT INTO creature_addon VALUES 
(246513, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=9171;
INSERT INTO creature_addon VALUES 
(9171, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285680;
INSERT INTO creature_addon VALUES 
(285680, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=26545;
INSERT INTO creature_addon VALUES 
(26545, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=6004;
INSERT INTO creature_addon VALUES 
(6004, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285681;
INSERT INTO creature_addon VALUES 
(285681, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22042;
INSERT INTO creature_addon VALUES 
(22042, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285682;
INSERT INTO creature_addon VALUES 
(285682, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=972;
INSERT INTO creature_addon VALUES 
(972, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=6782;
INSERT INTO creature_addon VALUES 
(6782, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=7012;
INSERT INTO creature_addon VALUES 
(7012, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22203;
INSERT INTO creature_addon VALUES 
(22203, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=24987;
INSERT INTO creature_addon VALUES 
(24987, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285683;
INSERT INTO creature_addon VALUES 
(285683, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1843;
INSERT INTO creature_addon VALUES 
(1843, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=2149;
INSERT INTO creature_addon VALUES 
(2149, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1877;
INSERT INTO creature_addon VALUES 
(1877, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=9086;
INSERT INTO creature_addon VALUES 
(9086, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=9136;
INSERT INTO creature_addon VALUES 
(9136, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=6374;
INSERT INTO creature_addon VALUES 
(6374, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285684;
INSERT INTO creature_addon VALUES 
(285684, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285685;
INSERT INTO creature_addon VALUES 
(285685, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=26553;
INSERT INTO creature_addon VALUES 
(26553, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22215;
INSERT INTO creature_addon VALUES 
(22215, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=21939;
INSERT INTO creature_addon VALUES 
(21939, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285686;
INSERT INTO creature_addon VALUES 
(285686, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22096;
INSERT INTO creature_addon VALUES 
(22096, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285687;
INSERT INTO creature_addon VALUES 
(285687, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285688;
INSERT INTO creature_addon VALUES 
(285688, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285689;
INSERT INTO creature_addon VALUES 
(285689, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22146;
INSERT INTO creature_addon VALUES 
(22146, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=21879;
INSERT INTO creature_addon VALUES 
(21879, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22247;
INSERT INTO creature_addon VALUES 
(22247, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=21853;
INSERT INTO creature_addon VALUES 
(21853, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=2362;
INSERT INTO creature_addon VALUES 
(2362, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285690;
INSERT INTO creature_addon VALUES 
(285690, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285691;
INSERT INTO creature_addon VALUES 
(285691, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285692;
INSERT INTO creature_addon VALUES 
(285692, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22142;
INSERT INTO creature_addon VALUES 
(22142, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22015;
INSERT INTO creature_addon VALUES 
(22015, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285693;
INSERT INTO creature_addon VALUES 
(285693, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=21954;
INSERT INTO creature_addon VALUES 
(21954, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=2289;
INSERT INTO creature_addon VALUES 
(2289, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=2238;
INSERT INTO creature_addon VALUES 
(2238, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=6037;
INSERT INTO creature_addon VALUES 
(6037, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=9740;
INSERT INTO creature_addon VALUES 
(9740, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=26556;
INSERT INTO creature_addon VALUES 
(26556, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=2004;
INSERT INTO creature_addon VALUES 
(2004, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285694;
INSERT INTO creature_addon VALUES 
(285694, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285695;
INSERT INTO creature_addon VALUES 
(285695, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285696;
INSERT INTO creature_addon VALUES 
(285696, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=24909;
INSERT INTO creature_addon VALUES 
(24909, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1364;
INSERT INTO creature_addon VALUES 
(1364, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1417;
INSERT INTO creature_addon VALUES 
(1417, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=649;
INSERT INTO creature_addon VALUES 
(649, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285697;
INSERT INTO creature_addon VALUES 
(285697, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285698;
INSERT INTO creature_addon VALUES 
(285698, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285699;
INSERT INTO creature_addon VALUES 
(285699, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1856;
INSERT INTO creature_addon VALUES 
(1856, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=9108;
INSERT INTO creature_addon VALUES 
(9108, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=9247;
INSERT INTO creature_addon VALUES 
(9247, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1797;
INSERT INTO creature_addon VALUES 
(1797, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285700;
INSERT INTO creature_addon VALUES 
(285700, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=9205;
INSERT INTO creature_addon VALUES 
(9205, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1832;
INSERT INTO creature_addon VALUES 
(1832, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=6008;
INSERT INTO creature_addon VALUES 
(6008, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285701;
INSERT INTO creature_addon VALUES 
(285701, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=4550;
INSERT INTO creature_addon VALUES 
(4550, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=4547;
INSERT INTO creature_addon VALUES 
(4547, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=24578;
INSERT INTO creature_addon VALUES 
(24578, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=7036;
INSERT INTO creature_addon VALUES 
(7036, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285702;
INSERT INTO creature_addon VALUES 
(285702, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285703;
INSERT INTO creature_addon VALUES 
(285703, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1785;
INSERT INTO creature_addon VALUES 
(1785, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=5218;
INSERT INTO creature_addon VALUES 
(5218, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=6155;
INSERT INTO creature_addon VALUES 
(6155, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1056;
INSERT INTO creature_addon VALUES 
(1056, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285704;
INSERT INTO creature_addon VALUES 
(285704, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=2139;
INSERT INTO creature_addon VALUES 
(2139, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285705;
INSERT INTO creature_addon VALUES 
(285705, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=21871;
INSERT INTO creature_addon VALUES 
(21871, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=5933;
INSERT INTO creature_addon VALUES 
(5933, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=4552;
INSERT INTO creature_addon VALUES 
(4552, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285706;
INSERT INTO creature_addon VALUES 
(285706, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1638;
INSERT INTO creature_addon VALUES 
(1638, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285707;
INSERT INTO creature_addon VALUES 
(285707, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=6780;
INSERT INTO creature_addon VALUES 
(6780, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=9194;
INSERT INTO creature_addon VALUES 
(9194, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285708;
INSERT INTO creature_addon VALUES 
(285708, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285709;
INSERT INTO creature_addon VALUES 
(285709, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22193;
INSERT INTO creature_addon VALUES 
(22193, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285710;
INSERT INTO creature_addon VALUES 
(285710, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285711;
INSERT INTO creature_addon VALUES 
(285711, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=26019;
INSERT INTO creature_addon VALUES 
(26019, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285712;
INSERT INTO creature_addon VALUES 
(285712, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=6087;
INSERT INTO creature_addon VALUES 
(6087, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285713;
INSERT INTO creature_addon VALUES 
(285713, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=24309;
INSERT INTO creature_addon VALUES 
(24309, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22244;
INSERT INTO creature_addon VALUES 
(22244, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285714;
INSERT INTO creature_addon VALUES 
(285714, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285715;
INSERT INTO creature_addon VALUES 
(285715, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285716;
INSERT INTO creature_addon VALUES 
(285716, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=5782;
INSERT INTO creature_addon VALUES 
(5782, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285717;
INSERT INTO creature_addon VALUES 
(285717, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1808;
INSERT INTO creature_addon VALUES 
(1808, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=22063;
INSERT INTO creature_addon VALUES 
(22063, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=942;
INSERT INTO creature_addon VALUES 
(942, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285718;
INSERT INTO creature_addon VALUES 
(285718, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=951;
INSERT INTO creature_addon VALUES 
(951, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=285719;
INSERT INTO creature_addon VALUES 
(285719, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=2049;
INSERT INTO creature_addon VALUES 
(2049, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=1763;
INSERT INTO creature_addon VALUES 
(1763, 0, 0, 0, 1, 431, "71333");

DELETE FROM creature_addon WHERE guid=248262;
INSERT INTO creature_addon VALUES 
(248262, 0, 0, 0, 1, 0, "71333");

DELETE FROM creature_addon WHERE guid=1762;
INSERT INTO creature_addon VALUES 
(1762, 0, 0, 0, 1, 431, "71333");

DELETE FROM creature_addon WHERE guid=245959;
INSERT INTO creature_addon VALUES 
(245959, 0, 0, 65536, 1, 0, "70268");

DELETE FROM creature_addon WHERE guid=249462;
INSERT INTO creature_addon VALUES 
(249462, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=769;
INSERT INTO creature_addon VALUES 
(769, 0, 0, 0, 1, 0, "13864 68327 79058");

DELETE FROM creature_addon WHERE guid=767;
INSERT INTO creature_addon VALUES 
(767, 0, 0, 0, 1, 0, "13864 68327 79058");

DELETE FROM creature_addon WHERE guid=768;
INSERT INTO creature_addon VALUES 
(768, 0, 0, 0, 1, 0, "13864 68327 79058");

DELETE FROM creature_addon WHERE guid=771;
INSERT INTO creature_addon VALUES 
(771, 0, 0, 0, 1, 0, "13864 68327 79058");

DELETE FROM creature_addon WHERE guid=770;
INSERT INTO creature_addon VALUES 
(770, 0, 0, 0, 1, 0, "13864 68327 79058");

DELETE FROM creature_addon WHERE guid=772;
INSERT INTO creature_addon VALUES 
(772, 0, 0, 0, 1, 333, "13864 68327 79058");

DELETE FROM creature_addon WHERE guid=248331;
INSERT INTO creature_addon VALUES 
(248331, 0, 0, 0, 1, 0, "76367");

DELETE FROM creature_addon WHERE guid=246798;
INSERT INTO creature_addon VALUES 
(246798, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=285775;
INSERT INTO creature_addon VALUES 
(285775, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246796;
INSERT INTO creature_addon VALUES 
(246796, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=285776;
INSERT INTO creature_addon VALUES 
(285776, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285779;
INSERT INTO creature_addon VALUES 
(285779, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285780;
INSERT INTO creature_addon VALUES 
(285780, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=246806;
INSERT INTO creature_addon VALUES 
(246806, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246823;
INSERT INTO creature_addon VALUES 
(246823, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246821;
INSERT INTO creature_addon VALUES 
(246821, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=285793;
INSERT INTO creature_addon VALUES 
(285793, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285799;
INSERT INTO creature_addon VALUES 
(285799, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285800;
INSERT INTO creature_addon VALUES 
(285800, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246797;
INSERT INTO creature_addon VALUES 
(246797, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=246824;
INSERT INTO creature_addon VALUES 
(246824, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=246810;
INSERT INTO creature_addon VALUES 
(246810, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=246808;
INSERT INTO creature_addon VALUES 
(246808, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246799;
INSERT INTO creature_addon VALUES 
(246799, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=285803;
INSERT INTO creature_addon VALUES 
(285803, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285804;
INSERT INTO creature_addon VALUES 
(285804, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246841;
INSERT INTO creature_addon VALUES 
(246841, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=285807;
INSERT INTO creature_addon VALUES 
(285807, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=246800;
INSERT INTO creature_addon VALUES 
(246800, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=6736;
INSERT INTO creature_addon VALUES 
(6736, 0, 0, 0, 1, 375, "");

DELETE FROM creature_addon WHERE guid=6735;
INSERT INTO creature_addon VALUES 
(6735, 0, 0, 65536, 1, 69, "");

DELETE FROM creature_addon WHERE guid=247426;
INSERT INTO creature_addon VALUES 
(247426, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285812;
INSERT INTO creature_addon VALUES 
(285812, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285813;
INSERT INTO creature_addon VALUES 
(285813, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285814;
INSERT INTO creature_addon VALUES 
(285814, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285815;
INSERT INTO creature_addon VALUES 
(285815, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285816;
INSERT INTO creature_addon VALUES 
(285816, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285817;
INSERT INTO creature_addon VALUES 
(285817, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285818;
INSERT INTO creature_addon VALUES 
(285818, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285819;
INSERT INTO creature_addon VALUES 
(285819, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247467;
INSERT INTO creature_addon VALUES 
(247467, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247420;
INSERT INTO creature_addon VALUES 
(247420, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285820;
INSERT INTO creature_addon VALUES 
(285820, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285821;
INSERT INTO creature_addon VALUES 
(285821, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285822;
INSERT INTO creature_addon VALUES 
(285822, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285823;
INSERT INTO creature_addon VALUES 
(285823, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285824;
INSERT INTO creature_addon VALUES 
(285824, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285825;
INSERT INTO creature_addon VALUES 
(285825, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247421;
INSERT INTO creature_addon VALUES 
(247421, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285826;
INSERT INTO creature_addon VALUES 
(285826, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285827;
INSERT INTO creature_addon VALUES 
(285827, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247470;
INSERT INTO creature_addon VALUES 
(247470, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285828;
INSERT INTO creature_addon VALUES 
(285828, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285829;
INSERT INTO creature_addon VALUES 
(285829, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285830;
INSERT INTO creature_addon VALUES 
(285830, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285831;
INSERT INTO creature_addon VALUES 
(285831, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285832;
INSERT INTO creature_addon VALUES 
(285832, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285833;
INSERT INTO creature_addon VALUES 
(285833, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285834;
INSERT INTO creature_addon VALUES 
(285834, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285835;
INSERT INTO creature_addon VALUES 
(285835, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285836;
INSERT INTO creature_addon VALUES 
(285836, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285837;
INSERT INTO creature_addon VALUES 
(285837, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285838;
INSERT INTO creature_addon VALUES 
(285838, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285839;
INSERT INTO creature_addon VALUES 
(285839, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285840;
INSERT INTO creature_addon VALUES 
(285840, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285841;
INSERT INTO creature_addon VALUES 
(285841, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285842;
INSERT INTO creature_addon VALUES 
(285842, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285843;
INSERT INTO creature_addon VALUES 
(285843, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247391;
INSERT INTO creature_addon VALUES 
(247391, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285844;
INSERT INTO creature_addon VALUES 
(285844, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247400;
INSERT INTO creature_addon VALUES 
(247400, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285845;
INSERT INTO creature_addon VALUES 
(285845, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285846;
INSERT INTO creature_addon VALUES 
(285846, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285847;
INSERT INTO creature_addon VALUES 
(285847, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285848;
INSERT INTO creature_addon VALUES 
(285848, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285849;
INSERT INTO creature_addon VALUES 
(285849, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285850;
INSERT INTO creature_addon VALUES 
(285850, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247471;
INSERT INTO creature_addon VALUES 
(247471, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285851;
INSERT INTO creature_addon VALUES 
(285851, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247427;
INSERT INTO creature_addon VALUES 
(247427, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285852;
INSERT INTO creature_addon VALUES 
(285852, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285853;
INSERT INTO creature_addon VALUES 
(285853, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285854;
INSERT INTO creature_addon VALUES 
(285854, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285855;
INSERT INTO creature_addon VALUES 
(285855, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285856;
INSERT INTO creature_addon VALUES 
(285856, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247399;
INSERT INTO creature_addon VALUES 
(247399, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247429;
INSERT INTO creature_addon VALUES 
(247429, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285857;
INSERT INTO creature_addon VALUES 
(285857, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247473;
INSERT INTO creature_addon VALUES 
(247473, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285858;
INSERT INTO creature_addon VALUES 
(285858, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247430;
INSERT INTO creature_addon VALUES 
(247430, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285859;
INSERT INTO creature_addon VALUES 
(285859, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285860;
INSERT INTO creature_addon VALUES 
(285860, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285861;
INSERT INTO creature_addon VALUES 
(285861, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285862;
INSERT INTO creature_addon VALUES 
(285862, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285863;
INSERT INTO creature_addon VALUES 
(285863, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285864;
INSERT INTO creature_addon VALUES 
(285864, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247431;
INSERT INTO creature_addon VALUES 
(247431, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285865;
INSERT INTO creature_addon VALUES 
(285865, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285866;
INSERT INTO creature_addon VALUES 
(285866, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285867;
INSERT INTO creature_addon VALUES 
(285867, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285868;
INSERT INTO creature_addon VALUES 
(285868, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285869;
INSERT INTO creature_addon VALUES 
(285869, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285870;
INSERT INTO creature_addon VALUES 
(285870, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285871;
INSERT INTO creature_addon VALUES 
(285871, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285872;
INSERT INTO creature_addon VALUES 
(285872, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247463;
INSERT INTO creature_addon VALUES 
(247463, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285873;
INSERT INTO creature_addon VALUES 
(285873, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285874;
INSERT INTO creature_addon VALUES 
(285874, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285875;
INSERT INTO creature_addon VALUES 
(285875, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285876;
INSERT INTO creature_addon VALUES 
(285876, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285877;
INSERT INTO creature_addon VALUES 
(285877, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285878;
INSERT INTO creature_addon VALUES 
(285878, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285879;
INSERT INTO creature_addon VALUES 
(285879, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247474;
INSERT INTO creature_addon VALUES 
(247474, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285880;
INSERT INTO creature_addon VALUES 
(285880, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285881;
INSERT INTO creature_addon VALUES 
(285881, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285882;
INSERT INTO creature_addon VALUES 
(285882, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285883;
INSERT INTO creature_addon VALUES 
(285883, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247457;
INSERT INTO creature_addon VALUES 
(247457, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285884;
INSERT INTO creature_addon VALUES 
(285884, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285885;
INSERT INTO creature_addon VALUES 
(285885, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285886;
INSERT INTO creature_addon VALUES 
(285886, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285887;
INSERT INTO creature_addon VALUES 
(285887, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247461;
INSERT INTO creature_addon VALUES 
(247461, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285888;
INSERT INTO creature_addon VALUES 
(285888, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285889;
INSERT INTO creature_addon VALUES 
(285889, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285890;
INSERT INTO creature_addon VALUES 
(285890, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285891;
INSERT INTO creature_addon VALUES 
(285891, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285892;
INSERT INTO creature_addon VALUES 
(285892, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285893;
INSERT INTO creature_addon VALUES 
(285893, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247412;
INSERT INTO creature_addon VALUES 
(247412, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285894;
INSERT INTO creature_addon VALUES 
(285894, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285895;
INSERT INTO creature_addon VALUES 
(285895, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247438;
INSERT INTO creature_addon VALUES 
(247438, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247437;
INSERT INTO creature_addon VALUES 
(247437, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285896;
INSERT INTO creature_addon VALUES 
(285896, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285897;
INSERT INTO creature_addon VALUES 
(285897, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285898;
INSERT INTO creature_addon VALUES 
(285898, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285899;
INSERT INTO creature_addon VALUES 
(285899, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247454;
INSERT INTO creature_addon VALUES 
(247454, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285900;
INSERT INTO creature_addon VALUES 
(285900, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247392;
INSERT INTO creature_addon VALUES 
(247392, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285901;
INSERT INTO creature_addon VALUES 
(285901, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285902;
INSERT INTO creature_addon VALUES 
(285902, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285903;
INSERT INTO creature_addon VALUES 
(285903, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285904;
INSERT INTO creature_addon VALUES 
(285904, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285905;
INSERT INTO creature_addon VALUES 
(285905, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285906;
INSERT INTO creature_addon VALUES 
(285906, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285907;
INSERT INTO creature_addon VALUES 
(285907, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285908;
INSERT INTO creature_addon VALUES 
(285908, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285909;
INSERT INTO creature_addon VALUES 
(285909, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285910;
INSERT INTO creature_addon VALUES 
(285910, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247413;
INSERT INTO creature_addon VALUES 
(247413, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285911;
INSERT INTO creature_addon VALUES 
(285911, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285912;
INSERT INTO creature_addon VALUES 
(285912, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247416;
INSERT INTO creature_addon VALUES 
(247416, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247432;
INSERT INTO creature_addon VALUES 
(247432, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285913;
INSERT INTO creature_addon VALUES 
(285913, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247396;
INSERT INTO creature_addon VALUES 
(247396, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285914;
INSERT INTO creature_addon VALUES 
(285914, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247419;
INSERT INTO creature_addon VALUES 
(247419, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285915;
INSERT INTO creature_addon VALUES 
(285915, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285916;
INSERT INTO creature_addon VALUES 
(285916, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285917;
INSERT INTO creature_addon VALUES 
(285917, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285918;
INSERT INTO creature_addon VALUES 
(285918, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247418;
INSERT INTO creature_addon VALUES 
(247418, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285919;
INSERT INTO creature_addon VALUES 
(285919, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285920;
INSERT INTO creature_addon VALUES 
(285920, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285921;
INSERT INTO creature_addon VALUES 
(285921, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247417;
INSERT INTO creature_addon VALUES 
(247417, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285922;
INSERT INTO creature_addon VALUES 
(285922, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285923;
INSERT INTO creature_addon VALUES 
(285923, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285924;
INSERT INTO creature_addon VALUES 
(285924, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247408;
INSERT INTO creature_addon VALUES 
(247408, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285925;
INSERT INTO creature_addon VALUES 
(285925, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285926;
INSERT INTO creature_addon VALUES 
(285926, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285927;
INSERT INTO creature_addon VALUES 
(285927, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285928;
INSERT INTO creature_addon VALUES 
(285928, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285929;
INSERT INTO creature_addon VALUES 
(285929, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285930;
INSERT INTO creature_addon VALUES 
(285930, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285931;
INSERT INTO creature_addon VALUES 
(285931, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285932;
INSERT INTO creature_addon VALUES 
(285932, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285933;
INSERT INTO creature_addon VALUES 
(285933, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285934;
INSERT INTO creature_addon VALUES 
(285934, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285935;
INSERT INTO creature_addon VALUES 
(285935, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247409;
INSERT INTO creature_addon VALUES 
(247409, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285936;
INSERT INTO creature_addon VALUES 
(285936, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247415;
INSERT INTO creature_addon VALUES 
(247415, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285937;
INSERT INTO creature_addon VALUES 
(285937, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285938;
INSERT INTO creature_addon VALUES 
(285938, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285939;
INSERT INTO creature_addon VALUES 
(285939, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285940;
INSERT INTO creature_addon VALUES 
(285940, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285941;
INSERT INTO creature_addon VALUES 
(285941, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285942;
INSERT INTO creature_addon VALUES 
(285942, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247404;
INSERT INTO creature_addon VALUES 
(247404, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285943;
INSERT INTO creature_addon VALUES 
(285943, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285944;
INSERT INTO creature_addon VALUES 
(285944, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285945;
INSERT INTO creature_addon VALUES 
(285945, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285946;
INSERT INTO creature_addon VALUES 
(285946, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285947;
INSERT INTO creature_addon VALUES 
(285947, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285948;
INSERT INTO creature_addon VALUES 
(285948, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285949;
INSERT INTO creature_addon VALUES 
(285949, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285950;
INSERT INTO creature_addon VALUES 
(285950, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285951;
INSERT INTO creature_addon VALUES 
(285951, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285952;
INSERT INTO creature_addon VALUES 
(285952, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285953;
INSERT INTO creature_addon VALUES 
(285953, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285954;
INSERT INTO creature_addon VALUES 
(285954, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285955;
INSERT INTO creature_addon VALUES 
(285955, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285956;
INSERT INTO creature_addon VALUES 
(285956, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247422;
INSERT INTO creature_addon VALUES 
(247422, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285957;
INSERT INTO creature_addon VALUES 
(285957, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285958;
INSERT INTO creature_addon VALUES 
(285958, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285959;
INSERT INTO creature_addon VALUES 
(285959, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285960;
INSERT INTO creature_addon VALUES 
(285960, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285961;
INSERT INTO creature_addon VALUES 
(285961, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247403;
INSERT INTO creature_addon VALUES 
(247403, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285962;
INSERT INTO creature_addon VALUES 
(285962, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285963;
INSERT INTO creature_addon VALUES 
(285963, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247407;
INSERT INTO creature_addon VALUES 
(247407, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285964;
INSERT INTO creature_addon VALUES 
(285964, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285965;
INSERT INTO creature_addon VALUES 
(285965, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285966;
INSERT INTO creature_addon VALUES 
(285966, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285967;
INSERT INTO creature_addon VALUES 
(285967, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247423;
INSERT INTO creature_addon VALUES 
(247423, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285968;
INSERT INTO creature_addon VALUES 
(285968, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285969;
INSERT INTO creature_addon VALUES 
(285969, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247424;
INSERT INTO creature_addon VALUES 
(247424, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285970;
INSERT INTO creature_addon VALUES 
(285970, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285971;
INSERT INTO creature_addon VALUES 
(285971, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285972;
INSERT INTO creature_addon VALUES 
(285972, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285973;
INSERT INTO creature_addon VALUES 
(285973, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247425;
INSERT INTO creature_addon VALUES 
(247425, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247465;
INSERT INTO creature_addon VALUES 
(247465, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285974;
INSERT INTO creature_addon VALUES 
(285974, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285975;
INSERT INTO creature_addon VALUES 
(285975, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285976;
INSERT INTO creature_addon VALUES 
(285976, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285977;
INSERT INTO creature_addon VALUES 
(285977, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285978;
INSERT INTO creature_addon VALUES 
(285978, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285979;
INSERT INTO creature_addon VALUES 
(285979, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285980;
INSERT INTO creature_addon VALUES 
(285980, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285981;
INSERT INTO creature_addon VALUES 
(285981, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285982;
INSERT INTO creature_addon VALUES 
(285982, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285983;
INSERT INTO creature_addon VALUES 
(285983, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285984;
INSERT INTO creature_addon VALUES 
(285984, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285985;
INSERT INTO creature_addon VALUES 
(285985, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285986;
INSERT INTO creature_addon VALUES 
(285986, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285987;
INSERT INTO creature_addon VALUES 
(285987, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285988;
INSERT INTO creature_addon VALUES 
(285988, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285989;
INSERT INTO creature_addon VALUES 
(285989, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285990;
INSERT INTO creature_addon VALUES 
(285990, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285991;
INSERT INTO creature_addon VALUES 
(285991, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285992;
INSERT INTO creature_addon VALUES 
(285992, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285993;
INSERT INTO creature_addon VALUES 
(285993, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285994;
INSERT INTO creature_addon VALUES 
(285994, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285995;
INSERT INTO creature_addon VALUES 
(285995, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247401;
INSERT INTO creature_addon VALUES 
(247401, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285996;
INSERT INTO creature_addon VALUES 
(285996, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285997;
INSERT INTO creature_addon VALUES 
(285997, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285998;
INSERT INTO creature_addon VALUES 
(285998, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=285999;
INSERT INTO creature_addon VALUES 
(285999, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286000;
INSERT INTO creature_addon VALUES 
(286000, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286001;
INSERT INTO creature_addon VALUES 
(286001, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286002;
INSERT INTO creature_addon VALUES 
(286002, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286003;
INSERT INTO creature_addon VALUES 
(286003, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286004;
INSERT INTO creature_addon VALUES 
(286004, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286005;
INSERT INTO creature_addon VALUES 
(286005, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286006;
INSERT INTO creature_addon VALUES 
(286006, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286007;
INSERT INTO creature_addon VALUES 
(286007, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286008;
INSERT INTO creature_addon VALUES 
(286008, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286009;
INSERT INTO creature_addon VALUES 
(286009, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286010;
INSERT INTO creature_addon VALUES 
(286010, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286011;
INSERT INTO creature_addon VALUES 
(286011, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247466;
INSERT INTO creature_addon VALUES 
(247466, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286012;
INSERT INTO creature_addon VALUES 
(286012, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286013;
INSERT INTO creature_addon VALUES 
(286013, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286014;
INSERT INTO creature_addon VALUES 
(286014, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286015;
INSERT INTO creature_addon VALUES 
(286015, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286016;
INSERT INTO creature_addon VALUES 
(286016, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286017;
INSERT INTO creature_addon VALUES 
(286017, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286018;
INSERT INTO creature_addon VALUES 
(286018, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247410;
INSERT INTO creature_addon VALUES 
(247410, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286019;
INSERT INTO creature_addon VALUES 
(286019, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286020;
INSERT INTO creature_addon VALUES 
(286020, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286021;
INSERT INTO creature_addon VALUES 
(286021, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286022;
INSERT INTO creature_addon VALUES 
(286022, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247433;
INSERT INTO creature_addon VALUES 
(247433, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286023;
INSERT INTO creature_addon VALUES 
(286023, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286024;
INSERT INTO creature_addon VALUES 
(286024, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286025;
INSERT INTO creature_addon VALUES 
(286025, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286026;
INSERT INTO creature_addon VALUES 
(286026, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286027;
INSERT INTO creature_addon VALUES 
(286027, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247395;
INSERT INTO creature_addon VALUES 
(247395, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286028;
INSERT INTO creature_addon VALUES 
(286028, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286029;
INSERT INTO creature_addon VALUES 
(286029, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286030;
INSERT INTO creature_addon VALUES 
(286030, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247393;
INSERT INTO creature_addon VALUES 
(247393, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286031;
INSERT INTO creature_addon VALUES 
(286031, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286032;
INSERT INTO creature_addon VALUES 
(286032, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286033;
INSERT INTO creature_addon VALUES 
(286033, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286034;
INSERT INTO creature_addon VALUES 
(286034, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286035;
INSERT INTO creature_addon VALUES 
(286035, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286036;
INSERT INTO creature_addon VALUES 
(286036, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286037;
INSERT INTO creature_addon VALUES 
(286037, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286038;
INSERT INTO creature_addon VALUES 
(286038, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286039;
INSERT INTO creature_addon VALUES 
(286039, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247469;
INSERT INTO creature_addon VALUES 
(247469, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286040;
INSERT INTO creature_addon VALUES 
(286040, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286041;
INSERT INTO creature_addon VALUES 
(286041, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286042;
INSERT INTO creature_addon VALUES 
(286042, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247428;
INSERT INTO creature_addon VALUES 
(247428, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286043;
INSERT INTO creature_addon VALUES 
(286043, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286044;
INSERT INTO creature_addon VALUES 
(286044, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286045;
INSERT INTO creature_addon VALUES 
(286045, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286046;
INSERT INTO creature_addon VALUES 
(286046, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286047;
INSERT INTO creature_addon VALUES 
(286047, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247411;
INSERT INTO creature_addon VALUES 
(247411, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247398;
INSERT INTO creature_addon VALUES 
(247398, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286048;
INSERT INTO creature_addon VALUES 
(286048, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286049;
INSERT INTO creature_addon VALUES 
(286049, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247402;
INSERT INTO creature_addon VALUES 
(247402, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247414;
INSERT INTO creature_addon VALUES 
(247414, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286050;
INSERT INTO creature_addon VALUES 
(286050, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286051;
INSERT INTO creature_addon VALUES 
(286051, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286052;
INSERT INTO creature_addon VALUES 
(286052, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286053;
INSERT INTO creature_addon VALUES 
(286053, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286054;
INSERT INTO creature_addon VALUES 
(286054, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286055;
INSERT INTO creature_addon VALUES 
(286055, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=247405;
INSERT INTO creature_addon VALUES 
(247405, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286056;
INSERT INTO creature_addon VALUES 
(286056, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286057;
INSERT INTO creature_addon VALUES 
(286057, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286058;
INSERT INTO creature_addon VALUES 
(286058, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286059;
INSERT INTO creature_addon VALUES 
(286059, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286060;
INSERT INTO creature_addon VALUES 
(286060, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286061;
INSERT INTO creature_addon VALUES 
(286061, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286062;
INSERT INTO creature_addon VALUES 
(286062, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286063;
INSERT INTO creature_addon VALUES 
(286063, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286064;
INSERT INTO creature_addon VALUES 
(286064, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286065;
INSERT INTO creature_addon VALUES 
(286065, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286066;
INSERT INTO creature_addon VALUES 
(286066, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286067;
INSERT INTO creature_addon VALUES 
(286067, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286068;
INSERT INTO creature_addon VALUES 
(286068, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286069;
INSERT INTO creature_addon VALUES 
(286069, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286070;
INSERT INTO creature_addon VALUES 
(286070, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286071;
INSERT INTO creature_addon VALUES 
(286071, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286072;
INSERT INTO creature_addon VALUES 
(286072, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286073;
INSERT INTO creature_addon VALUES 
(286073, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286074;
INSERT INTO creature_addon VALUES 
(286074, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286075;
INSERT INTO creature_addon VALUES 
(286075, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286076;
INSERT INTO creature_addon VALUES 
(286076, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286077;
INSERT INTO creature_addon VALUES 
(286077, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286078;
INSERT INTO creature_addon VALUES 
(286078, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286079;
INSERT INTO creature_addon VALUES 
(286079, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=286080;
INSERT INTO creature_addon VALUES 
(286080, 0, 0, 0, 1, 0, "71333 72778 72866");

DELETE FROM creature_addon WHERE guid=249204;
INSERT INTO creature_addon VALUES 
(249204, 0, 0, 0, 1, 0, "89842");

DELETE FROM creature_addon WHERE guid=286081;
INSERT INTO creature_addon VALUES 
(286081, 0, 0, 0, 1, 0, "89842");

DELETE FROM creature_addon WHERE guid=286082;
INSERT INTO creature_addon VALUES 
(286082, 0, 0, 0, 1, 0, "89842");

DELETE FROM creature_addon WHERE guid=246074;
INSERT INTO creature_addon VALUES 
(246074, 0, 0, 0, 1, 0, "78273");

DELETE FROM creature_addon WHERE guid=249399;
INSERT INTO creature_addon VALUES 
(249399, 0, 0, 65536, 1, 0, "70268");

DELETE FROM creature_addon WHERE guid=249398;
INSERT INTO creature_addon VALUES 
(249398, 0, 0, 65536, 1, 0, "70268");

DELETE FROM creature_addon WHERE guid=249406;
INSERT INTO creature_addon VALUES 
(249406, 0, 0, 65536, 1, 0, "70268");

DELETE FROM creature_addon WHERE guid=249390;
INSERT INTO creature_addon VALUES 
(249390, 0, 0, 65536, 1, 0, "70268");

DELETE FROM creature_addon WHERE guid=249380;
INSERT INTO creature_addon VALUES 
(249380, 0, 0, 65536, 1, 0, "70268");

DELETE FROM creature_addon WHERE guid=245827;
INSERT INTO creature_addon VALUES 
(245827, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=245831;
INSERT INTO creature_addon VALUES 
(245831, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=286083;
INSERT INTO creature_addon VALUES 
(286083, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=245828;
INSERT INTO creature_addon VALUES 
(245828, 0, 0, 0, 1, 375, "76136");

DELETE FROM creature_addon WHERE guid=286089;
INSERT INTO creature_addon VALUES 
(286089, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246371;
INSERT INTO creature_addon VALUES 
(246371, 0, 0, 0, 2, 0, "85370");

DELETE FROM creature_addon WHERE guid=246306;
INSERT INTO creature_addon VALUES 
(246306, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=286090;
INSERT INTO creature_addon VALUES 
(286090, 0, 0, 0, 2, 0, "85370");

DELETE FROM creature_addon WHERE guid=246385;
INSERT INTO creature_addon VALUES 
(246385, 0, 0, 0, 1, 0, "85370");

DELETE FROM creature_addon WHERE guid=286091;
INSERT INTO creature_addon VALUES 
(286091, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246339;
INSERT INTO creature_addon VALUES 
(246339, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246307;
INSERT INTO creature_addon VALUES 
(246307, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=286092;
INSERT INTO creature_addon VALUES 
(286092, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246310;
INSERT INTO creature_addon VALUES 
(246310, 0, 0, 0, 1, 0, "85370");

DELETE FROM creature_addon WHERE guid=246356;
INSERT INTO creature_addon VALUES 
(246356, 0, 0, 0, 1, 0, "85370");

DELETE FROM creature_addon WHERE guid=246351;
INSERT INTO creature_addon VALUES 
(246351, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=286093;
INSERT INTO creature_addon VALUES 
(286093, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246350;
INSERT INTO creature_addon VALUES 
(246350, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=286094;
INSERT INTO creature_addon VALUES 
(286094, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246328;
INSERT INTO creature_addon VALUES 
(246328, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246329;
INSERT INTO creature_addon VALUES 
(246329, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246374;
INSERT INTO creature_addon VALUES 
(246374, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=286095;
INSERT INTO creature_addon VALUES 
(286095, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246318;
INSERT INTO creature_addon VALUES 
(246318, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=286096;
INSERT INTO creature_addon VALUES 
(286096, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246383;
INSERT INTO creature_addon VALUES 
(246383, 0, 0, 0, 2, 376, "85370");

DELETE FROM creature_addon WHERE guid=246056;
INSERT INTO creature_addon VALUES 
(246056, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246055;
INSERT INTO creature_addon VALUES 
(246055, 0, 0, 1, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286100;
INSERT INTO creature_addon VALUES 
(286100, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246092;
INSERT INTO creature_addon VALUES 
(246092, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=249645;
INSERT INTO creature_addon VALUES 
(249645, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249642;
INSERT INTO creature_addon VALUES 
(249642, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249636;
INSERT INTO creature_addon VALUES 
(249636, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249640;
INSERT INTO creature_addon VALUES 
(249640, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249656;
INSERT INTO creature_addon VALUES 
(249656, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249644;
INSERT INTO creature_addon VALUES 
(249644, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249639;
INSERT INTO creature_addon VALUES 
(249639, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249658;
INSERT INTO creature_addon VALUES 
(249658, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249650;
INSERT INTO creature_addon VALUES 
(249650, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249638;
INSERT INTO creature_addon VALUES 
(249638, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249643;
INSERT INTO creature_addon VALUES 
(249643, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249648;
INSERT INTO creature_addon VALUES 
(249648, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249641;
INSERT INTO creature_addon VALUES 
(249641, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249635;
INSERT INTO creature_addon VALUES 
(249635, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249637;
INSERT INTO creature_addon VALUES 
(249637, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249651;
INSERT INTO creature_addon VALUES 
(249651, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249659;
INSERT INTO creature_addon VALUES 
(249659, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249649;
INSERT INTO creature_addon VALUES 
(249649, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249657;
INSERT INTO creature_addon VALUES 
(249657, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249654;
INSERT INTO creature_addon VALUES 
(249654, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=249655;
INSERT INTO creature_addon VALUES 
(249655, 0, 0, 0, 1, 0, "72939");

DELETE FROM creature_addon WHERE guid=286101;
INSERT INTO creature_addon VALUES 
(286101, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247685;
INSERT INTO creature_addon VALUES 
(247685, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247688;
INSERT INTO creature_addon VALUES 
(247688, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247690;
INSERT INTO creature_addon VALUES 
(247690, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247663;
INSERT INTO creature_addon VALUES 
(247663, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247672;
INSERT INTO creature_addon VALUES 
(247672, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247635;
INSERT INTO creature_addon VALUES 
(247635, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247659;
INSERT INTO creature_addon VALUES 
(247659, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286102;
INSERT INTO creature_addon VALUES 
(286102, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247633;
INSERT INTO creature_addon VALUES 
(247633, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247678;
INSERT INTO creature_addon VALUES 
(247678, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286103;
INSERT INTO creature_addon VALUES 
(286103, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286104;
INSERT INTO creature_addon VALUES 
(286104, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247693;
INSERT INTO creature_addon VALUES 
(247693, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286105;
INSERT INTO creature_addon VALUES 
(286105, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286106;
INSERT INTO creature_addon VALUES 
(286106, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247662;
INSERT INTO creature_addon VALUES 
(247662, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247719;
INSERT INTO creature_addon VALUES 
(247719, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247661;
INSERT INTO creature_addon VALUES 
(247661, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286107;
INSERT INTO creature_addon VALUES 
(286107, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286108;
INSERT INTO creature_addon VALUES 
(286108, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247717;
INSERT INTO creature_addon VALUES 
(247717, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286109;
INSERT INTO creature_addon VALUES 
(286109, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286110;
INSERT INTO creature_addon VALUES 
(286110, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247689;
INSERT INTO creature_addon VALUES 
(247689, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247711;
INSERT INTO creature_addon VALUES 
(247711, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247708;
INSERT INTO creature_addon VALUES 
(247708, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286111;
INSERT INTO creature_addon VALUES 
(286111, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247713;
INSERT INTO creature_addon VALUES 
(247713, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286112;
INSERT INTO creature_addon VALUES 
(286112, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286113;
INSERT INTO creature_addon VALUES 
(286113, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286114;
INSERT INTO creature_addon VALUES 
(286114, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247710;
INSERT INTO creature_addon VALUES 
(247710, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286115;
INSERT INTO creature_addon VALUES 
(286115, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286116;
INSERT INTO creature_addon VALUES 
(286116, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247705;
INSERT INTO creature_addon VALUES 
(247705, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286117;
INSERT INTO creature_addon VALUES 
(286117, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247716;
INSERT INTO creature_addon VALUES 
(247716, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286118;
INSERT INTO creature_addon VALUES 
(286118, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247691;
INSERT INTO creature_addon VALUES 
(247691, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247684;
INSERT INTO creature_addon VALUES 
(247684, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286119;
INSERT INTO creature_addon VALUES 
(286119, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247673;
INSERT INTO creature_addon VALUES 
(247673, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286120;
INSERT INTO creature_addon VALUES 
(286120, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247666;
INSERT INTO creature_addon VALUES 
(247666, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286121;
INSERT INTO creature_addon VALUES 
(286121, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286122;
INSERT INTO creature_addon VALUES 
(286122, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286123;
INSERT INTO creature_addon VALUES 
(286123, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247681;
INSERT INTO creature_addon VALUES 
(247681, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286124;
INSERT INTO creature_addon VALUES 
(286124, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286125;
INSERT INTO creature_addon VALUES 
(286125, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286126;
INSERT INTO creature_addon VALUES 
(286126, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247715;
INSERT INTO creature_addon VALUES 
(247715, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247654;
INSERT INTO creature_addon VALUES 
(247654, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286127;
INSERT INTO creature_addon VALUES 
(286127, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286128;
INSERT INTO creature_addon VALUES 
(286128, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=247634;
INSERT INTO creature_addon VALUES 
(247634, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=249391;
INSERT INTO creature_addon VALUES 
(249391, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=245965;
INSERT INTO creature_addon VALUES 
(245965, 0, 0, 0, 1, 0, "68327 91298");

DELETE FROM creature_addon WHERE guid=1714;
INSERT INTO creature_addon VALUES 
(1714, 0, 0, 65536, 1, 133, "68327 91298");

DELETE FROM creature_addon WHERE guid=1711;
INSERT INTO creature_addon VALUES 
(1711, 0, 0, 0, 1, 133, "68327 91298");

DELETE FROM creature_addon WHERE guid=1713;
INSERT INTO creature_addon VALUES 
(1713, 0, 0, 0, 1, 133, "68327 91298");

DELETE FROM creature_addon WHERE guid=247594;
INSERT INTO creature_addon VALUES 
(247594, 0, 0, 0, 1, 234, "68327 91298");

DELETE FROM creature_addon WHERE guid=1712;
INSERT INTO creature_addon VALUES 
(1712, 0, 0, 0, 1, 0, "68327 91298");

DELETE FROM creature_addon WHERE guid=247867;
INSERT INTO creature_addon VALUES 
(247867, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286132;
INSERT INTO creature_addon VALUES 
(286132, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247851;
INSERT INTO creature_addon VALUES 
(247851, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247846;
INSERT INTO creature_addon VALUES 
(247846, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247849;
INSERT INTO creature_addon VALUES 
(247849, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247862;
INSERT INTO creature_addon VALUES 
(247862, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247860;
INSERT INTO creature_addon VALUES 
(247860, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286133;
INSERT INTO creature_addon VALUES 
(286133, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247847;
INSERT INTO creature_addon VALUES 
(247847, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286134;
INSERT INTO creature_addon VALUES 
(286134, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286135;
INSERT INTO creature_addon VALUES 
(286135, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247869;
INSERT INTO creature_addon VALUES 
(247869, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247845;
INSERT INTO creature_addon VALUES 
(247845, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247865;
INSERT INTO creature_addon VALUES 
(247865, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247850;
INSERT INTO creature_addon VALUES 
(247850, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286136;
INSERT INTO creature_addon VALUES 
(286136, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247842;
INSERT INTO creature_addon VALUES 
(247842, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286137;
INSERT INTO creature_addon VALUES 
(286137, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247844;
INSERT INTO creature_addon VALUES 
(247844, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286138;
INSERT INTO creature_addon VALUES 
(286138, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247838;
INSERT INTO creature_addon VALUES 
(247838, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247839;
INSERT INTO creature_addon VALUES 
(247839, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286139;
INSERT INTO creature_addon VALUES 
(286139, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247864;
INSERT INTO creature_addon VALUES 
(247864, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286140;
INSERT INTO creature_addon VALUES 
(286140, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286141;
INSERT INTO creature_addon VALUES 
(286141, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286142;
INSERT INTO creature_addon VALUES 
(286142, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247843;
INSERT INTO creature_addon VALUES 
(247843, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286143;
INSERT INTO creature_addon VALUES 
(286143, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286144;
INSERT INTO creature_addon VALUES 
(286144, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286145;
INSERT INTO creature_addon VALUES 
(286145, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247852;
INSERT INTO creature_addon VALUES 
(247852, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247861;
INSERT INTO creature_addon VALUES 
(247861, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286146;
INSERT INTO creature_addon VALUES 
(286146, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247853;
INSERT INTO creature_addon VALUES 
(247853, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247840;
INSERT INTO creature_addon VALUES 
(247840, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247863;
INSERT INTO creature_addon VALUES 
(247863, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247857;
INSERT INTO creature_addon VALUES 
(247857, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247848;
INSERT INTO creature_addon VALUES 
(247848, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286147;
INSERT INTO creature_addon VALUES 
(286147, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247854;
INSERT INTO creature_addon VALUES 
(247854, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=247856;
INSERT INTO creature_addon VALUES 
(247856, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286148;
INSERT INTO creature_addon VALUES 
(286148, 0, 0, 0, 1, 0, "78715");

DELETE FROM creature_addon WHERE guid=245967;
INSERT INTO creature_addon VALUES 
(245967, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=5807;
INSERT INTO creature_addon VALUES 
(5807, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=5808;
INSERT INTO creature_addon VALUES 
(5808, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=5805;
INSERT INTO creature_addon VALUES 
(5805, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=246081;
INSERT INTO creature_addon VALUES 
(246081, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=286187;
INSERT INTO creature_addon VALUES 
(286187, 0, 0, 0, 1, 0, "29266 65734");

DELETE FROM creature_addon WHERE guid=247599;
INSERT INTO creature_addon VALUES 
(247599, 0, 0, 0, 1, 0, "29266 65734");

UPDATE creature_addon SET auras="29266 54219" WHERE guid=249535;
DELETE FROM creature_addon WHERE guid=286188;
INSERT INTO creature_addon VALUES 
(286188, 0, 0, 0, 1, 0, "75098");

DELETE FROM creature_addon WHERE guid=249340;
INSERT INTO creature_addon VALUES 
(249340, 0, 0, 0, 1, 0, "75098");

DELETE FROM creature_addon WHERE guid=286189;
INSERT INTO creature_addon VALUES 
(286189, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=248942;
INSERT INTO creature_addon VALUES 
(248942, 0, 0, 0, 1, 431, "");

DELETE FROM creature_addon WHERE guid=286215;
INSERT INTO creature_addon VALUES 
(286215, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286216;
INSERT INTO creature_addon VALUES 
(286216, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286224;
INSERT INTO creature_addon VALUES 
(286224, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286225;
INSERT INTO creature_addon VALUES 
(286225, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286226;
INSERT INTO creature_addon VALUES 
(286226, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248685;
INSERT INTO creature_addon VALUES 
(248685, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248689;
INSERT INTO creature_addon VALUES 
(248689, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286227;
INSERT INTO creature_addon VALUES 
(286227, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248688;
INSERT INTO creature_addon VALUES 
(248688, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286228;
INSERT INTO creature_addon VALUES 
(286228, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248684;
INSERT INTO creature_addon VALUES 
(248684, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286229;
INSERT INTO creature_addon VALUES 
(286229, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245351;
INSERT INTO creature_addon VALUES 
(245351, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286230;
INSERT INTO creature_addon VALUES 
(286230, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286231;
INSERT INTO creature_addon VALUES 
(286231, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245356;
INSERT INTO creature_addon VALUES 
(245356, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245367;
INSERT INTO creature_addon VALUES 
(245367, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245353;
INSERT INTO creature_addon VALUES 
(245353, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248690;
INSERT INTO creature_addon VALUES 
(248690, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286232;
INSERT INTO creature_addon VALUES 
(286232, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248655;
INSERT INTO creature_addon VALUES 
(248655, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245362;
INSERT INTO creature_addon VALUES 
(245362, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245349;
INSERT INTO creature_addon VALUES 
(245349, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286233;
INSERT INTO creature_addon VALUES 
(286233, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245354;
INSERT INTO creature_addon VALUES 
(245354, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248731;
INSERT INTO creature_addon VALUES 
(248731, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248721;
INSERT INTO creature_addon VALUES 
(248721, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286234;
INSERT INTO creature_addon VALUES 
(286234, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245350;
INSERT INTO creature_addon VALUES 
(245350, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286235;
INSERT INTO creature_addon VALUES 
(286235, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248657;
INSERT INTO creature_addon VALUES 
(248657, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286236;
INSERT INTO creature_addon VALUES 
(286236, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286237;
INSERT INTO creature_addon VALUES 
(286237, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248687;
INSERT INTO creature_addon VALUES 
(248687, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286238;
INSERT INTO creature_addon VALUES 
(286238, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286239;
INSERT INTO creature_addon VALUES 
(286239, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286240;
INSERT INTO creature_addon VALUES 
(286240, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286241;
INSERT INTO creature_addon VALUES 
(286241, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=245373;
INSERT INTO creature_addon VALUES 
(245373, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286242;
INSERT INTO creature_addon VALUES 
(286242, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=249048;
INSERT INTO creature_addon VALUES 
(249048, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286243;
INSERT INTO creature_addon VALUES 
(286243, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286244;
INSERT INTO creature_addon VALUES 
(286244, 0, 0, 65536, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286245;
INSERT INTO creature_addon VALUES 
(286245, 0, 0, 50397184, 1, 0, "");

DELETE FROM creature_addon WHERE guid=249131;
INSERT INTO creature_addon VALUES 
(249131, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=249132;
INSERT INTO creature_addon VALUES 
(249132, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=249135;
INSERT INTO creature_addon VALUES 
(249135, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=249144;
INSERT INTO creature_addon VALUES 
(249144, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=249143;
INSERT INTO creature_addon VALUES 
(249143, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=249137;
INSERT INTO creature_addon VALUES 
(249137, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=249128;
INSERT INTO creature_addon VALUES 
(249128, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=249134;
INSERT INTO creature_addon VALUES 
(249134, 0, 0, 0, 1, 233, "");

DELETE FROM creature_addon WHERE guid=286248;
INSERT INTO creature_addon VALUES 
(286248, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286249;
INSERT INTO creature_addon VALUES 
(286249, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247042;
INSERT INTO creature_addon VALUES 
(247042, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247181;
INSERT INTO creature_addon VALUES 
(247181, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247147;
INSERT INTO creature_addon VALUES 
(247147, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286250;
INSERT INTO creature_addon VALUES 
(286250, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286251;
INSERT INTO creature_addon VALUES 
(286251, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246896;
INSERT INTO creature_addon VALUES 
(246896, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247107;
INSERT INTO creature_addon VALUES 
(247107, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286252;
INSERT INTO creature_addon VALUES 
(286252, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286253;
INSERT INTO creature_addon VALUES 
(286253, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247184;
INSERT INTO creature_addon VALUES 
(247184, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286254;
INSERT INTO creature_addon VALUES 
(286254, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286255;
INSERT INTO creature_addon VALUES 
(286255, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286256;
INSERT INTO creature_addon VALUES 
(286256, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246877;
INSERT INTO creature_addon VALUES 
(246877, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247116;
INSERT INTO creature_addon VALUES 
(247116, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247150;
INSERT INTO creature_addon VALUES 
(247150, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286257;
INSERT INTO creature_addon VALUES 
(286257, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286258;
INSERT INTO creature_addon VALUES 
(286258, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246869;
INSERT INTO creature_addon VALUES 
(246869, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286259;
INSERT INTO creature_addon VALUES 
(286259, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286260;
INSERT INTO creature_addon VALUES 
(286260, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286261;
INSERT INTO creature_addon VALUES 
(286261, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247000;
INSERT INTO creature_addon VALUES 
(247000, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286262;
INSERT INTO creature_addon VALUES 
(286262, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286263;
INSERT INTO creature_addon VALUES 
(286263, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247179;
INSERT INTO creature_addon VALUES 
(247179, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286264;
INSERT INTO creature_addon VALUES 
(286264, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246939;
INSERT INTO creature_addon VALUES 
(246939, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286265;
INSERT INTO creature_addon VALUES 
(286265, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286266;
INSERT INTO creature_addon VALUES 
(286266, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286267;
INSERT INTO creature_addon VALUES 
(286267, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247098;
INSERT INTO creature_addon VALUES 
(247098, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286268;
INSERT INTO creature_addon VALUES 
(286268, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286269;
INSERT INTO creature_addon VALUES 
(286269, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286270;
INSERT INTO creature_addon VALUES 
(286270, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286271;
INSERT INTO creature_addon VALUES 
(286271, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247182;
INSERT INTO creature_addon VALUES 
(247182, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246981;
INSERT INTO creature_addon VALUES 
(246981, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246966;
INSERT INTO creature_addon VALUES 
(246966, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286272;
INSERT INTO creature_addon VALUES 
(286272, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247183;
INSERT INTO creature_addon VALUES 
(247183, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286273;
INSERT INTO creature_addon VALUES 
(286273, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286274;
INSERT INTO creature_addon VALUES 
(286274, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286275;
INSERT INTO creature_addon VALUES 
(286275, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247118;
INSERT INTO creature_addon VALUES 
(247118, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286276;
INSERT INTO creature_addon VALUES 
(286276, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286277;
INSERT INTO creature_addon VALUES 
(286277, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286278;
INSERT INTO creature_addon VALUES 
(286278, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246929;
INSERT INTO creature_addon VALUES 
(246929, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286279;
INSERT INTO creature_addon VALUES 
(286279, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286280;
INSERT INTO creature_addon VALUES 
(286280, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247128;
INSERT INTO creature_addon VALUES 
(247128, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286281;
INSERT INTO creature_addon VALUES 
(286281, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286282;
INSERT INTO creature_addon VALUES 
(286282, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286283;
INSERT INTO creature_addon VALUES 
(286283, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247100;
INSERT INTO creature_addon VALUES 
(247100, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286284;
INSERT INTO creature_addon VALUES 
(286284, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246881;
INSERT INTO creature_addon VALUES 
(246881, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246892;
INSERT INTO creature_addon VALUES 
(246892, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286285;
INSERT INTO creature_addon VALUES 
(286285, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247121;
INSERT INTO creature_addon VALUES 
(247121, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286286;
INSERT INTO creature_addon VALUES 
(286286, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286287;
INSERT INTO creature_addon VALUES 
(286287, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286288;
INSERT INTO creature_addon VALUES 
(286288, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247109;
INSERT INTO creature_addon VALUES 
(247109, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286289;
INSERT INTO creature_addon VALUES 
(286289, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286290;
INSERT INTO creature_addon VALUES 
(286290, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286291;
INSERT INTO creature_addon VALUES 
(286291, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286292;
INSERT INTO creature_addon VALUES 
(286292, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286293;
INSERT INTO creature_addon VALUES 
(286293, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286294;
INSERT INTO creature_addon VALUES 
(286294, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286295;
INSERT INTO creature_addon VALUES 
(286295, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247158;
INSERT INTO creature_addon VALUES 
(247158, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247159;
INSERT INTO creature_addon VALUES 
(247159, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286296;
INSERT INTO creature_addon VALUES 
(286296, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247127;
INSERT INTO creature_addon VALUES 
(247127, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286297;
INSERT INTO creature_addon VALUES 
(286297, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286298;
INSERT INTO creature_addon VALUES 
(286298, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286299;
INSERT INTO creature_addon VALUES 
(286299, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247099;
INSERT INTO creature_addon VALUES 
(247099, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286300;
INSERT INTO creature_addon VALUES 
(286300, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286301;
INSERT INTO creature_addon VALUES 
(286301, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246955;
INSERT INTO creature_addon VALUES 
(246955, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286302;
INSERT INTO creature_addon VALUES 
(286302, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286303;
INSERT INTO creature_addon VALUES 
(286303, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286304;
INSERT INTO creature_addon VALUES 
(286304, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246879;
INSERT INTO creature_addon VALUES 
(246879, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246969;
INSERT INTO creature_addon VALUES 
(246969, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286305;
INSERT INTO creature_addon VALUES 
(286305, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247153;
INSERT INTO creature_addon VALUES 
(247153, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247112;
INSERT INTO creature_addon VALUES 
(247112, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286306;
INSERT INTO creature_addon VALUES 
(286306, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247145;
INSERT INTO creature_addon VALUES 
(247145, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286307;
INSERT INTO creature_addon VALUES 
(286307, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286308;
INSERT INTO creature_addon VALUES 
(286308, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286309;
INSERT INTO creature_addon VALUES 
(286309, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286310;
INSERT INTO creature_addon VALUES 
(286310, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286311;
INSERT INTO creature_addon VALUES 
(286311, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286312;
INSERT INTO creature_addon VALUES 
(286312, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286313;
INSERT INTO creature_addon VALUES 
(286313, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286314;
INSERT INTO creature_addon VALUES 
(286314, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286315;
INSERT INTO creature_addon VALUES 
(286315, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286316;
INSERT INTO creature_addon VALUES 
(286316, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286317;
INSERT INTO creature_addon VALUES 
(286317, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286318;
INSERT INTO creature_addon VALUES 
(286318, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246963;
INSERT INTO creature_addon VALUES 
(246963, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247148;
INSERT INTO creature_addon VALUES 
(247148, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246866;
INSERT INTO creature_addon VALUES 
(246866, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286319;
INSERT INTO creature_addon VALUES 
(286319, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247062;
INSERT INTO creature_addon VALUES 
(247062, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286321;
INSERT INTO creature_addon VALUES 
(286321, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286322;
INSERT INTO creature_addon VALUES 
(286322, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286323;
INSERT INTO creature_addon VALUES 
(286323, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247024;
INSERT INTO creature_addon VALUES 
(247024, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286324;
INSERT INTO creature_addon VALUES 
(286324, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286325;
INSERT INTO creature_addon VALUES 
(286325, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246961;
INSERT INTO creature_addon VALUES 
(246961, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246923;
INSERT INTO creature_addon VALUES 
(246923, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286326;
INSERT INTO creature_addon VALUES 
(286326, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286327;
INSERT INTO creature_addon VALUES 
(286327, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286328;
INSERT INTO creature_addon VALUES 
(286328, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246864;
INSERT INTO creature_addon VALUES 
(246864, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246953;
INSERT INTO creature_addon VALUES 
(246953, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246941;
INSERT INTO creature_addon VALUES 
(246941, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286329;
INSERT INTO creature_addon VALUES 
(286329, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286330;
INSERT INTO creature_addon VALUES 
(286330, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246937;
INSERT INTO creature_addon VALUES 
(246937, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286331;
INSERT INTO creature_addon VALUES 
(286331, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286332;
INSERT INTO creature_addon VALUES 
(286332, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286333;
INSERT INTO creature_addon VALUES 
(286333, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247057;
INSERT INTO creature_addon VALUES 
(247057, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247035;
INSERT INTO creature_addon VALUES 
(247035, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286334;
INSERT INTO creature_addon VALUES 
(286334, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247120;
INSERT INTO creature_addon VALUES 
(247120, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246980;
INSERT INTO creature_addon VALUES 
(246980, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286335;
INSERT INTO creature_addon VALUES 
(286335, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246880;
INSERT INTO creature_addon VALUES 
(246880, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286336;
INSERT INTO creature_addon VALUES 
(286336, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286337;
INSERT INTO creature_addon VALUES 
(286337, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286338;
INSERT INTO creature_addon VALUES 
(286338, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286339;
INSERT INTO creature_addon VALUES 
(286339, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286340;
INSERT INTO creature_addon VALUES 
(286340, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286341;
INSERT INTO creature_addon VALUES 
(286341, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246928;
INSERT INTO creature_addon VALUES 
(246928, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286342;
INSERT INTO creature_addon VALUES 
(286342, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286343;
INSERT INTO creature_addon VALUES 
(286343, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247157;
INSERT INTO creature_addon VALUES 
(247157, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247064;
INSERT INTO creature_addon VALUES 
(247064, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286344;
INSERT INTO creature_addon VALUES 
(286344, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247146;
INSERT INTO creature_addon VALUES 
(247146, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286345;
INSERT INTO creature_addon VALUES 
(286345, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286346;
INSERT INTO creature_addon VALUES 
(286346, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286347;
INSERT INTO creature_addon VALUES 
(286347, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286348;
INSERT INTO creature_addon VALUES 
(286348, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248057;
INSERT INTO creature_addon VALUES 
(248057, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247055;
INSERT INTO creature_addon VALUES 
(247055, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247056;
INSERT INTO creature_addon VALUES 
(247056, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286349;
INSERT INTO creature_addon VALUES 
(286349, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286350;
INSERT INTO creature_addon VALUES 
(286350, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286351;
INSERT INTO creature_addon VALUES 
(286351, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286352;
INSERT INTO creature_addon VALUES 
(286352, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247106;
INSERT INTO creature_addon VALUES 
(247106, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246872;
INSERT INTO creature_addon VALUES 
(246872, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246875;
INSERT INTO creature_addon VALUES 
(246875, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286353;
INSERT INTO creature_addon VALUES 
(286353, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247094;
INSERT INTO creature_addon VALUES 
(247094, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286354;
INSERT INTO creature_addon VALUES 
(286354, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286355;
INSERT INTO creature_addon VALUES 
(286355, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246992;
INSERT INTO creature_addon VALUES 
(246992, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286356;
INSERT INTO creature_addon VALUES 
(286356, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247163;
INSERT INTO creature_addon VALUES 
(247163, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247038;
INSERT INTO creature_addon VALUES 
(247038, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286357;
INSERT INTO creature_addon VALUES 
(286357, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247054;
INSERT INTO creature_addon VALUES 
(247054, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286358;
INSERT INTO creature_addon VALUES 
(286358, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286359;
INSERT INTO creature_addon VALUES 
(286359, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286360;
INSERT INTO creature_addon VALUES 
(286360, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286361;
INSERT INTO creature_addon VALUES 
(286361, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247111;
INSERT INTO creature_addon VALUES 
(247111, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286362;
INSERT INTO creature_addon VALUES 
(286362, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286363;
INSERT INTO creature_addon VALUES 
(286363, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286364;
INSERT INTO creature_addon VALUES 
(286364, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286365;
INSERT INTO creature_addon VALUES 
(286365, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286366;
INSERT INTO creature_addon VALUES 
(286366, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246871;
INSERT INTO creature_addon VALUES 
(246871, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286367;
INSERT INTO creature_addon VALUES 
(286367, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246938;
INSERT INTO creature_addon VALUES 
(246938, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286368;
INSERT INTO creature_addon VALUES 
(286368, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246873;
INSERT INTO creature_addon VALUES 
(246873, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246932;
INSERT INTO creature_addon VALUES 
(246932, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246934;
INSERT INTO creature_addon VALUES 
(246934, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286369;
INSERT INTO creature_addon VALUES 
(286369, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286370;
INSERT INTO creature_addon VALUES 
(286370, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247108;
INSERT INTO creature_addon VALUES 
(247108, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286371;
INSERT INTO creature_addon VALUES 
(286371, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286372;
INSERT INTO creature_addon VALUES 
(286372, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286373;
INSERT INTO creature_addon VALUES 
(286373, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246931;
INSERT INTO creature_addon VALUES 
(246931, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247166;
INSERT INTO creature_addon VALUES 
(247166, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247164;
INSERT INTO creature_addon VALUES 
(247164, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286374;
INSERT INTO creature_addon VALUES 
(286374, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246979;
INSERT INTO creature_addon VALUES 
(246979, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286375;
INSERT INTO creature_addon VALUES 
(286375, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286376;
INSERT INTO creature_addon VALUES 
(286376, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286377;
INSERT INTO creature_addon VALUES 
(286377, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286378;
INSERT INTO creature_addon VALUES 
(286378, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286379;
INSERT INTO creature_addon VALUES 
(286379, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286380;
INSERT INTO creature_addon VALUES 
(286380, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246913;
INSERT INTO creature_addon VALUES 
(246913, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286381;
INSERT INTO creature_addon VALUES 
(286381, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286382;
INSERT INTO creature_addon VALUES 
(286382, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286383;
INSERT INTO creature_addon VALUES 
(286383, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286384;
INSERT INTO creature_addon VALUES 
(286384, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286385;
INSERT INTO creature_addon VALUES 
(286385, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247095;
INSERT INTO creature_addon VALUES 
(247095, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286386;
INSERT INTO creature_addon VALUES 
(286386, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286387;
INSERT INTO creature_addon VALUES 
(286387, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286388;
INSERT INTO creature_addon VALUES 
(286388, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286389;
INSERT INTO creature_addon VALUES 
(286389, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246935;
INSERT INTO creature_addon VALUES 
(246935, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286390;
INSERT INTO creature_addon VALUES 
(286390, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247115;
INSERT INTO creature_addon VALUES 
(247115, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286391;
INSERT INTO creature_addon VALUES 
(286391, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286392;
INSERT INTO creature_addon VALUES 
(286392, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247023;
INSERT INTO creature_addon VALUES 
(247023, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286393;
INSERT INTO creature_addon VALUES 
(286393, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286394;
INSERT INTO creature_addon VALUES 
(286394, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286395;
INSERT INTO creature_addon VALUES 
(286395, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286396;
INSERT INTO creature_addon VALUES 
(286396, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247141;
INSERT INTO creature_addon VALUES 
(247141, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247105;
INSERT INTO creature_addon VALUES 
(247105, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286397;
INSERT INTO creature_addon VALUES 
(286397, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247180;
INSERT INTO creature_addon VALUES 
(247180, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246901;
INSERT INTO creature_addon VALUES 
(246901, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286398;
INSERT INTO creature_addon VALUES 
(286398, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246990;
INSERT INTO creature_addon VALUES 
(246990, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286399;
INSERT INTO creature_addon VALUES 
(286399, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246912;
INSERT INTO creature_addon VALUES 
(246912, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286400;
INSERT INTO creature_addon VALUES 
(286400, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247117;
INSERT INTO creature_addon VALUES 
(247117, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246893;
INSERT INTO creature_addon VALUES 
(246893, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246933;
INSERT INTO creature_addon VALUES 
(246933, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286401;
INSERT INTO creature_addon VALUES 
(286401, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286402;
INSERT INTO creature_addon VALUES 
(286402, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286403;
INSERT INTO creature_addon VALUES 
(286403, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286404;
INSERT INTO creature_addon VALUES 
(286404, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286405;
INSERT INTO creature_addon VALUES 
(286405, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246890;
INSERT INTO creature_addon VALUES 
(246890, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247028;
INSERT INTO creature_addon VALUES 
(247028, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286406;
INSERT INTO creature_addon VALUES 
(286406, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286407;
INSERT INTO creature_addon VALUES 
(286407, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286408;
INSERT INTO creature_addon VALUES 
(286408, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286409;
INSERT INTO creature_addon VALUES 
(286409, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286411;
INSERT INTO creature_addon VALUES 
(286411, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247114;
INSERT INTO creature_addon VALUES 
(247114, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286412;
INSERT INTO creature_addon VALUES 
(286412, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247186;
INSERT INTO creature_addon VALUES 
(247186, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247104;
INSERT INTO creature_addon VALUES 
(247104, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286413;
INSERT INTO creature_addon VALUES 
(286413, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286414;
INSERT INTO creature_addon VALUES 
(286414, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286415;
INSERT INTO creature_addon VALUES 
(286415, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286416;
INSERT INTO creature_addon VALUES 
(286416, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286417;
INSERT INTO creature_addon VALUES 
(286417, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247143;
INSERT INTO creature_addon VALUES 
(247143, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286418;
INSERT INTO creature_addon VALUES 
(286418, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247119;
INSERT INTO creature_addon VALUES 
(247119, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286419;
INSERT INTO creature_addon VALUES 
(286419, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247162;
INSERT INTO creature_addon VALUES 
(247162, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286420;
INSERT INTO creature_addon VALUES 
(286420, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286421;
INSERT INTO creature_addon VALUES 
(286421, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247034;
INSERT INTO creature_addon VALUES 
(247034, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=246874;
INSERT INTO creature_addon VALUES 
(246874, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286422;
INSERT INTO creature_addon VALUES 
(286422, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286423;
INSERT INTO creature_addon VALUES 
(286423, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286424;
INSERT INTO creature_addon VALUES 
(286424, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286425;
INSERT INTO creature_addon VALUES 
(286425, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286426;
INSERT INTO creature_addon VALUES 
(286426, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247063;
INSERT INTO creature_addon VALUES 
(247063, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286427;
INSERT INTO creature_addon VALUES 
(286427, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=247129;
INSERT INTO creature_addon VALUES 
(247129, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286428;
INSERT INTO creature_addon VALUES 
(286428, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286429;
INSERT INTO creature_addon VALUES 
(286429, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286451;
INSERT INTO creature_addon VALUES 
(286451, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286452;
INSERT INTO creature_addon VALUES 
(286452, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286453;
INSERT INTO creature_addon VALUES 
(286453, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286454;
INSERT INTO creature_addon VALUES 
(286454, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286455;
INSERT INTO creature_addon VALUES 
(286455, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286456;
INSERT INTO creature_addon VALUES 
(286456, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286457;
INSERT INTO creature_addon VALUES 
(286457, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286458;
INSERT INTO creature_addon VALUES 
(286458, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286459;
INSERT INTO creature_addon VALUES 
(286459, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=248639;
INSERT INTO creature_addon VALUES 
(248639, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286460;
INSERT INTO creature_addon VALUES 
(286460, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286461;
INSERT INTO creature_addon VALUES 
(286461, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286462;
INSERT INTO creature_addon VALUES 
(286462, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286463;
INSERT INTO creature_addon VALUES 
(286463, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286464;
INSERT INTO creature_addon VALUES 
(286464, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286465;
INSERT INTO creature_addon VALUES 
(286465, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286466;
INSERT INTO creature_addon VALUES 
(286466, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286467;
INSERT INTO creature_addon VALUES 
(286467, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286468;
INSERT INTO creature_addon VALUES 
(286468, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286469;
INSERT INTO creature_addon VALUES 
(286469, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286470;
INSERT INTO creature_addon VALUES 
(286470, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286471;
INSERT INTO creature_addon VALUES 
(286471, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286472;
INSERT INTO creature_addon VALUES 
(286472, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286473;
INSERT INTO creature_addon VALUES 
(286473, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286474;
INSERT INTO creature_addon VALUES 
(286474, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286475;
INSERT INTO creature_addon VALUES 
(286475, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286476;
INSERT INTO creature_addon VALUES 
(286476, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286477;
INSERT INTO creature_addon VALUES 
(286477, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286478;
INSERT INTO creature_addon VALUES 
(286478, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286479;
INSERT INTO creature_addon VALUES 
(286479, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286480;
INSERT INTO creature_addon VALUES 
(286480, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286481;
INSERT INTO creature_addon VALUES 
(286481, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286482;
INSERT INTO creature_addon VALUES 
(286482, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286483;
INSERT INTO creature_addon VALUES 
(286483, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=248580;
INSERT INTO creature_addon VALUES 
(248580, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286484;
INSERT INTO creature_addon VALUES 
(286484, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286485;
INSERT INTO creature_addon VALUES 
(286485, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286486;
INSERT INTO creature_addon VALUES 
(286486, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286487;
INSERT INTO creature_addon VALUES 
(286487, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286488;
INSERT INTO creature_addon VALUES 
(286488, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286489;
INSERT INTO creature_addon VALUES 
(286489, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286490;
INSERT INTO creature_addon VALUES 
(286490, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286491;
INSERT INTO creature_addon VALUES 
(286491, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286492;
INSERT INTO creature_addon VALUES 
(286492, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286493;
INSERT INTO creature_addon VALUES 
(286493, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286494;
INSERT INTO creature_addon VALUES 
(286494, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=248613;
INSERT INTO creature_addon VALUES 
(248613, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286495;
INSERT INTO creature_addon VALUES 
(286495, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286496;
INSERT INTO creature_addon VALUES 
(286496, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286497;
INSERT INTO creature_addon VALUES 
(286497, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286498;
INSERT INTO creature_addon VALUES 
(286498, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286499;
INSERT INTO creature_addon VALUES 
(286499, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286500;
INSERT INTO creature_addon VALUES 
(286500, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286501;
INSERT INTO creature_addon VALUES 
(286501, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286502;
INSERT INTO creature_addon VALUES 
(286502, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286503;
INSERT INTO creature_addon VALUES 
(286503, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286504;
INSERT INTO creature_addon VALUES 
(286504, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286505;
INSERT INTO creature_addon VALUES 
(286505, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286506;
INSERT INTO creature_addon VALUES 
(286506, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=248629;
INSERT INTO creature_addon VALUES 
(248629, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286507;
INSERT INTO creature_addon VALUES 
(286507, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286508;
INSERT INTO creature_addon VALUES 
(286508, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286509;
INSERT INTO creature_addon VALUES 
(286509, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286510;
INSERT INTO creature_addon VALUES 
(286510, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286511;
INSERT INTO creature_addon VALUES 
(286511, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286512;
INSERT INTO creature_addon VALUES 
(286512, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=286513;
INSERT INTO creature_addon VALUES 
(286513, 0, 0, 50331648, 1, 0, "68327 76354");

DELETE FROM creature_addon WHERE guid=248988;
INSERT INTO creature_addon VALUES 
(248988, 0, 0, 1, 1, 0, "");

DELETE FROM creature_addon WHERE guid=247351;
INSERT INTO creature_addon VALUES 
(247351, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286514;
INSERT INTO creature_addon VALUES 
(286514, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286515;
INSERT INTO creature_addon VALUES 
(286515, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286516;
INSERT INTO creature_addon VALUES 
(286516, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286517;
INSERT INTO creature_addon VALUES 
(286517, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286518;
INSERT INTO creature_addon VALUES 
(286518, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286519;
INSERT INTO creature_addon VALUES 
(286519, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286520;
INSERT INTO creature_addon VALUES 
(286520, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286521;
INSERT INTO creature_addon VALUES 
(286521, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286522;
INSERT INTO creature_addon VALUES 
(286522, 0, 0, 0, 1, 0, "76371");

UPDATE creature_addon SET path_id=249327 WHERE guid=249327;
DELETE FROM creature_addon WHERE guid=248027;
INSERT INTO creature_addon VALUES 
(248027, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=286545;
INSERT INTO creature_addon VALUES 
(286545, 0, 0, 0, 1, 0, "76371");

DELETE FROM creature_addon WHERE guid=245986;
INSERT INTO creature_addon VALUES 
(245986, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=286548;
INSERT INTO creature_addon VALUES 
(286548, 0, 0, 0, 1, 0, "76354");

DELETE FROM creature_addon WHERE guid=248906;
INSERT INTO creature_addon VALUES 
(248906, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248894;
INSERT INTO creature_addon VALUES 
(248894, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248897;
INSERT INTO creature_addon VALUES 
(248897, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248895;
INSERT INTO creature_addon VALUES 
(248895, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248403;
INSERT INTO creature_addon VALUES 
(248403, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248405;
INSERT INTO creature_addon VALUES 
(248405, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248910;
INSERT INTO creature_addon VALUES 
(248910, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248404;
INSERT INTO creature_addon VALUES 
(248404, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248913;
INSERT INTO creature_addon VALUES 
(248913, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=286625;
INSERT INTO creature_addon VALUES 
(286625, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248914;
INSERT INTO creature_addon VALUES 
(248914, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248912;
INSERT INTO creature_addon VALUES 
(248912, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248410;
INSERT INTO creature_addon VALUES 
(248410, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248896;
INSERT INTO creature_addon VALUES 
(248896, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248407;
INSERT INTO creature_addon VALUES 
(248407, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248408;
INSERT INTO creature_addon VALUES 
(248408, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248911;
INSERT INTO creature_addon VALUES 
(248911, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248400;
INSERT INTO creature_addon VALUES 
(248400, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248909;
INSERT INTO creature_addon VALUES 
(248909, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248905;
INSERT INTO creature_addon VALUES 
(248905, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248406;
INSERT INTO creature_addon VALUES 
(248406, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=248907;
INSERT INTO creature_addon VALUES 
(248907, 0, 0, 0, 1, 0, "76136");

DELETE FROM creature_addon WHERE guid=286626;
INSERT INTO creature_addon VALUES 
(286626, 0, 0, 0, 1, 0, "73080");

DELETE FROM creature_addon WHERE guid=286627;
INSERT INTO creature_addon VALUES 
(286627, 0, 0, 0, 1, 0, "73080");

DELETE FROM creature_addon WHERE guid=286628;
INSERT INTO creature_addon VALUES 
(286628, 0, 0, 0, 1, 0, "73080");

DELETE FROM creature_addon WHERE guid=286629;
INSERT INTO creature_addon VALUES 
(286629, 0, 0, 0, 1, 0, "73080");

DELETE FROM creature_addon WHERE guid=286630;
INSERT INTO creature_addon VALUES 
(286630, 0, 0, 0, 1, 0, "73080");

DELETE FROM creature_addon WHERE guid=286631;
INSERT INTO creature_addon VALUES 
(286631, 0, 0, 0, 1, 0, "73080");

DELETE FROM creature_addon WHERE guid=286632;
INSERT INTO creature_addon VALUES 
(286632, 0, 0, 0, 1, 0, "73080");

DELETE FROM creature_addon WHERE guid=286633;
INSERT INTO creature_addon VALUES 
(286633, 0, 0, 0, 1, 0, "73080");

DELETE FROM creature_addon WHERE guid=249464;
INSERT INTO creature_addon VALUES 
(249464, 0, 0, 50397184, 1, 0, "68231");

DELETE FROM creature_addon WHERE guid=286634;
INSERT INTO creature_addon VALUES 
(286634, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286635;
INSERT INTO creature_addon VALUES 
(286635, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286636;
INSERT INTO creature_addon VALUES 
(286636, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286637;
INSERT INTO creature_addon VALUES 
(286637, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286638;
INSERT INTO creature_addon VALUES 
(286638, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246715;
INSERT INTO creature_addon VALUES 
(246715, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286639;
INSERT INTO creature_addon VALUES 
(286639, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286640;
INSERT INTO creature_addon VALUES 
(286640, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286641;
INSERT INTO creature_addon VALUES 
(286641, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246586;
INSERT INTO creature_addon VALUES 
(246586, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246580;
INSERT INTO creature_addon VALUES 
(246580, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246577;
INSERT INTO creature_addon VALUES 
(246577, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286642;
INSERT INTO creature_addon VALUES 
(286642, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286643;
INSERT INTO creature_addon VALUES 
(286643, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286644;
INSERT INTO creature_addon VALUES 
(286644, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286645;
INSERT INTO creature_addon VALUES 
(286645, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246583;
INSERT INTO creature_addon VALUES 
(246583, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246596;
INSERT INTO creature_addon VALUES 
(246596, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246593;
INSERT INTO creature_addon VALUES 
(246593, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246581;
INSERT INTO creature_addon VALUES 
(246581, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=246588;
INSERT INTO creature_addon VALUES 
(246588, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286646;
INSERT INTO creature_addon VALUES 
(286646, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286647;
INSERT INTO creature_addon VALUES 
(286647, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286648;
INSERT INTO creature_addon VALUES 
(286648, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286649;
INSERT INTO creature_addon VALUES 
(286649, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286650;
INSERT INTO creature_addon VALUES 
(286650, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286651;
INSERT INTO creature_addon VALUES 
(286651, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286652;
INSERT INTO creature_addon VALUES 
(286652, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286653;
INSERT INTO creature_addon VALUES 
(286653, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286654;
INSERT INTO creature_addon VALUES 
(286654, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286655;
INSERT INTO creature_addon VALUES 
(286655, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286656;
INSERT INTO creature_addon VALUES 
(286656, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286657;
INSERT INTO creature_addon VALUES 
(286657, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286658;
INSERT INTO creature_addon VALUES 
(286658, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286659;
INSERT INTO creature_addon VALUES 
(286659, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=286660;
INSERT INTO creature_addon VALUES 
(286660, 0, 0, 0, 1, 0, "83142");

DELETE FROM creature_addon WHERE guid=245964;
INSERT INTO creature_addon VALUES 
(245964, 0, 0, 0, 1, 0, "68327");

DELETE FROM creature_addon WHERE guid=249584;
INSERT INTO creature_addon VALUES 
(249584, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=286661;
INSERT INTO creature_addon VALUES 
(286661, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=286662;
INSERT INTO creature_addon VALUES 
(286662, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=249599;
INSERT INTO creature_addon VALUES 
(249599, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=249585;
INSERT INTO creature_addon VALUES 
(249585, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=249598;
INSERT INTO creature_addon VALUES 
(249598, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=286663;
INSERT INTO creature_addon VALUES 
(286663, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=249601;
INSERT INTO creature_addon VALUES 
(249601, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=249597;
INSERT INTO creature_addon VALUES 
(249597, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=249596;
INSERT INTO creature_addon VALUES 
(249596, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=249600;
INSERT INTO creature_addon VALUES 
(249600, 0, 0, 0, 1, 0, "71910");

DELETE FROM creature_addon WHERE guid=249463;
INSERT INTO creature_addon VALUES 
(249463, 0, 0, 50397184, 1, 0, "70686");

DELETE FROM creature_addon WHERE guid=249466;
INSERT INTO creature_addon VALUES 
(249466, 0, 0, 50397184, 1, 0, "70687");

DELETE FROM creature_addon WHERE guid=249465;
INSERT INTO creature_addon VALUES 
(249465, 0, 0, 50397184, 1, 0, "70688");

DELETE FROM creature_addon WHERE guid=246048;
INSERT INTO creature_addon VALUES 
(246048, 0, 0, 50331649, 1, 0, "");

DELETE FROM creature_addon WHERE guid=248244;
INSERT INTO creature_addon VALUES 
(248244, 0, 0, 50397185, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286680;
INSERT INTO creature_addon VALUES 
(286680, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286681;
INSERT INTO creature_addon VALUES 
(286681, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286682;
INSERT INTO creature_addon VALUES 
(286682, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286683;
INSERT INTO creature_addon VALUES 
(286683, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286684;
INSERT INTO creature_addon VALUES 
(286684, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286685;
INSERT INTO creature_addon VALUES 
(286685, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286686;
INSERT INTO creature_addon VALUES 
(286686, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286687;
INSERT INTO creature_addon VALUES 
(286687, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286688;
INSERT INTO creature_addon VALUES 
(286688, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286689;
INSERT INTO creature_addon VALUES 
(286689, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286690;
INSERT INTO creature_addon VALUES 
(286690, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286691;
INSERT INTO creature_addon VALUES 
(286691, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286692;
INSERT INTO creature_addon VALUES 
(286692, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286693;
INSERT INTO creature_addon VALUES 
(286693, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286694;
INSERT INTO creature_addon VALUES 
(286694, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286695;
INSERT INTO creature_addon VALUES 
(286695, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286696;
INSERT INTO creature_addon VALUES 
(286696, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286697;
INSERT INTO creature_addon VALUES 
(286697, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286698;
INSERT INTO creature_addon VALUES 
(286698, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286699;
INSERT INTO creature_addon VALUES 
(286699, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286700;
INSERT INTO creature_addon VALUES 
(286700, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=248187;
INSERT INTO creature_addon VALUES 
(248187, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286701;
INSERT INTO creature_addon VALUES 
(286701, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286702;
INSERT INTO creature_addon VALUES 
(286702, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286703;
INSERT INTO creature_addon VALUES 
(286703, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286704;
INSERT INTO creature_addon VALUES 
(286704, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286705;
INSERT INTO creature_addon VALUES 
(286705, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286706;
INSERT INTO creature_addon VALUES 
(286706, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286707;
INSERT INTO creature_addon VALUES 
(286707, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286708;
INSERT INTO creature_addon VALUES 
(286708, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286709;
INSERT INTO creature_addon VALUES 
(286709, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286710;
INSERT INTO creature_addon VALUES 
(286710, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286711;
INSERT INTO creature_addon VALUES 
(286711, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286712;
INSERT INTO creature_addon VALUES 
(286712, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286713;
INSERT INTO creature_addon VALUES 
(286713, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286714;
INSERT INTO creature_addon VALUES 
(286714, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286715;
INSERT INTO creature_addon VALUES 
(286715, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286716;
INSERT INTO creature_addon VALUES 
(286716, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286717;
INSERT INTO creature_addon VALUES 
(286717, 0, 0, 0, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286718;
INSERT INTO creature_addon VALUES 
(286718, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286719;
INSERT INTO creature_addon VALUES 
(286719, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286720;
INSERT INTO creature_addon VALUES 
(286720, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286721;
INSERT INTO creature_addon VALUES 
(286721, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286722;
INSERT INTO creature_addon VALUES 
(286722, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286723;
INSERT INTO creature_addon VALUES 
(286723, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286724;
INSERT INTO creature_addon VALUES 
(286724, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286725;
INSERT INTO creature_addon VALUES 
(286725, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286726;
INSERT INTO creature_addon VALUES 
(286726, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286727;
INSERT INTO creature_addon VALUES 
(286727, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286728;
INSERT INTO creature_addon VALUES 
(286728, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286729;
INSERT INTO creature_addon VALUES 
(286729, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286730;
INSERT INTO creature_addon VALUES 
(286730, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=248294;
INSERT INTO creature_addon VALUES 
(248294, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286731;
INSERT INTO creature_addon VALUES 
(286731, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286732;
INSERT INTO creature_addon VALUES 
(286732, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286733;
INSERT INTO creature_addon VALUES 
(286733, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286734;
INSERT INTO creature_addon VALUES 
(286734, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286735;
INSERT INTO creature_addon VALUES 
(286735, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286736;
INSERT INTO creature_addon VALUES 
(286736, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286737;
INSERT INTO creature_addon VALUES 
(286737, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286738;
INSERT INTO creature_addon VALUES 
(286738, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286739;
INSERT INTO creature_addon VALUES 
(286739, 0, 0, 50331648, 1, 0, "73363");

DELETE FROM creature_addon WHERE guid=286740;
INSERT INTO creature_addon VALUES 
(286740, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286741;
INSERT INTO creature_addon VALUES 
(286741, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286742;
INSERT INTO creature_addon VALUES 
(286742, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286743;
INSERT INTO creature_addon VALUES 
(286743, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286744;
INSERT INTO creature_addon VALUES 
(286744, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=246278;
INSERT INTO creature_addon VALUES 
(246278, 0, 0, 0, 1, 375, "29266");

DELETE FROM creature_addon WHERE guid=286745;
INSERT INTO creature_addon VALUES 
(286745, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286746;
INSERT INTO creature_addon VALUES 
(286746, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=246285;
INSERT INTO creature_addon VALUES 
(246285, 0, 0, 0, 1, 375, "29266");

DELETE FROM creature_addon WHERE guid=246275;
INSERT INTO creature_addon VALUES 
(246275, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286747;
INSERT INTO creature_addon VALUES 
(286747, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286748;
INSERT INTO creature_addon VALUES 
(286748, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286749;
INSERT INTO creature_addon VALUES 
(286749, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286750;
INSERT INTO creature_addon VALUES 
(286750, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286751;
INSERT INTO creature_addon VALUES 
(286751, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286752;
INSERT INTO creature_addon VALUES 
(286752, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286753;
INSERT INTO creature_addon VALUES 
(286753, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286754;
INSERT INTO creature_addon VALUES 
(286754, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286755;
INSERT INTO creature_addon VALUES 
(286755, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286756;
INSERT INTO creature_addon VALUES 
(286756, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286757;
INSERT INTO creature_addon VALUES 
(286757, 0, 0, 0, 1, 375, "29266");

DELETE FROM creature_addon WHERE guid=246274;
INSERT INTO creature_addon VALUES 
(246274, 0, 0, 0, 1, 375, "29266");

DELETE FROM creature_addon WHERE guid=246281;
INSERT INTO creature_addon VALUES 
(246281, 0, 0, 0, 1, 375, "29266");

DELETE FROM creature_addon WHERE guid=246277;
INSERT INTO creature_addon VALUES 
(246277, 0, 0, 0, 1, 375, "29266");

DELETE FROM creature_addon WHERE guid=246265;
INSERT INTO creature_addon VALUES 
(246265, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286758;
INSERT INTO creature_addon VALUES 
(286758, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286759;
INSERT INTO creature_addon VALUES 
(286759, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286760;
INSERT INTO creature_addon VALUES 
(286760, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=246267;
INSERT INTO creature_addon VALUES 
(246267, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286761;
INSERT INTO creature_addon VALUES 
(286761, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286762;
INSERT INTO creature_addon VALUES 
(286762, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=246280;
INSERT INTO creature_addon VALUES 
(246280, 0, 0, 0, 1, 375, "29266");

DELETE FROM creature_addon WHERE guid=286763;
INSERT INTO creature_addon VALUES 
(286763, 0, 0, 0, 1, 375, "29266");

DELETE FROM creature_addon WHERE guid=246269;
INSERT INTO creature_addon VALUES 
(246269, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286764;
INSERT INTO creature_addon VALUES 
(286764, 0, 0, 0, 1, 0, "29266");

DELETE FROM creature_addon WHERE guid=286765;
INSERT INTO creature_addon VALUES 
(286765, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=286766;
INSERT INTO creature_addon VALUES 
(286766, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=286767;
INSERT INTO creature_addon VALUES 
(286767, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=286768;
INSERT INTO creature_addon VALUES 
(286768, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=286769;
INSERT INTO creature_addon VALUES 
(286769, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=286770;
INSERT INTO creature_addon VALUES 
(286770, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=248492;
INSERT INTO creature_addon VALUES 
(248492, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=248484;
INSERT INTO creature_addon VALUES 
(248484, 0, 0, 0, 1, 234, "");

DELETE FROM creature_addon WHERE guid=248502;
INSERT INTO creature_addon VALUES 
(248502, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=286771;
INSERT INTO creature_addon VALUES 
(286771, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=248493;
INSERT INTO creature_addon VALUES 
(248493, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=248483;
INSERT INTO creature_addon VALUES 
(248483, 0, 0, 0, 1, 234, "");

DELETE FROM creature_addon WHERE guid=248494;
INSERT INTO creature_addon VALUES 
(248494, 0, 0, 65536, 1, 333, "");

DELETE FROM creature_addon WHERE guid=248489;
INSERT INTO creature_addon VALUES 
(248489, 0, 0, 0, 1, 69, "");

DELETE FROM creature_addon WHERE guid=286773;
INSERT INTO creature_addon VALUES 
(286773, 0, 0, 0, 1, 0, "324");

DELETE FROM creature_addon WHERE guid=248349;
INSERT INTO creature_addon VALUES 
(248349, 0, 0, 8, 1, 0, "324");

DELETE FROM creature_addon WHERE guid=286774;
INSERT INTO creature_addon VALUES 
(286774, 0, 0, 0, 1, 0, "324");

DELETE FROM creature_addon WHERE guid=286781;
INSERT INTO creature_addon VALUES 
(286781, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286782;
INSERT INTO creature_addon VALUES 
(286782, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286783;
INSERT INTO creature_addon VALUES 
(286783, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286784;
INSERT INTO creature_addon VALUES 
(286784, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286785;
INSERT INTO creature_addon VALUES 
(286785, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286786;
INSERT INTO creature_addon VALUES 
(286786, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286788;
INSERT INTO creature_addon VALUES 
(286788, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286789;
INSERT INTO creature_addon VALUES 
(286789, 0, 0, 65536, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286790;
INSERT INTO creature_addon VALUES 
(286790, 0, 0, 65536, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286791;
INSERT INTO creature_addon VALUES 
(286791, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286792;
INSERT INTO creature_addon VALUES 
(286792, 0, 0, 65536, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286794;
INSERT INTO creature_addon VALUES 
(286794, 0, 0, 65536, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286795;
INSERT INTO creature_addon VALUES 
(286795, 0, 0, 65536, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286796;
INSERT INTO creature_addon VALUES 
(286796, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286797;
INSERT INTO creature_addon VALUES 
(286797, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286798;
INSERT INTO creature_addon VALUES 
(286798, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286799;
INSERT INTO creature_addon VALUES 
(286799, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286800;
INSERT INTO creature_addon VALUES 
(286800, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=248507;
INSERT INTO creature_addon VALUES 
(248507, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286801;
INSERT INTO creature_addon VALUES 
(286801, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286802;
INSERT INTO creature_addon VALUES 
(286802, 0, 0, 0, 2, 214, "");

DELETE FROM creature_addon WHERE guid=286810;
INSERT INTO creature_addon VALUES 
(286810, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286811;
INSERT INTO creature_addon VALUES 
(286811, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286812;
INSERT INTO creature_addon VALUES 
(286812, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286814;
INSERT INTO creature_addon VALUES 
(286814, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286822;
INSERT INTO creature_addon VALUES 
(286822, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286823;
INSERT INTO creature_addon VALUES 
(286823, 0, 0, 8, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286835;
INSERT INTO creature_addon VALUES 
(286835, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286836;
INSERT INTO creature_addon VALUES 
(286836, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286837;
INSERT INTO creature_addon VALUES 
(286837, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286838;
INSERT INTO creature_addon VALUES 
(286838, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286839;
INSERT INTO creature_addon VALUES 
(286839, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286840;
INSERT INTO creature_addon VALUES 
(286840, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286841;
INSERT INTO creature_addon VALUES 
(286841, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286842;
INSERT INTO creature_addon VALUES 
(286842, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286843;
INSERT INTO creature_addon VALUES 
(286843, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286844;
INSERT INTO creature_addon VALUES 
(286844, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286845;
INSERT INTO creature_addon VALUES 
(286845, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286846;
INSERT INTO creature_addon VALUES 
(286846, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286847;
INSERT INTO creature_addon VALUES 
(286847, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286848;
INSERT INTO creature_addon VALUES 
(286848, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286849;
INSERT INTO creature_addon VALUES 
(286849, 0, 0, 50331648, 1, 0, "");

DELETE FROM creature_addon WHERE guid=286850;
INSERT INTO creature_addon VALUES 
(286850, 0, 0, 50331648, 1, 0, "");


