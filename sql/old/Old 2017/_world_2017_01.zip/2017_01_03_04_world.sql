
DELETE FROM creature_addon WHERE guid=272093;
DELETE FROM creature_addon WHERE guid=272099;
DELETE FROM creature_addon WHERE guid=272098;
DELETE FROM creature_addon WHERE guid=272097;
DELETE FROM creature_addon WHERE guid=272096;
DELETE FROM creature_addon WHERE guid=272095;
DELETE FROM creature_addon WHERE guid=272094;
