

DELETE FROM conditions WHERE SourceTypeOrReferenceId=15 AND SourceGroup=4106 AND SourceEntry=0 AND SourceId=0;
INSERT INTO conditions (SourceTypeOrReferenceId, SourceGroup, ConditionTypeOrReference, ConditionValue1, NegativeCondition) VALUES (15, 4106, 28, 26322, 1);

