
UPDATE creature_template SET ScriptName="npc_fire_juggler_generic" WHERE entry=55397;

UPDATE creature_template SET ScriptName="npc_fire_juggler_generic" WHERE entry=55398;

UPDATE creature_template_addon SET auras="" WHERE entry=55397;

