
-- deepholm

DELETE FROM npc_spellclick_spells WHERE npc_entry=29488;
INSERT INTO npc_spellclick_spells VALUES 
(29488, 54567, 3, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29501;
INSERT INTO npc_spellclick_spells VALUES 
(29501, 52263, 3, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28605;
INSERT INTO npc_spellclick_spells VALUES 
(28605, 54574, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28833;
INSERT INTO npc_spellclick_spells VALUES 
(28833, 52447, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28683;
INSERT INTO npc_spellclick_spells VALUES 
(28683, 43671, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28607;
INSERT INTO npc_spellclick_spells VALUES 
(28607, 52263, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28606;
INSERT INTO npc_spellclick_spells VALUES 
(28606, 52263, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28782;
INSERT INTO npc_spellclick_spells VALUES 
(28782, 52349, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=42339;
INSERT INTO npc_spellclick_spells VALUES 
(42339, 78974, 1, 0);



