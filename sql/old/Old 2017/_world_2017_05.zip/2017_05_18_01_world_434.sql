
ALTER TABLE `creature`
ADD COLUMN `VerifiedBuild`  smallint(5) NOT NULL DEFAULT 0 AFTER `dynamicflags`;


