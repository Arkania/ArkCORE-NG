

delete from arkcore_string where entry=364;
insert into arkcore_string values 
(364, "Creature (Entry: %u, DbGuid: %u) Deleted", "", "", "Creature (Entry: %u, DbGuid: %u) Gelöscht", "", "", "", "", "");

