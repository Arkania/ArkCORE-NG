

UPDATE `quest_template` SET `RewardSpellCast` = '0' WHERE `quest_template`.`Id` = 14396;
