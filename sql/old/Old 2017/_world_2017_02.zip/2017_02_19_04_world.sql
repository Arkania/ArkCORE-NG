
delete from game_event_arena_seasons where eventEntry between 124 and 134;
insert into game_event_arena_seasons values 
(124, 1),
(125, 2),
(126, 3),
(127, 4),
(128, 5),
(129, 6),
(130, 7),
(131, 8),
(132, 9),
(133, 10),
(134, 11);

