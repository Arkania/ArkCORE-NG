
DELETE FROM creature_text WHERE entry=28511;
INSERT INTO creature_text VALUES 
(28511, 0, 0, "The Eye of Acherus launches towards its destination.", 42, 0, 100, 0, 0, 0, "Eye of Acherus", 28507),
(28511, 1, 0, "The Eye of Acherus is in your control.", 42, 0, 100, 0, 0, 0, "Eye of Acherus", 28465);


