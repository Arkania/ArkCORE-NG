
-- table is not used
DROP TABLE IF EXISTS creature_transport;

