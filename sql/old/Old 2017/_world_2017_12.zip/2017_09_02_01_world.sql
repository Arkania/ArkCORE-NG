
-- Thousand Needles

UPDATE quest_template SET RequiredRaces=2098253 WHERE Id=25873;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=25874;

UPDATE creature_template SET gossip_menu_id=12006 WHERE entry=45278;

UPDATE creature SET phaseId=170 WHERE guid in (85955, 86087, 86084, 86085, 86093, 85954, 11117, 86044, 86034, 86053, 86088, 85936, 85961, 86079);

UPDATE creature SET phaseId=170 WHERE guid in (86035);

UPDATE creature SET phaseId=170 WHERE id in (9525);

