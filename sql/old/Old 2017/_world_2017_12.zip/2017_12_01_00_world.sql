
DELETE FROM `spell_script_names` WHERE `ScriptName`='spell_hun_camouflage_visual';
INSERT INTO `spell_script_names` values
(51755, 'spell_hun_camouflage_visual');

