


DELETE FROM gameobject_template WHERE entry=252;
INSERT INTO gameobject_template VALUES 
(252, 3, 28, "I Should not be here B", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 9, 753, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=272;
INSERT INTO gameobject_template VALUES 
(272, 3, 1, "MacGrann\'s Meat Locker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 1682, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=337;
INSERT INTO gameobject_template VALUES 
(337, 3, 297, "Water Pitcher", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 2369, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=1586;
INSERT INTO gameobject_template VALUES 
(1586, 3, 113, "Crate of Candles", "", "Grabbing", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 28239, 30, 0, 0, 0, 0, 0, 24985, 0, 0, 0, 0, 0, 37379, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=1667;
INSERT INTO gameobject_template VALUES 
(1667, 3, 384, "Incendicite Mineral Vein", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 39, 1409, 0, 1, 1, 1, 294, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=2053;
INSERT INTO gameobject_template VALUES 
(2053, 3, 10, "TWO-SOLUTION TEST", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 52, 1711, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2054;
INSERT INTO gameobject_template VALUES 
(2054, 3, 315, "Tin Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 39, 1736, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=2055;
INSERT INTO gameobject_template VALUES 
(2055, 3, 310, "Copper Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 38, 1735, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=2549;
INSERT INTO gameobject_template VALUES 
(2549, 3, 10, "Cookie Test Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 53, 2027, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2559;
INSERT INTO gameobject_template VALUES 
(2559, 3, 10, "Maury\'s Lock Test Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 63, 2008, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2700;
INSERT INTO gameobject_template VALUES 
(2700, 3, 192, "Campfire", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1810, 15175, 30, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2723;
INSERT INTO gameobject_template VALUES 
(2723, 3, 251, "Bale of Hay", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2216, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2743;
INSERT INTO gameobject_template VALUES 
(2743, 3, 52, "Carved Stone Urn", "", "", "", 0, 0, 0.4, 0, 0, 0, 0, 0, 0, 43, 2263, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=2842;
INSERT INTO gameobject_template VALUES 
(2842, 3, 235, "Pillar of Diamond", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 67, 2418, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=2845;
INSERT INTO gameobject_template VALUES 
(2845, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2277, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=2846;
INSERT INTO gameobject_template VALUES 
(2846, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2278, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=2847;
INSERT INTO gameobject_template VALUES 
(2847, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2279, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14007); 

DELETE FROM gameobject_template WHERE entry=2848;
INSERT INTO gameobject_template VALUES 
(2848, 3, 235, "Pillar of Opal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 67, 2417, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=2850;
INSERT INTO gameobject_template VALUES 
(2850, 3, 259, "Solid Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=2884;
INSERT INTO gameobject_template VALUES 
(2884, 3, 261, "Clam", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 57, 2265, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=2885;
INSERT INTO gameobject_template VALUES 
(2885, 3, 31, "Large Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2265, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2886;
INSERT INTO gameobject_template VALUES 
(2886, 3, 288, "Barrel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2265, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2887;
INSERT INTO gameobject_template VALUES 
(2887, 3, 216, "Cauldron", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2265, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2888;
INSERT INTO gameobject_template VALUES 
(2888, 3, 289, "Woodpile", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2356, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2889;
INSERT INTO gameobject_template VALUES 
(2889, 3, 33, "Powder Keg", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2356, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2890;
INSERT INTO gameobject_template VALUES 
(2890, 3, 292, "Full Mine Cart", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2356, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=2907;
INSERT INTO gameobject_template VALUES 
(2907, 3, 297, "Water Pitcher", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 2369, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3237;
INSERT INTO gameobject_template VALUES 
(3237, 3, 226, "Imprisoned Darkspear", "", "", "", 0, 0, 1.3, 0, 0, 0, 0, 0, 0, 43, 2424, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3238;
INSERT INTO gameobject_template VALUES 
(3238, 3, 319, "Chen\'s Empty Keg", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2494, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3239;
INSERT INTO gameobject_template VALUES 
(3239, 3, 41, "Benedict\'s Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 68, 2483, 0, 0, 0, 0, 498, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3240;
INSERT INTO gameobject_template VALUES 
(3240, 3, 412, "Taillasher Eggs", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2495, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3524;
INSERT INTO gameobject_template VALUES 
(3524, 3, 327, "The Demon Seed", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 39470, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3645;
INSERT INTO gameobject_template VALUES 
(3645, 3, 332, "Ripe Watermelon", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2501, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3646;
INSERT INTO gameobject_template VALUES 
(3646, 3, 10, "General Twinbraid\'s Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2499, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3657;
INSERT INTO gameobject_template VALUES 
(3657, 3, 333, "Abandoned Mine Car", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2356, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3689;
INSERT INTO gameobject_template VALUES 
(3689, 3, 335, "Weapon Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 404, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3690;
INSERT INTO gameobject_template VALUES 
(3690, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2577, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3692;
INSERT INTO gameobject_template VALUES 
(3692, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2573, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3695;
INSERT INTO gameobject_template VALUES 
(3695, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2600, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3696;
INSERT INTO gameobject_template VALUES 
(3696, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2599, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3697;
INSERT INTO gameobject_template VALUES 
(3697, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2596, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3698;
INSERT INTO gameobject_template VALUES 
(3698, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2595, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3699;
INSERT INTO gameobject_template VALUES 
(3699, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2594, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3701;
INSERT INTO gameobject_template VALUES 
(3701, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2597, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3702;
INSERT INTO gameobject_template VALUES 
(3702, 3, 335, "Armor Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 405, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=3703;
INSERT INTO gameobject_template VALUES 
(3703, 3, 335, "Armor Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 1619, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3704;
INSERT INTO gameobject_template VALUES 
(3704, 3, 335, "Weapon Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 1618, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3707;
INSERT INTO gameobject_template VALUES 
(3707, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 9955, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3708;
INSERT INTO gameobject_template VALUES 
(3708, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 9937, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3709;
INSERT INTO gameobject_template VALUES 
(3709, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 9946, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3710;
INSERT INTO gameobject_template VALUES 
(3710, 3, 336, "Food Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2356, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=3712;
INSERT INTO gameobject_template VALUES 
(3712, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 9952, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3713;
INSERT INTO gameobject_template VALUES 
(3713, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 9943, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=3714;
INSERT INTO gameobject_template VALUES 
(3714, 3, 259, "Alliance Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 5, 2281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3715;
INSERT INTO gameobject_template VALUES 
(3715, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3724;
INSERT INTO gameobject_template VALUES 
(3724, 3, 269, "Peacebloom", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 29, 2512, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3725;
INSERT INTO gameobject_template VALUES 
(3725, 3, 270, "Silverleaf", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 29, 2511, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3726;
INSERT INTO gameobject_template VALUES 
(3726, 3, 414, "Earthroot", "", "", "", 0, 0, 0.4, 0, 0, 0, 0, 0, 0, 30, 2513, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3727;
INSERT INTO gameobject_template VALUES 
(3727, 3, 268, "Mageroyal", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 9, 2514, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3729;
INSERT INTO gameobject_template VALUES 
(3729, 3, 271, "Briarthorn", "", "", "", 0, 0, 0.4, 0, 0, 0, 0, 0, 0, 31, 2515, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3730;
INSERT INTO gameobject_template VALUES 
(3730, 3, 358, "Bruiseweed", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 519, 2516, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=3743;
INSERT INTO gameobject_template VALUES 
(3743, 3, 267, "Fissure Plant", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 57, 2603, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14007); 

DELETE FROM gameobject_template WHERE entry=3763;
INSERT INTO gameobject_template VALUES 
(3763, 3, 310, "Copper Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 38, 2626, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3764;
INSERT INTO gameobject_template VALUES 
(3764, 3, 315, "Tin Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 39, 2627, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3767;
INSERT INTO gameobject_template VALUES 
(3767, 3, 31, "Drizzlik\'s Emporium", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2628, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=3768;
INSERT INTO gameobject_template VALUES 
(3768, 3, 347, "Fragile - Do Not Drop", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2629, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=4095;
INSERT INTO gameobject_template VALUES 
(4095, 3, 259, "Alliance Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 23, 2282, 0, 1, 0, 0, 0, 0, 0, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=4096;
INSERT INTO gameobject_template VALUES 
(4096, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2282, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=4148;
INSERT INTO gameobject_template VALUES 
(4148, 3, 259, "Mithril Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 61, 5278, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=4149;
INSERT INTO gameobject_template VALUES 
(4149, 3, 259, "Solid Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 5278, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=9630;
INSERT INTO gameobject_template VALUES 
(9630, 3, 379, "Flagongut\'s Fossil", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2760, 30, 1, 0, 0, 601, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=11713;
INSERT INTO gameobject_template VALUES 
(11713, 3, 385, "Death Cap", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 259, 2765, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=11714;
INSERT INTO gameobject_template VALUES 
(11714, 3, 359, "Scaber Stalk", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 259, 2766, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=12654;
INSERT INTO gameobject_template VALUES 
(12654, 3, 406, "Mathystra Relic", "", "", "", 0, 0, 4, 0, 0, 0, 0, 0, 0, 57, 2767, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=13872;
INSERT INTO gameobject_template VALUES 
(13872, 3, 404, "Mathystra Relic", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 57, 2767, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=13873;
INSERT INTO gameobject_template VALUES 
(13873, 3, 407, "Cat Figurine", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 57, 2768, 0, 1, 0, 0, 0, 12653, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "go_cat_figurine", 15354); 

DELETE FROM gameobject_template WHERE entry=13874;
INSERT INTO gameobject_template VALUES 
(13874, 3, 390, "Serpentbloom", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 259, 2772, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=17155;
INSERT INTO gameobject_template VALUES 
(17155, 3, 33, "Defias Gunpowder", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2882, 0, 1, 0, 0, 619, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "SmartGameObjectAI", "", 12340); 

DELETE FROM gameobject_template WHERE entry=18036;
INSERT INTO gameobject_template VALUES 
(18036, 3, 228, "Bottle of Disease", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 2935, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=19017;
INSERT INTO gameobject_template VALUES 
(19017, 3, 261, "Giant Clam", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2954, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=19018;
INSERT INTO gameobject_template VALUES 
(19018, 3, 261, "Giant Clam", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2959, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=19020;
INSERT INTO gameobject_template VALUES 
(19020, 3, 335, "Box of Assorted Parts", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2955, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=19284;
INSERT INTO gameobject_template VALUES 
(19284, 3, 422, "Mythology of the Titans", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 3064, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=19541;
INSERT INTO gameobject_template VALUES 
(19541, 3, 378, "Deepmoss Eggs", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 3082, 0, 1, 0, 0, 0, 19543, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=19542;
INSERT INTO gameobject_template VALUES 
(19542, 3, 378, "Deepmoss Eggs", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 3081, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=19595;
INSERT INTO gameobject_template VALUES 
(19595, 3, 438, "Gatekeeper\'s Hold", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 3087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=19596;
INSERT INTO gameobject_template VALUES 
(19596, 3, 439, "Sleepers\' Cache", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 94, 3088, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=19598;
INSERT INTO gameobject_template VALUES 
(19598, 3, 439, "Barrow Cache", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 94, 3090, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=20726;
INSERT INTO gameobject_template VALUES 
(20726, 3, 470, "Beginnings of the Undead Threat", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 3313, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=20920;
INSERT INTO gameobject_template VALUES 
(20920, 3, 683, "Blueleaf Tuber", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 43, 3338, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "SmartGameObjectAI", "", 12340); 

DELETE FROM gameobject_template WHERE entry=21145;
INSERT INTO gameobject_template VALUES 
(21145, 3, 566, "Feast Boar", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 3459, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=21146;
INSERT INTO gameobject_template VALUES 
(21146, 3, 564, "Feast Fish", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 3458, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=21147;
INSERT INTO gameobject_template VALUES 
(21147, 3, 563, "Feast Fruit", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 3460, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=21148;
INSERT INTO gameobject_template VALUES 
(21148, 3, 565, "Feast Goblet", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 3461, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=21277;
INSERT INTO gameobject_template VALUES 
(21277, 3, 528, "Crate with Holes", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 3450, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=21530;
INSERT INTO gameobject_template VALUES 
(21530, 3, 447, "Snufflenose Owner\'s Manual", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 3502, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=22246;
INSERT INTO gameobject_template VALUES 
(22246, 3, 219, "Tear of Theradras", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 99, 3543, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=28604;
INSERT INTO gameobject_template VALUES 
(28604, 3, 335, "Scattered Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 3597, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=30855;
INSERT INTO gameobject_template VALUES 
(30855, 3, 652, "Atal\'ai Artifact", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 3598, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=30856;
INSERT INTO gameobject_template VALUES 
(30856, 3, 653, "Atal\'ai Artifact", "", "", "", 0, 0, 0.2, 0, 0, 0, 0, 0, 0, 57, 3598, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=37098;
INSERT INTO gameobject_template VALUES 
(37098, 3, 10, "Perrine\'s Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 3625, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=68865;
INSERT INTO gameobject_template VALUES 
(68865, 3, 760, "Snufflenose Command Sticks", "", "", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 93, 4059, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=73939;
INSERT INTO gameobject_template VALUES 
(73939, 3, 767, "Ooze Covered Iron Deposit", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1505, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=74448;
INSERT INTO gameobject_template VALUES 
(74448, 3, 259, "Large Solid Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 4075, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=74731;
INSERT INTO gameobject_template VALUES 
(74731, 3, 252, "Noggle\'s Satchel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2217, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=75295;
INSERT INTO gameobject_template VALUES 
(75295, 3, 259, "Large Iron Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 5, 4074, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=75296;
INSERT INTO gameobject_template VALUES 
(75296, 3, 259, "Large Iron Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 24, 4076, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=75297;
INSERT INTO gameobject_template VALUES 
(75297, 3, 259, "Large Iron Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 60, 4077, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=83763;
INSERT INTO gameobject_template VALUES 
(83763, 3, 107, "Stolen Books", "", "", "", 0, 0, 0.63, 0, 0, 0, 0, 0, 0, 93, 4165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=85562;
INSERT INTO gameobject_template VALUES 
(85562, 3, 10, "Ironband\'s Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 4185, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=86492;
INSERT INTO gameobject_template VALUES 
(86492, 3, 335, "Crate of Elunite", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4187, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=89634;
INSERT INTO gameobject_template VALUES 
(89634, 3, 2251, "Iron Coral", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 4227, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=89635;
INSERT INTO gameobject_template VALUES 
(89635, 3, 4075, "Sunscorched Shell", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 4228, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=91137;
INSERT INTO gameobject_template VALUES 
(91137, 3, 10, "Jordan\'s Shipment", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 4364, 30, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=91138;
INSERT INTO gameobject_template VALUES 
(91138, 3, 908, "Jordan\'s Hammer", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 279, 4275, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=92013;
INSERT INTO gameobject_template VALUES 
(92013, 3, 928, "Tome of the Cabal", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 43, 4305, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=92420;
INSERT INTO gameobject_template VALUES 
(92420, 3, 31, "Bailor\'s Ore", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 4352, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=92423;
INSERT INTO gameobject_template VALUES 
(92423, 3, 1, "Damaged Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 4353, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=93192;
INSERT INTO gameobject_template VALUES 
(93192, 3, 967, "Heartswood", "", "", "", 0, 0, 3.91, 0, 0, 0, 0, 0, 0, 99, 4304, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=102984;
INSERT INTO gameobject_template VALUES 
(102984, 3, 10, "Bink\'s Toolbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 4504, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=102985;
INSERT INTO gameobject_template VALUES 
(102985, 3, 1087, "Balnir Snapdragons", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 4505, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=103574;
INSERT INTO gameobject_template VALUES 
(103574, 3, 1707, "Filled Containment Coffer", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 4589, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=103600;
INSERT INTO gameobject_template VALUES 
(103600, 3, 137, "Andron\'s Bookshelf", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4590, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=103662;
INSERT INTO gameobject_template VALUES 
(103662, 3, 1708, "Bolt Charged Bramble", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4754, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=103664;
INSERT INTO gameobject_template VALUES 
(103664, 3, 422, "Rituals of Power", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4584, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=103709;
INSERT INTO gameobject_template VALUES 
(103709, 3, 315, "Tin Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 38, 1503, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=103710;
INSERT INTO gameobject_template VALUES 
(103710, 3, 312, "Iron Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 41, 1505, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=103711;
INSERT INTO gameobject_template VALUES 
(103711, 3, 315, "Tin Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 39, 1503, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=103712;
INSERT INTO gameobject_template VALUES 
(103712, 3, 312, "Iron Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 41, 1505, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=103713;
INSERT INTO gameobject_template VALUES 
(103713, 3, 310, "Copper Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 38, 1502, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=103714;
INSERT INTO gameobject_template VALUES 
(103714, 3, 310, "Copper Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 38, 1502, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=103774;
INSERT INTO gameobject_template VALUES 
(103774, 3, 318, "Standard Issue Tools", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4665, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=103815;
INSERT INTO gameobject_template VALUES 
(103815, 3, 1, "Ambermill Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 5, 4667, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=103820;
INSERT INTO gameobject_template VALUES 
(103820, 3, 1188, "Red Rocket", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 4669, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=104564;
INSERT INTO gameobject_template VALUES 
(104564, 3, 1208, "Bingles\'s Toolbucket", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 43, 4685, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=104569;
INSERT INTO gameobject_template VALUES 
(104569, 3, 1209, "Bingles\'s Toolbucket", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 43, 4686, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=104574;
INSERT INTO gameobject_template VALUES 
(104574, 3, 1210, "Bingles\'s Toolbucket", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 43, 4687, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=104575;
INSERT INTO gameobject_template VALUES 
(104575, 3, 112, "Bingles\'s Blastencapper", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 43, 4688, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=105170;
INSERT INTO gameobject_template VALUES 
(105170, 3, 130, "Agamand Weapon Rack", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4765, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=105171;
INSERT INTO gameobject_template VALUES 
(105171, 3, 130, "Agamand Weapon Rack", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4766, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=105172;
INSERT INTO gameobject_template VALUES 
(105172, 3, 130, "Agamand Weapon Rack", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4767, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=105174;
INSERT INTO gameobject_template VALUES 
(105174, 3, 1, "Chest of Containment Coffers", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 93, 4768, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=105175;
INSERT INTO gameobject_template VALUES 
(105175, 3, 164, "Cantation of Manifestation", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 4769, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=105176;
INSERT INTO gameobject_template VALUES 
(105176, 3, 10, "Venture Co. Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 5, 4770, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=105569;
INSERT INTO gameobject_template VALUES 
(105569, 3, 314, "Silver Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 40, 1504, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=105570;
INSERT INTO gameobject_template VALUES 
(105570, 3, 259, "Alliance Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 24, 2283, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=105571;
INSERT INTO gameobject_template VALUES 
(105571, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2283, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=105577;
INSERT INTO gameobject_template VALUES 
(105577, 3, 259, "Horde Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 24, 2283, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=105578;
INSERT INTO gameobject_template VALUES 
(105578, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2283, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=105579;
INSERT INTO gameobject_template VALUES 
(105579, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2283, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=105580;
INSERT INTO gameobject_template VALUES 
(105580, 3, 259, "Alliance Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 60, 2284, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=105581;
INSERT INTO gameobject_template VALUES 
(105581, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2284, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=106318;
INSERT INTO gameobject_template VALUES 
(106318, 3, 259, "Battered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2277, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=111095;
INSERT INTO gameobject_template VALUES 
(111095, 3, 259, "Tattered Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2280, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14007); 

DELETE FROM gameobject_template WHERE entry=113757;
INSERT INTO gameobject_template VALUES 
(113757, 3, 1387, "Shadowforge Cache", "", "", "", 0, 0, 0.4, 0, 0, 0, 0, 0, 0, 43, 4964, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=125477;
INSERT INTO gameobject_template VALUES 
(125477, 3, 53, "Conspicuous Urn", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 93, 5201, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=126049;
INSERT INTO gameobject_template VALUES 
(126049, 3, 2090, "Magenta Cap Clusters", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 5212, 0, 1, 0, 0, 0, 128196, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=126260;
INSERT INTO gameobject_template VALUES 
(126260, 3, 1387, "Ancient Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2309, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=128293;
INSERT INTO gameobject_template VALUES 
(128293, 3, 2090, "Magenta Cap Clusters", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 5212, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=128308;
INSERT INTO gameobject_template VALUES 
(128308, 3, 1767, "Shallow Grave", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1539, 8367, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "go_shallow_grave", 15595); 

DELETE FROM gameobject_template WHERE entry=128403;
INSERT INTO gameobject_template VALUES 
(128403, 3, 1767, "Shallow Grave", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1539, 8367, 0, 1, 0, 0, 0, 128972, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "go_shallow_grave", 15595); 

DELETE FROM gameobject_template WHERE entry=129127;
INSERT INTO gameobject_template VALUES 
(129127, 3, 1, "Gallywix\'s Lockbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 24, 5246, 30, 1, 0, 0, 0, 130126, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=131978;
INSERT INTO gameobject_template VALUES 
(131978, 3, 259, "Large Mithril Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 61, 5282, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=131979;
INSERT INTO gameobject_template VALUES 
(131979, 3, 259, "Large Darkwood Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 5282, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=140911;
INSERT INTO gameobject_template VALUES 
(140911, 3, 1747, "Spool of Light Chartreuse Silk Thread", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 5429, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=140971;
INSERT INTO gameobject_template VALUES 
(140971, 3, 1767, "Gahz\'ridian", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 419, 5446, 0, 1, 0, 0, 0, 0, 3161, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=141609;
INSERT INTO gameobject_template VALUES 
(141609, 3, 33, "Weegli\'s Barrel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 5504, 30, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=141872;
INSERT INTO gameobject_template VALUES 
(141872, 3, 327, "Divino-matic Rod", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 5629, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=141979;
INSERT INTO gameobject_template VALUES 
(141979, 3, 1387, "Ancient Treasure", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 5730, 1800000, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=142076;
INSERT INTO gameobject_template VALUES 
(142076, 3, 1928, "Clara\'s Fresh Apples", "", "", "", 0, 0, 0.9, 0, 0, 0, 0, 0, 0, 93, 5706, 0, 1, 0, 0, 0, 0, 2746, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=142088;
INSERT INTO gameobject_template VALUES 
(142088, 3, 5, "Tablet of Will", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 5727, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=142147;
INSERT INTO gameobject_template VALUES 
(142147, 3, 1967, "Firework test", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 3377, 30, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=142181;
INSERT INTO gameobject_template VALUES 
(142181, 3, 36, "Stolen Cargo", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 6706, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=142184;
INSERT INTO gameobject_template VALUES 
(142184, 3, 10, "Captain\'s Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 460, 8387, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=142344;
INSERT INTO gameobject_template VALUES 
(142344, 3, 2089, "Artificial Extrapolator", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 6799, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=142477;
INSERT INTO gameobject_template VALUES 
(142477, 3, 10, "Thermaplugg\'s Safe", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 479, 6978, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=144054;
INSERT INTO gameobject_template VALUES 
(144054, 3, 10, "Shay\'s Chest", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 8438, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=144064;
INSERT INTO gameobject_template VALUES 
(144064, 3, 20, "Gordunni Dirt Mound", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 43, 8446, 0, 1, 0, 0, 0, 0, 2987, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=147557;
INSERT INTO gameobject_template VALUES 
(147557, 3, 10, "Stolen Silver", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 8759, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=149036;
INSERT INTO gameobject_template VALUES 
(149036, 3, 2450, "Marvon\'s Chest", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 9199, 1, 0, 1, 1, 0, 0, 3444, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=149481;
INSERT INTO gameobject_template VALUES 
(149481, 3, 235, "Rune of Beth\'Amara", "", "", "", 0, 0, 1.22, 0, 0, 0, 0, 0, 0, 540, 9239, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=149482;
INSERT INTO gameobject_template VALUES 
(149482, 3, 235, "Rune of Markri", "", "", "", 0, 0, 1.22, 0, 0, 0, 0, 0, 0, 540, 9241, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=149483;
INSERT INTO gameobject_template VALUES 
(149483, 3, 235, "Rune of Sael\'hai", "", "", "", 0, 0, 1.21, 0, 0, 0, 0, 0, 0, 540, 9242, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=150079;
INSERT INTO gameobject_template VALUES 
(150079, 3, 313, "Mithril Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 379, 1742, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=150080;
INSERT INTO gameobject_template VALUES 
(150080, 3, 311, "Gold Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 42, 1506, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11159); 

DELETE FROM gameobject_template WHERE entry=150081;
INSERT INTO gameobject_template VALUES 
(150081, 3, 314, "Truesilver Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 380, 5045, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=150082;
INSERT INTO gameobject_template VALUES 
(150082, 3, 3951, "Small Thorium Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 400, 9597, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=152094;
INSERT INTO gameobject_template VALUES 
(152094, 3, 2090, "Hyacinth Mushroom", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 259, 9604, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=152608;
INSERT INTO gameobject_template VALUES 
(152608, 3, 1, "Kolkar\'s Booty", "", "", "", 0, 0, 1.6, 0, 0, 0, 0, 0, 0, 70, 3318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=152618;
INSERT INTO gameobject_template VALUES 
(152618, 3, 1, "Kolkar\'s Booty", "", "", "", 0, 0, 1.62, 0, 0, 0, 0, 0, 0, 70, 3318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=153123;
INSERT INTO gameobject_template VALUES 
(153123, 3, 285, "Kim\'jael\'s Equipment", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 9677, 0, 1, 0, 0, 0, 0, 3601, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=153451;
INSERT INTO gameobject_template VALUES 
(153451, 3, 259, "Solid Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 9931, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=153453;
INSERT INTO gameobject_template VALUES 
(153453, 3, 259, "Solid Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 9932, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=153454;
INSERT INTO gameobject_template VALUES 
(153454, 3, 259, "Solid Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 9933, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=153455;
INSERT INTO gameobject_template VALUES 
(153455, 3, 259, "Mithril Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 62, 9931, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=153457;
INSERT INTO gameobject_template VALUES 
(153457, 3, 259, "Mithril Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 599, 9932, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=153458;
INSERT INTO gameobject_template VALUES 
(153458, 3, 259, "Mithril Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 600, 9933, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=153470;
INSERT INTO gameobject_template VALUES 
(153470, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 9956, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=153471;
INSERT INTO gameobject_template VALUES 
(153471, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 9957, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=153472;
INSERT INTO gameobject_template VALUES 
(153472, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2509, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=153473;
INSERT INTO gameobject_template VALUES 
(153473, 3, 336, "Food Crate", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 57, 2508, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=157936;
INSERT INTO gameobject_template VALUES 
(157936, 3, 49, "Un\'Goro Dirt Pile", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 10039, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=160845;
INSERT INTO gameobject_template VALUES 
(160845, 3, 10, "Dark Coffer", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 11103, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=161495;
INSERT INTO gameobject_template VALUES 
(161495, 3, 10, "Secret Safe", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 11104, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=161557;
INSERT INTO gameobject_template VALUES 
(161557, 3, 3012, "Milly\'s Harvest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 10119, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=164662;
INSERT INTO gameobject_template VALUES 
(164662, 3, 36, "Equipment Boxes", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 57, 10984, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=164778;
INSERT INTO gameobject_template VALUES 
(164778, 3, 2975, "Blue Power Crystal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 10980, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=164779;
INSERT INTO gameobject_template VALUES 
(164779, 3, 2976, "Green Power Crystal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 10981, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=164780;
INSERT INTO gameobject_template VALUES 
(164780, 3, 2977, "Red Power Crystal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 10982, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=164781;
INSERT INTO gameobject_template VALUES 
(164781, 3, 2978, "Yellow Power Crystal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 10983, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=164798;
INSERT INTO gameobject_template VALUES 
(164798, 3, 2991, "Evoroot", "", "", "", 0, 0, 0.4, 0, 0, 0, 0, 0, 0, 93, 11020, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=169243;
INSERT INTO gameobject_template VALUES 
(169243, 3, 1387, "Chest of The Seven", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 12260, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=173232;
INSERT INTO gameobject_template VALUES 
(173232, 3, 525, "Blacksmithing Plans", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 11524, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=173234;
INSERT INTO gameobject_template VALUES 
(173234, 3, 525, "Blacksmithing Plans", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 11525, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12201, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=173266;
INSERT INTO gameobject_template VALUES 
(173266, 3, 2530, "Goodsteel Ledger", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 11582, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=175079;
INSERT INTO gameobject_template VALUES 
(175079, 3, 1411, "Mechanical Egg", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 4984, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=175165;
INSERT INTO gameobject_template VALUES 
(175165, 3, 10, "Silver Dawning\'s Lockbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 12600, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175166;
INSERT INTO gameobject_template VALUES 
(175166, 3, 10, "Mist Veil\'s Lockbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 12601, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175245;
INSERT INTO gameobject_template VALUES 
(175245, 3, 1667, "Father Flame", "", "", "", 0, 0, 0.4, 0, 0, 0, 0, 0, 0, 93, 13761, 30, 1, 0, 0, 0, 177606, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175264;
INSERT INTO gameobject_template VALUES 
(175264, 3, 1807, "Broodling Essence", "", "", "", 0, 0, 0.2, 0, 0, 0, 0, 0, 0, 93, 12680, 0, 1, 0, 0, 0, 177586, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=175322;
INSERT INTO gameobject_template VALUES 
(175322, 3, 3693, "Forged Seal of Ascension", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 12731, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=175329;
INSERT INTO gameobject_template VALUES 
(175329, 3, 3613, "Blackwood Nut Stores", "", "", "", 0, 0, 1.1, 0, 0, 0, 0, 0, 0, 93, 12811, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175330;
INSERT INTO gameobject_template VALUES 
(175330, 3, 3613, "Blackwood Fruit Stores", "", "", "", 0, 0, 0.72, 0, 0, 0, 0, 0, 0, 93, 12810, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175331;
INSERT INTO gameobject_template VALUES 
(175331, 3, 3613, "Blackwood Grain Stores", "", "", "", 0, 0, 0.91, 0, 0, 0, 0, 0, 0, 93, 12812, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175334;
INSERT INTO gameobject_template VALUES 
(175334, 3, 41, "Bijou\'s Belongings", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 12841, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175382;
INSERT INTO gameobject_template VALUES 
(175382, 3, 1387, "Doomrigger\'s Coffer", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 43, 12871, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175384;
INSERT INTO gameobject_template VALUES 
(175384, 3, 3851, "Highperch Wyvern Egg", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 12880, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175385;
INSERT INTO gameobject_template VALUES 
(175385, 3, 403, "Darkstone Tablet", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 12881, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175488;
INSERT INTO gameobject_template VALUES 
(175488, 3, 5, "Fourth Mosh\'aru Tablet", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 12905, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=175565;
INSERT INTO gameobject_template VALUES 
(175565, 3, 364, "Alien Egg", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 12980, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175588;
INSERT INTO gameobject_template VALUES 
(175588, 3, 378, "Spire Spider Egg", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 13000, 0, 1, 0, 0, 4799, 175590, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175606;
INSERT INTO gameobject_template VALUES 
(175606, 3, 378, "Spire Spider Egg", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 13000, 0, 1, 0, 0, 4799, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175629;
INSERT INTO gameobject_template VALUES 
(175629, 3, 285, "Jaron\'s Supplies", "", "", "", 0, 0, 0.77, 0, 0, 0, 0, 0, 0, 43, 13022, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175770;
INSERT INTO gameobject_template VALUES 
(175770, 3, 477, "TEST Dragon Egg Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2229, 30, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=175785;
INSERT INTO gameobject_template VALUES 
(175785, 3, 183, "Inconspicuous Documents", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 13201, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175802;
INSERT INTO gameobject_template VALUES 
(175802, 3, 318, "Small Lockbox", "", "", "", 0, 0, 1.3, 0, 0, 0, 0, 0, 0, 57, 13220, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175886;
INSERT INTO gameobject_template VALUES 
(175886, 3, 5891, "Roughshod Pike", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 13340, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175888;
INSERT INTO gameobject_template VALUES 
(175888, 3, 3991, "Highborne Relic Fragment", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 979, 13606, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175889;
INSERT INTO gameobject_template VALUES 
(175889, 3, 3992, "Ancient Egg", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 13342, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175891;
INSERT INTO gameobject_template VALUES 
(175891, 3, 3991, "Highborne Relic Fragment", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 979, 13607, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175928;
INSERT INTO gameobject_template VALUES 
(175928, 3, 4055, "Incendia Agave", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 259, 13360, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=175949;
INSERT INTO gameobject_template VALUES 
(175949, 3, 5, "Fifth Mosh\'aru Tablet", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 13366, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175950;
INSERT INTO gameobject_template VALUES 
(175950, 3, 5, "Sixth Mosh\'aru Tablet", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 13367, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=175964;
INSERT INTO gameobject_template VALUES 
(175964, 3, 1327, "Skin of Shadow", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 13380, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=175966;
INSERT INTO gameobject_template VALUES 
(175966, 3, 4071, "Enchanted Scarlet Thread", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 13382, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15050); 

DELETE FROM gameobject_template WHERE entry=175970;
INSERT INTO gameobject_template VALUES 
(175970, 3, 4074, "Unforged Runic Breastplate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 13572, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=176089;
INSERT INTO gameobject_template VALUES 
(176089, 3, 241, "Unfired Plate Gauntlets", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 13574, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=176112;
INSERT INTO gameobject_template VALUES 
(176112, 3, 1, "Malor\'s Strongbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 13580, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=176145;
INSERT INTO gameobject_template VALUES 
(176145, 3, 3171, "Joseph Redpath\'s Monument", "", "", "", 0, 0, 0.71, 0, 0, 0, 0, 0, 0, 43, 13605, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=176150;
INSERT INTO gameobject_template VALUES 
(176150, 3, 558, "Musty Tome", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 13610, 0, 1, 0, 0, 0, 0, 5154, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176151;
INSERT INTO gameobject_template VALUES 
(176151, 3, 4135, "Musty Tome", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 14480, 30, 1, 0, 0, 0, 176152, 5154, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176188;
INSERT INTO gameobject_template VALUES 
(176188, 3, 4152, "Ritual Candle", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 13620, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=176189;
INSERT INTO gameobject_template VALUES 
(176189, 3, 4153, "Skeletal Sea Turtle", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 12681, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=176213;
INSERT INTO gameobject_template VALUES 
(176213, 3, 4211, "Blood of Heroes", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 13622, 0, 1, 0, 0, 0, 176214, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176215;
INSERT INTO gameobject_template VALUES 
(176215, 3, 4177, "Cannonball Stack", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1085, 13645, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=176224;
INSERT INTO gameobject_template VALUES 
(176224, 3, 335, "Supply Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 13646, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=176249;
INSERT INTO gameobject_template VALUES 
(176249, 3, 318, "Scourge Data", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 13662, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=176325;
INSERT INTO gameobject_template VALUES 
(176325, 3, 525, "Blacksmithing Plans", "", "Collecting", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 93, 13721, 0, 1, 0, 0, 5300, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "SmartGameObjectAI", "", 14545); 

DELETE FROM gameobject_template WHERE entry=176327;
INSERT INTO gameobject_template VALUES 
(176327, 3, 525, "Blacksmithing Plans", "", "Collecting", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 93, 13722, 0, 1, 0, 0, 5301, 0, 27230, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "SmartGameObjectAI", "", 15354); 

DELETE FROM gameobject_template WHERE entry=176344;
INSERT INTO gameobject_template VALUES 
(176344, 3, 10, "Document Chest #1", "", "Collecting", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 93, 13400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176356;
INSERT INTO gameobject_template VALUES 
(176356, 3, 559, "Sacred Highborne Writings", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 13744, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=176360;
INSERT INTO gameobject_template VALUES 
(176360, 3, 4191, "Postbox Parcel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 13740, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=176634;
INSERT INTO gameobject_template VALUES 
(176634, 3, 10, "Kerlonian\'s Chest", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 43, 13964, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=176637;
INSERT INTO gameobject_template VALUES 
(176637, 3, 2313, "Gromsblood", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 444, 13966, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176638;
INSERT INTO gameobject_template VALUES 
(176638, 3, 4652, "Golden Sansam", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1119, 13967, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176639;
INSERT INTO gameobject_template VALUES 
(176639, 3, 4635, "Dreamfoil", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1120, 13968, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176640;
INSERT INTO gameobject_template VALUES 
(176640, 3, 4633, "Mountain Silversage", "", "", "", 0, 0, 1.8, 0, 0, 0, 0, 0, 0, 1121, 13969, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176641;
INSERT INTO gameobject_template VALUES 
(176641, 3, 4632, "Plaguebloom", "", "", "", 0, 0, 1.8, 0, 0, 0, 0, 0, 0, 1122, 13971, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176642;
INSERT INTO gameobject_template VALUES 
(176642, 3, 2310, "Arthas\' Tears", "", "", "", 0, 0, 1.3, 0, 0, 0, 0, 0, 0, 440, 13970, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176643;
INSERT INTO gameobject_template VALUES 
(176643, 3, 3951, "Small Thorium Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 400, 13960, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176644;
INSERT INTO gameobject_template VALUES 
(176644, 3, 3952, "Rich Thorium Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 939, 13962, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=176645;
INSERT INTO gameobject_template VALUES 
(176645, 3, 313, "Mithril Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 379, 13961, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=176752;
INSERT INTO gameobject_template VALUES 
(176752, 3, 4453, "Kodo Bones", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 13982, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=177241;
INSERT INTO gameobject_template VALUES 
(177241, 3, 4712, "Araj\'s Phylactery", "", "", "", 0, 0, 0.9, 0, 0, 0, 0, 0, 0, 43, 14285, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=177260;
INSERT INTO gameobject_template VALUES 
(177260, 3, 4715, "Symbol of Lost Honor", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 14287, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=177585;
INSERT INTO gameobject_template VALUES 
(177585, 3, 4811, "Fast-growing Flower", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 43, 14460, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=177624;
INSERT INTO gameobject_template VALUES 
(177624, 3, 644, "Xabraxxis\' Demon Bag", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 14500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=177681;
INSERT INTO gameobject_template VALUES 
(177681, 3, 20, "Gordunni Dirt Mound", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 43, 14540, 0, 1, 0, 0, 0, 0, 2987, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=177747;
INSERT INTO gameobject_template VALUES 
(177747, 3, 1128, "Quel\'Thalas Registry", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 14560, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=177750;
INSERT INTO gameobject_template VALUES 
(177750, 3, 155, "Lunar Fungal Bloom", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 14562, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=177785;
INSERT INTO gameobject_template VALUES 
(177785, 3, 4871, "Bauble Container", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 93, 14621, 0, 1, 0, 0, 0, 178984, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=177790;
INSERT INTO gameobject_template VALUES 
(177790, 3, 10, "Strange Lockbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 14626, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=177792;
INSERT INTO gameobject_template VALUES 
(177792, 3, 10, "Strange Lockbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 14628, 0, 0, 0, 0, 0, 177793, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=177794;
INSERT INTO gameobject_template VALUES 
(177794, 3, 10, "Strange Lockbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 14628, 0, 0, 0, 0, 0, 177793, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=177804;
INSERT INTO gameobject_template VALUES 
(177804, 3, 4093, "Mangled Human Remains", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 14680, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=177805;
INSERT INTO gameobject_template VALUES 
(177805, 3, 4093, "Mangled Human Remains", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 14681, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=177806;
INSERT INTO gameobject_template VALUES 
(177806, 3, 4093, "Mangled Human Remains", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 14682, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=177844;
INSERT INTO gameobject_template VALUES 
(177844, 3, 10, "Strange Lockbox", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 14626, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=178804;
INSERT INTO gameobject_template VALUES 
(178804, 3, 346, "Small Termite Mound", "", "", "", 0, 0, 0.35, 0, 0, 0, 0, 0, 0, 1259, 15797, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=179004;
INSERT INTO gameobject_template VALUES 
(179004, 3, 163, "Drek\'Thar\'s Scrolls", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 15920, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=179005;
INSERT INTO gameobject_template VALUES 
(179005, 3, 220, "Drek\'Thar\'s Scrolls", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 15920, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=179006;
INSERT INTO gameobject_template VALUES 
(179006, 3, 183, "Vanndar\'s Documents", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 15921, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179007;
INSERT INTO gameobject_template VALUES 
(179007, 3, 164, "Vanndar\'s Documents", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 15921, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179008;
INSERT INTO gameobject_template VALUES 
(179008, 3, 190, "Vanndar\'s Documents", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 15921, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179024;
INSERT INTO gameobject_template VALUES 
(179024, 3, 5191, "Stormpike Banner", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 15983, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=179025;
INSERT INTO gameobject_template VALUES 
(179025, 3, 5571, "Frostwolf Banner", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 15988, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179486;
INSERT INTO gameobject_template VALUES 
(179486, 3, 5743, "Battered Footlocker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 24, 16464, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179488;
INSERT INTO gameobject_template VALUES 
(179488, 3, 5743, "Battered Footlocker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1559, 16464, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179489;
INSERT INTO gameobject_template VALUES 
(179489, 3, 5744, "Waterlogged Footlocker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1559, 16464, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179490;
INSERT INTO gameobject_template VALUES 
(179490, 3, 5743, "Battered Footlocker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1560, 16465, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=179492;
INSERT INTO gameobject_template VALUES 
(179492, 3, 5743, "Dented Footlocker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 61, 16465, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=179495;
INSERT INTO gameobject_template VALUES 
(179495, 3, 5744, "Mossy Footlocker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1561, 16466, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=179497;
INSERT INTO gameobject_template VALUES 
(179497, 3, 5744, "Mossy Footlocker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 62, 16466, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=179516;
INSERT INTO gameobject_template VALUES 
(179516, 3, 41, "Fengus\'s Chest", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 16523, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179545;
INSERT INTO gameobject_template VALUES 
(179545, 3, 10, "The Prince\'s Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 16569, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179553;
INSERT INTO gameobject_template VALUES 
(179553, 3, 5740, "Core Fragment", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 16570, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=179562;
INSERT INTO gameobject_template VALUES 
(179562, 3, 4175, "Ancient Heated Blade", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 16592, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=179644;
INSERT INTO gameobject_template VALUES 
(179644, 3, 1667, "Imprisoned Doomguard", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 16668, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=179703;
INSERT INTO gameobject_template VALUES 
(179703, 3, 51, "Cache of the Firelord", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 16719, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=179826;
INSERT INTO gameobject_template VALUES 
(179826, 3, 163, "Secret Plans: Fiery Flux", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 16799, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=179832;
INSERT INTO gameobject_template VALUES 
(179832, 3, 5914, "Pillaclencher\'s Ornate Pillow", "", "Stealing", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 16841, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26365, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14007); 

DELETE FROM gameobject_template WHERE entry=179914;
INSERT INTO gameobject_template VALUES 
(179914, 3, 293, "Pile of Bones", "", "", "", 0, 0, 1.25, 0, 0, 0, 0, 0, 0, 43, 16925, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=180164;
INSERT INTO gameobject_template VALUES 
(180164, 3, 2315, "Sungrass", "", "", "", 0, 0, 1.8, 0, 0, 0, 0, 0, 0, 441, 17201, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180165;
INSERT INTO gameobject_template VALUES 
(180165, 3, 2314, "Purple Lotus", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 439, 17200, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180166;
INSERT INTO gameobject_template VALUES 
(180166, 3, 4633, "Mountain Silversage", "", "", "", 0, 0, 1.8, 0, 0, 0, 0, 0, 0, 1121, 17204, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180167;
INSERT INTO gameobject_template VALUES 
(180167, 3, 4652, "Golden Sansam", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1119, 17202, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180168;
INSERT INTO gameobject_template VALUES 
(180168, 3, 4635, "Dreamfoil", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1120, 17203, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180215;
INSERT INTO gameobject_template VALUES 
(180215, 3, 3952, "Hakkari Thorium Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 939, 17241, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180216;
INSERT INTO gameobject_template VALUES 
(180216, 3, 28, "Whipweed", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 43, 17299, 0, 1, 0, 0, 0, 180217, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=180346;
INSERT INTO gameobject_template VALUES 
(180346, 3, 6366, "Mudskunk Lure", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 17320, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=180370;
INSERT INTO gameobject_template VALUES 
(180370, 3, 381, "Harvest Fruit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 17323, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180371;
INSERT INTO gameobject_template VALUES 
(180371, 3, 564, "Harvest Fish", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 17324, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180372;
INSERT INTO gameobject_template VALUES 
(180372, 3, 566, "Harvest Boar", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 17325, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180373;
INSERT INTO gameobject_template VALUES 
(180373, 3, 6371, "Harvest Nectar", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 17326, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180374;
INSERT INTO gameobject_template VALUES 
(180374, 3, 6153, "Harvest Nectar", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 17326, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180392;
INSERT INTO gameobject_template VALUES 
(180392, 3, 213, "Full Jug", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 17331, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=180501;
INSERT INTO gameobject_template VALUES 
(180501, 3, 6420, "Twilight Tablet Fragment", "", "Collecting", "", 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 93, 17350, 0, 1, 0, 0, 0, 180583, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=180618;
INSERT INTO gameobject_template VALUES 
(180618, 3, 4192, "Metal Casing", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 17461, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=180691;
INSERT INTO gameobject_template VALUES 
(180691, 3, 6502, "Scarab Coffer", "", "", "", 0, 0, 1.4, 0, 0, 0, 0, 0, 0, 1629, 17532, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=180716;
INSERT INTO gameobject_template VALUES 
(180716, 3, 3151, "Festive Mug", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 17540, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=180754;
INSERT INTO gameobject_template VALUES 
(180754, 3, 565, "Toasting Goblet", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 17685, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=180905;
INSERT INTO gameobject_template VALUES 
(180905, 3, 3151, "Festive Mug", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 17540, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181083;
INSERT INTO gameobject_template VALUES 
(181083, 3, 10, "Sothos and Jarien\'s Heirlooms", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 17919, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=181085;
INSERT INTO gameobject_template VALUES 
(181085, 3, 6448, "Stratholme Supply Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 17899, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=181098;
INSERT INTO gameobject_template VALUES 
(181098, 3, 49, "Volcanic Ash", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 17912, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=181108;
INSERT INTO gameobject_template VALUES 
(181108, 3, 314, "Truesilver Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 380, 17938, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=181109;
INSERT INTO gameobject_template VALUES 
(181109, 3, 311, "Gold Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 42, 17939, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=181127;
INSERT INTO gameobject_template VALUES 
(181127, 3, 6926, "Arcane Sanctum Rubble", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 57, 17969, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181207;
INSERT INTO gameobject_template VALUES 
(181207, 3, 4175, "Runed Demonic Blade", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 18015, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181248;
INSERT INTO gameobject_template VALUES 
(181248, 3, 310, "Copper Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 38, 18092, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=181249;
INSERT INTO gameobject_template VALUES 
(181249, 3, 315, "Tin Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 39, 18093, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 13623); 

DELETE FROM gameobject_template WHERE entry=181287;
INSERT INTO gameobject_template VALUES 
(181287, 3, 6714, "Frozen Rune", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1647, 18150, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=181365;
INSERT INTO gameobject_template VALUES 
(181365, 3, 6714, "Frozen Rune", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1647, 18150, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181558;
INSERT INTO gameobject_template VALUES 
(181558, 3, 6798, "Rich Adamantite Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1652, 26861, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181568;
INSERT INTO gameobject_template VALUES 
(181568, 3, 6798, "Rich Adamantite Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1652, 26861, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181570;
INSERT INTO gameobject_template VALUES 
(181570, 3, 6798, "Rich Adamantite Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1652, 26861, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 70, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181589;
INSERT INTO gameobject_template VALUES 
(181589, 3, 225, "Suntouched Special Reserve", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1654, 18377, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181590;
INSERT INTO gameobject_template VALUES 
(181590, 3, 114, "Springpaw Appetizer", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 1654, 18378, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181593;
INSERT INTO gameobject_template VALUES 
(181593, 3, 6777, "Bloodthistle Plant", "", "", "", 0, 0, 0.13, 0, 0, 0, 0, 0, 0, 1654, 18379, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181620;
INSERT INTO gameobject_template VALUES 
(181620, 3, 336, "Unopened Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 18399, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=181627;
INSERT INTO gameobject_template VALUES 
(181627, 3, 130, "Weapon Rack", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 18402, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=181628;
INSERT INTO gameobject_template VALUES 
(181628, 3, 6811, "Empty Barrel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 18403, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=181629;
INSERT INTO gameobject_template VALUES 
(181629, 3, 1, "Holy Coffer", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 18404, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=181671;
INSERT INTO gameobject_template VALUES 
(181671, 3, 6816, "Fel Horde Banner", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 57, 18459, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181687;
INSERT INTO gameobject_template VALUES 
(181687, 3, 1108, "Lumber Pile", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 18451, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=181757;
INSERT INTO gameobject_template VALUES 
(181757, 3, 6484, "Stillpine Grain", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 18501, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181771;
INSERT INTO gameobject_template VALUES 
(181771, 3, 6837, "Corrupted Crystal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 18512, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181797;
INSERT INTO gameobject_template VALUES 
(181797, 3, 259, "Fel Iron Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 600, 9933, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181799;
INSERT INTO gameobject_template VALUES 
(181799, 3, 259, "Heavy Fel Iron Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1665, 22342, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181801;
INSERT INTO gameobject_template VALUES 
(181801, 3, 259, "Adamantite Bound Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1666, 22342, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181803;
INSERT INTO gameobject_template VALUES 
(181803, 3, 259, "Felsteel Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1667, 22984, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=181845;
INSERT INTO gameobject_template VALUES 
(181845, 3, 6894, "Sealed Tome", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 18509, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181846;
INSERT INTO gameobject_template VALUES 
(181846, 3, 6893, "Sealed Tome", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 18509, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181847;
INSERT INTO gameobject_template VALUES 
(181847, 3, 6891, "Sealed Tome", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 18509, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181848;
INSERT INTO gameobject_template VALUES 
(181848, 3, 6892, "Sealed Tome", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 18509, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181872;
INSERT INTO gameobject_template VALUES 
(181872, 3, 6314, "Steam Pump Part", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 18600, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181873;
INSERT INTO gameobject_template VALUES 
(181873, 3, 449, "Steam Pump Part", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 18600, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181874;
INSERT INTO gameobject_template VALUES 
(181874, 3, 6867, "Steam Pump Part", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 18600, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181875;
INSERT INTO gameobject_template VALUES 
(181875, 3, 6868, "Steam Pump Part", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 18600, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=181876;
INSERT INTO gameobject_template VALUES 
(181876, 3, 451, "Steam Pump Part", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 57, 18600, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=182011;
INSERT INTO gameobject_template VALUES 
(182011, 3, 31, "Crate of Ingots", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 18672, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=182063;
INSERT INTO gameobject_template VALUES 
(182063, 3, 445, "Basin of Holy Water", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 18699, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 13329); 

DELETE FROM gameobject_template WHERE entry=182256;
INSERT INTO gameobject_template VALUES 
(182256, 3, 6941, "Discarded Nutriment", "", "Collecting", "", 0, 0, 0.05, 0, 0, 0, 0, 0, 0, 1690, 18676, 0, 1, 0, 0, 0, 184578, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=182342;
INSERT INTO gameobject_template VALUES 
(182342, 3, 183, "Boulderfist Plans", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 19324, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=182936;
INSERT INTO gameobject_template VALUES 
(182936, 3, 6481, "Salvageable Wood", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 36258, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=182937;
INSERT INTO gameobject_template VALUES 
(182937, 3, 7000, "Salvageable Metal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 36259, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=182938;
INSERT INTO gameobject_template VALUES 
(182938, 3, 6999, "Salvageable Metal", "", "", "", 0, 0, 0.9, 0, 0, 0, 0, 0, 0, 1690, 36259, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=183395;
INSERT INTO gameobject_template VALUES 
(183395, 3, 7041, "Zeppelin Debris", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 19885, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=183396;
INSERT INTO gameobject_template VALUES 
(183396, 3, 7042, "Zeppelin Debris", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 19885, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=183397;
INSERT INTO gameobject_template VALUES 
(183397, 3, 451, "Zeppelin Debris", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 19885, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=183814;
INSERT INTO gameobject_template VALUES 
(183814, 3, 7089, "Ethereal Technology", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 20035, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=183876;
INSERT INTO gameobject_template VALUES 
(183876, 3, 336, "Rob Test Crate", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 20045, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=183933;
INSERT INTO gameobject_template VALUES 
(183933, 3, 7118, "Elemental Power", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 20046, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14007); 

DELETE FROM gameobject_template WHERE entry=184251;
INSERT INTO gameobject_template VALUES 
(184251, 3, 4094, "Sunfury Torch", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 57, 20260, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=184309;
INSERT INTO gameobject_template VALUES 
(184309, 3, 6136, "Suspicious Outhouse", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 20266, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=184435;
INSERT INTO gameobject_template VALUES 
(184435, 3, 7171, "Legion Fel Cannon", "", "", "", 0, 0, 0.95, 0, 0, 0, 0, 0, 0, 57, 20403, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=184619;
INSERT INTO gameobject_template VALUES 
(184619, 3, 7213, "Mana Bomb Code Sheet 1", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184620;
INSERT INTO gameobject_template VALUES 
(184620, 3, 7213, "Mana Bomb Code Sheet 2", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184621;
INSERT INTO gameobject_template VALUES 
(184621, 3, 7213, "Mana Bomb Code Sheet 3", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184622;
INSERT INTO gameobject_template VALUES 
(184622, 3, 7213, "Mana Bomb Code Sheet 4", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 2281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184693;
INSERT INTO gameobject_template VALUES 
(184693, 3, 60, "Designer Island Pumpkin 01 [PH]", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 18156, 30, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=184739;
INSERT INTO gameobject_template VALUES 
(184739, 3, 5743, "Dented Footlocker", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 600, 20890, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=184810;
INSERT INTO gameobject_template VALUES 
(184810, 3, 352, "Sealed Coffin", "", "", "", 0, 0, 1.75, 0, 0, 0, 0, 0, 0, 57, 21111, 30, 1, 0, 0, 13766, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=184811;
INSERT INTO gameobject_template VALUES 
(184811, 3, 352, "Sealed Coffin", "", "", "", 0, 0, 1.75, 0, 0, 0, 0, 0, 0, 57, 21111, 30, 1, 0, 0, 13767, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=184812;
INSERT INTO gameobject_template VALUES 
(184812, 3, 352, "Sealed Coffin", "", "", "", 0, 0, 1.75, 0, 0, 0, 0, 0, 0, 57, 21111, 30, 1, 0, 0, 13768, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=184813;
INSERT INTO gameobject_template VALUES 
(184813, 3, 352, "Sealed Coffin", "", "", "", 0, 0, 1.75, 0, 0, 0, 0, 0, 0, 57, 21111, 30, 1, 0, 0, 13769, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=184814;
INSERT INTO gameobject_template VALUES 
(184814, 3, 352, "Sealed Coffin", "", "", "", 0, 0, 1.75, 0, 0, 0, 0, 0, 0, 57, 21111, 30, 1, 0, 0, 13770, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=184815;
INSERT INTO gameobject_template VALUES 
(184815, 3, 352, "Sealed Coffin", "", "", "", 0, 0, 1.75, 0, 0, 0, 0, 0, 0, 57, 21111, 30, 1, 0, 0, 13771, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=184845;
INSERT INTO gameobject_template VALUES 
(184845, 25, 6527, "Strange Pool", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 20, 17519, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=184849;
INSERT INTO gameobject_template VALUES 
(184849, 3, 7216, "Cache of the Legion", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1706, 20530, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=184870;
INSERT INTO gameobject_template VALUES 
(184870, 3, 6420, "Baa\'ri Tablet Fragment", "", "", "", 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 93, 21231, 0, 1, 0, 0, 0, 184868, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=184930;
INSERT INTO gameobject_template VALUES 
(184930, 3, 259, "Solid Fel Iron Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 21260, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184931;
INSERT INTO gameobject_template VALUES 
(184931, 3, 259, "Bound Fel Iron Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1665, 21260, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184932;
INSERT INTO gameobject_template VALUES 
(184932, 3, 259, "Bound Fel Iron Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1665, 21278, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184933;
INSERT INTO gameobject_template VALUES 
(184933, 3, 259, "Solid Fel Iron Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 21278, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184934;
INSERT INTO gameobject_template VALUES 
(184934, 3, 259, "Bound Fel Iron Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1665, 21279, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184935;
INSERT INTO gameobject_template VALUES 
(184935, 3, 259, "Solid Fel Iron Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 21279, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184936;
INSERT INTO gameobject_template VALUES 
(184936, 3, 259, "Bound Adamantite Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1666, 21280, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184937;
INSERT INTO gameobject_template VALUES 
(184937, 3, 259, "Solid Adamantite Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 21280, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184938;
INSERT INTO gameobject_template VALUES 
(184938, 3, 259, "Bound Adamantite Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1666, 21281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184939;
INSERT INTO gameobject_template VALUES 
(184939, 3, 259, "Solid Adamantite Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 21281, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184940;
INSERT INTO gameobject_template VALUES 
(184940, 3, 259, "Bound Adamantite Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1667, 21261, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184941;
INSERT INTO gameobject_template VALUES 
(184941, 3, 259, "Solid Adamantite Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 21261, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=184980;
INSERT INTO gameobject_template VALUES 
(184980, 3, 3675, "Felhound Poo", "", "Searching", "", 0, 0, 1.7, 0, 0, 0, 0, 0, 0, 43, 21311, 0, 1, 0, 0, 0, 184981, 10629, 0, 0, 0, 0, 0, 19680, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=185169;
INSERT INTO gameobject_template VALUES 
(185169, 3, 5744, "Reinforced Fel Iron Chest", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 21764, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=185233;
INSERT INTO gameobject_template VALUES 
(185233, 3, 41, "The Doctor\'s Strongbox", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1709, 21291, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=185497;
INSERT INTO gameobject_template VALUES 
(185497, 3, 7386, "Bogblossom", "", "Collecting", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 259, 22011, 0, 1, 0, 0, 0, 185502, 10961, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=185523;
INSERT INTO gameobject_template VALUES 
(185523, 3, 20, "Mound of Dirt", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 22034, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=185525;
INSERT INTO gameobject_template VALUES 
(185525, 3, 2614, "Pile o\' Gold", "", "", "", 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 1635, 19059, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=185540;
INSERT INTO gameobject_template VALUES 
(185540, 3, 259, "Pat\'s Magic Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 21279, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=185541;
INSERT INTO gameobject_template VALUES 
(185541, 3, 6419, "Raven Stone Fragment", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 1691, 22035, 0, 1, 0, 0, 0, 185527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=185562;
INSERT INTO gameobject_template VALUES 
(185562, 3, 255, "Vim\'gol\'s Vile Grimoire", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1690, 22048, 1, 0, 0, 0, 0, 185564, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=185567;
INSERT INTO gameobject_template VALUES 
(185567, 3, 7354, "Grulloc\'s Dragon Skull", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1690, 22054, 1, 0, 0, 0, 0, 185578, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=185574;
INSERT INTO gameobject_template VALUES 
(185574, 3, 7215, "Slaag\'s Standard", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1690, 22056, 1, 0, 0, 0, 0, 185564, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=185900;
INSERT INTO gameobject_template VALUES 
(185900, 3, 7385, "Picnic Grill", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 22098, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=185961;
INSERT INTO gameobject_template VALUES 
(185961, 3, 7402, "Dark Portal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1635, 19059, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=186263;
INSERT INTO gameobject_template VALUES 
(186263, 3, 222, "Grimbooze\'s Secret Recipe", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 57, 22300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=186325;
INSERT INTO gameobject_template VALUES 
(186325, 3, 49, "Darkclaw Guano", "", "Collecting", "", 0, 0, 0.15, 0, 0, 0, 0, 0, 0, 43, 22327, 0, 1, 0, 0, 0, 186326, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186404;
INSERT INTO gameobject_template VALUES 
(186404, 3, 7454, "Whisper Gulch Gem", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 22368, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186466;
INSERT INTO gameobject_template VALUES 
(186466, 3, 7455, "Whisper Gulch Gem", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 22368, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186467;
INSERT INTO gameobject_template VALUES 
(186467, 3, 7456, "Whisper Gulch Gem", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 22368, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186468;
INSERT INTO gameobject_template VALUES 
(186468, 3, 7457, "Whisper Gulch Ore Fragment", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 22369, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186595;
INSERT INTO gameobject_template VALUES 
(186595, 3, 6419, "Wyrmskull Tablet", "", "Collecting", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 43, 22408, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186635;
INSERT INTO gameobject_template VALUES 
(186635, 3, 644, "Bakkalzu\'s Satchel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 22831, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=186636;
INSERT INTO gameobject_template VALUES 
(186636, 3, 644, "Bakkalzu\'s Satchel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 22832, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=186637;
INSERT INTO gameobject_template VALUES 
(186637, 3, 644, "Bakkalzu\'s Satchel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 22833, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=186638;
INSERT INTO gameobject_template VALUES 
(186638, 3, 644, "Bakkalzu\'s Satchel", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 22833, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=186640;
INSERT INTO gameobject_template VALUES 
(186640, 3, 6714, "Ancient Cipher", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 22697, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186648;
INSERT INTO gameobject_template VALUES 
(186648, 3, 41, "Hazlek\'s Trunk", "", "Opening", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1744, 22699, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 21400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186667;
INSERT INTO gameobject_template VALUES 
(186667, 3, 4191, "Norkani\'s Package", "", "Opening", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 57, 22790, 30, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 21400, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186736;
INSERT INTO gameobject_template VALUES 
(186736, 3, 323, "Money Bag", "", "", "", 0, 0, 0.4, 0, 0, 0, 0, 0, 0, 57, 22891, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186739;
INSERT INTO gameobject_template VALUES 
(186739, 3, 2450, "Amani Charm Box", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 57, 22903, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14333); 

DELETE FROM gameobject_template WHERE entry=186741;
INSERT INTO gameobject_template VALUES 
(186741, 3, 2450, "Amani Charm Box", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 57, 22905, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=186744;
INSERT INTO gameobject_template VALUES 
(186744, 3, 2450, "Amani Treasure Box", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 57, 39720, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=186940;
INSERT INTO gameobject_template VALUES 
(186940, 3, 7543, "Loose Rock", "", "", "", 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 1635, 22937, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=186948;
INSERT INTO gameobject_template VALUES 
(186948, 3, 259, "Omar\'s Magic (Tapped) Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 27081, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=186951;
INSERT INTO gameobject_template VALUES 
(186951, 3, 259, "Omar\'s Magic (Non-Tapped) Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 22351, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=187021;
INSERT INTO gameobject_template VALUES 
(187021, 3, 644, "Bakkalzu\'s Satchel", "", "Opening", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 57, 22968, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 21400, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187072;
INSERT INTO gameobject_template VALUES 
(187072, 3, 271, "Razorthorn Root", "", "", "", 0, 0, 0.2, 0, 0, 0, 0, 0, 0, 57, 22993, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=187238;
INSERT INTO gameobject_template VALUES 
(187238, 3, 7343, "Sorlof\'s Booty", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 23005, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187269;
INSERT INTO gameobject_template VALUES 
(187269, 3, 5744, "Reinforced Zierhut Chest", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 20531, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=187660;
INSERT INTO gameobject_template VALUES 
(187660, 3, 7638, "Warsong Munitions Crate", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 23083, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187661;
INSERT INTO gameobject_template VALUES 
(187661, 3, 7236, "Warsong Munitions Crate", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 23083, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187671;
INSERT INTO gameobject_template VALUES 
(187671, 3, 7626, "Tuskarr Ritual Object", "", "Collecting", "", 0, 0, 0.55, 0, 0, 0, 0, 0, 0, 1691, 23085, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187674;
INSERT INTO gameobject_template VALUES 
(187674, 3, 7641, "Ith\'rix\'s Hardened Carapace", "", "", "", 0, 0, 4, 0, 0, 0, 0, 0, 0, 1634, 23089, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=187685;
INSERT INTO gameobject_template VALUES 
(187685, 3, 7041, "Super Strong Metal Plate", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 23093, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=187686;
INSERT INTO gameobject_template VALUES 
(187686, 3, 450, "Super Strong Metal Plate", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 23093, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=187687;
INSERT INTO gameobject_template VALUES 
(187687, 3, 7643, "Super Strong Metal Plate", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 23093, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=187875;
INSERT INTO gameobject_template VALUES 
(187875, 3, 10, "Salrand\'s Lockbox", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 57, 23156, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=187898;
INSERT INTO gameobject_template VALUES 
(187898, 3, 449, "Fizzcrank Spare Parts", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 23168, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187899;
INSERT INTO gameobject_template VALUES 
(187899, 3, 6867, "Fizzcrank Spare Parts", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 23168, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187900;
INSERT INTO gameobject_template VALUES 
(187900, 3, 6868, "Fizzcrank Spare Parts", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 23168, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187901;
INSERT INTO gameobject_template VALUES 
(187901, 3, 451, "Fizzcrank Spare Parts", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 23168, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=187981;
INSERT INTO gameobject_template VALUES 
(187981, 3, 3675, "Wolf Droppings", "", "", "", 0, 0, 1.25, 0, 0, 0, 0, 0, 0, 1690, 23177, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=188016;
INSERT INTO gameobject_template VALUES 
(188016, 3, 7679, "Shipment of Animal Parts", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 23194, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=188017;
INSERT INTO gameobject_template VALUES 
(188017, 3, 335, "Shipment of Animal Parts", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 23194, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=188018;
INSERT INTO gameobject_template VALUES 
(188018, 3, 7680, "Shipment of Animal Parts", "", "Retrieving", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 93, 23194, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=188066;
INSERT INTO gameobject_template VALUES 
(188066, 3, 7687, "Kaw\'s War Halberd", "", "", "", 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 1634, 23230, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=188121;
INSERT INTO gameobject_template VALUES 
(188121, 3, 6891, "Agricultural Engineering for Dummies", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 23322, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188122;
INSERT INTO gameobject_template VALUES 
(188122, 3, 6892, "Harvest Collector Maintenance Guide", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 23323, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188191;
INSERT INTO gameobject_template VALUES 
(188191, 3, 1387, "Ice Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 23379, 9999, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188192;
INSERT INTO gameobject_template VALUES 
(188192, 3, 1387, "Ice Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 28683, 99999, 1, 0, 0, 17507, 188187, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=188263;
INSERT INTO gameobject_template VALUES 
(188263, 3, 222, "Missing Journal Page", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 23388, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=188367;
INSERT INTO gameobject_template VALUES 
(188367, 3, 2091, "Portable Seismograph", "", "Retrieving", "", 0, 0, 1.25, 0, 0, 0, 0, 0, 0, 43, 23406, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=188384;
INSERT INTO gameobject_template VALUES 
(188384, 3, 7766, "Carrion Field Victim", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 23415, 30, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188385;
INSERT INTO gameobject_template VALUES 
(188385, 3, 4093, "Carrion Field Victim", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 23415, 30, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188525;
INSERT INTO gameobject_template VALUES 
(188525, 3, 7788, "Drakkari Spirit Particles", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1690, 23890, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=188602;
INSERT INTO gameobject_template VALUES 
(188602, 3, 424, "Honeycone", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1690, 23917, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188603;
INSERT INTO gameobject_template VALUES 
(188603, 3, 7444, "Quickpoppy", "", "", "", 0, 0, 1.1, 0, 0, 0, 0, 0, 0, 1690, 23918, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188647;
INSERT INTO gameobject_template VALUES 
(188647, 3, 7819, "Petrified Dragon Bone", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1635, 23927, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188648;
INSERT INTO gameobject_template VALUES 
(188648, 3, 7820, "Petrified Dragon Bone", "", "", "", 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 1635, 23927, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=188650;
INSERT INTO gameobject_template VALUES 
(188650, 3, 7822, "Emerald Dragon Tear", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 23927, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=188677;
INSERT INTO gameobject_template VALUES 
(188677, 3, 164, "Scarlet Onslaught Daily Orders: Beach", "", "Stealing", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 23954, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26365, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=188699;
INSERT INTO gameobject_template VALUES 
(188699, 3, 7836, "Strange Ore", "Mine", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1775, 23964, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=189974;
INSERT INTO gameobject_template VALUES 
(189974, 3, 7845, "Constrictor Grass", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1124, 24094, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=189982;
INSERT INTO gameobject_template VALUES 
(189982, 3, 6798, "Titanium Node (DEPRECATED)", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1652, 24157, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=190168;
INSERT INTO gameobject_template VALUES 
(190168, 3, 6968, "Evergreen Moss", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1646, 24223, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=190174;
INSERT INTO gameobject_template VALUES 
(190174, 3, 8085, "Frozen Herb", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1124, 25096, 0, 1, 1, 1, 0, 0, 0, 72, 0, 0, 0, 0, 0, 0, 0, 0, 71, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=190175;
INSERT INTO gameobject_template VALUES 
(190175, 3, 8085, "Frozen Herb", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1793, 25095, 0, 1, 1, 1, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, 74, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=190354;
INSERT INTO gameobject_template VALUES 
(190354, 3, 8102, "Scythe of Antiok", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1635, 24293, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=190454;
INSERT INTO gameobject_template VALUES 
(190454, 3, 449, "Venture Co. Spare Parts", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 24317, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=190455;
INSERT INTO gameobject_template VALUES 
(190455, 3, 6867, "Venture Co. Spare Parts", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 24317, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=190483;
INSERT INTO gameobject_template VALUES 
(190483, 3, 10, "Document Chest #2", "", "Collecting", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 93, 13576, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=190484;
INSERT INTO gameobject_template VALUES 
(190484, 3, 10, "Document Chest #3", "", "Collecting", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 93, 13577, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=190558;
INSERT INTO gameobject_template VALUES 
(190558, 3, 7942, "Shining Crystal", "", "Retrieving", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1690, 24387, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=190560;
INSERT INTO gameobject_template VALUES 
(190560, 3, 7943, "Glinting Armor", "Interact", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 24387, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=190561;
INSERT INTO gameobject_template VALUES 
(190561, 3, 7841, "Glowing Gem", "Interact", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 24387, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 13623); 

DELETE FROM gameobject_template WHERE entry=190562;
INSERT INTO gameobject_template VALUES 
(190562, 3, 7944, "Polished Platter", "Interact", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 24387, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=190563;
INSERT INTO gameobject_template VALUES 
(190563, 3, 2614, "Sparkling Treasure", "Interact", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 24387, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=190583;
INSERT INTO gameobject_template VALUES 
(190583, 3, 7687, "Battle-worn Axe", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1635, 24610, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=190613;
INSERT INTO gameobject_template VALUES 
(190613, 3, 2450, "Treasure of Gawanil", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 24730, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=190614;
INSERT INTO gameobject_template VALUES 
(190614, 3, 2450, "Treasure of Kutube\'sa", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 24731, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=190643;
INSERT INTO gameobject_template VALUES 
(190643, 3, 334, "Thunderbrew\'s Jungle Punch", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 24742, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=190696;
INSERT INTO gameobject_template VALUES 
(190696, 3, 323, "Mosswalker Possesions", "", "", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 1691, 24750, 0, 1, 0, 0, 0, 0, 12580, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=190717;
INSERT INTO gameobject_template VALUES 
(190717, 3, 6573, "Underworld Power Fragment", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1690, 24756, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=190718;
INSERT INTO gameobject_template VALUES 
(190718, 3, 7989, "Underworld Power Fragment", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1690, 24756, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=190719;
INSERT INTO gameobject_template VALUES 
(190719, 3, 6571, "Underworld Power Fragment", "", "Collecting", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 1690, 24756, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191179;
INSERT INTO gameobject_template VALUES 
(191179, 3, 7795, "Stormwatcher\'s Head", "", "", "", 0, 0, 1.75, 0, 0, 0, 0, 0, 0, 1691, 25025, 0, 1, 0, 0, 0, 0, 12758, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11159); 

DELETE FROM gameobject_template WHERE entry=191368;
INSERT INTO gameobject_template VALUES 
(191368, 25, 6291, "(TESTING) Rare Fish Node", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 25106, 100, 100, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=191458;
INSERT INTO gameobject_template VALUES 
(191458, 3, 6928, "Drakuru\'s Skull", "", "", "", 0, 0, 5, 0, 0, 0, 0, 0, 0, 1691, 25108, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191531;
INSERT INTO gameobject_template VALUES 
(191531, 3, 6314, "Charred Wreckage", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 25277, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191532;
INSERT INTO gameobject_template VALUES 
(191532, 3, 449, "Charred Wreckage", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 25277, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191534;
INSERT INTO gameobject_template VALUES 
(191534, 3, 6868, "Charred Wreckage", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 25277, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191535;
INSERT INTO gameobject_template VALUES 
(191535, 3, 8108, "Charred Wreckage", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 25277, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191536;
INSERT INTO gameobject_template VALUES 
(191536, 3, 7000, "Charred Wreckage", "", "Retrieving", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1690, 25277, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191537;
INSERT INTO gameobject_template VALUES 
(191537, 3, 5391, "Charred Wreckage", "", "Retrieving", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 1690, 25277, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191600;
INSERT INTO gameobject_template VALUES 
(191600, 3, 8116, "Unfortunate Snobold", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 25343, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=191601;
INSERT INTO gameobject_template VALUES 
(191601, 3, 8117, "Unfortunate Snobold", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 25343, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=191602;
INSERT INTO gameobject_template VALUES 
(191602, 3, 8118, "Unfortunate Snobold", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 25343, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=191603;
INSERT INTO gameobject_template VALUES 
(191603, 3, 8119, "Unfortunate Snobold", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 25343, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=191604;
INSERT INTO gameobject_template VALUES 
(191604, 3, 8120, "Unfortunate Snobold", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 25343, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=191773;
INSERT INTO gameobject_template VALUES 
(191773, 3, 1867, "Eagle Egg", "", "Gathering", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 1690, 25364, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24982, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191777;
INSERT INTO gameobject_template VALUES 
(191777, 3, 8180, "Gooey Ghoul Drool", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 24743, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=191781;
INSERT INTO gameobject_template VALUES 
(191781, 3, 8183, "Scourge Scrap Metal", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1635, 25391, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191782;
INSERT INTO gameobject_template VALUES 
(191782, 3, 7974, "Scourge Scrap Metal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1635, 25391, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191783;
INSERT INTO gameobject_template VALUES 
(191783, 3, 7975, "Scourge Scrap Metal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1635, 25391, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191815;
INSERT INTO gameobject_template VALUES 
(191815, 3, 8187, "Granite Boulder", "", "", "", 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 1691, 25498, 0, 1, 0, 0, 0, 0, 12915, 0, 0, 0, 0, 0, 30585, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191844;
INSERT INTO gameobject_template VALUES 
(191844, 3, 8194, "Enchanted Earth", "Mine", "", "", 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 1802, 25621, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=191845;
INSERT INTO gameobject_template VALUES 
(191845, 3, 8195, "Enchanted Earth", "Mine", "", "", 0, 0, 0.2, 0, 0, 0, 0, 0, 0, 1802, 25621, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192047;
INSERT INTO gameobject_template VALUES 
(192047, 25, 6482, "Bonescale Snapper School", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 25666, 3, 5, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=192055;
INSERT INTO gameobject_template VALUES 
(192055, 25, 6482, "Rockfin Grouper School", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 25667, 3, 5, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=192056;
INSERT INTO gameobject_template VALUES 
(192056, 25, 6482, "Barrelhead Goby School", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 25672, 3, 5, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=192081;
INSERT INTO gameobject_template VALUES 
(192081, 3, 8222, "Horn Fragment", "", "", "", 0, 0, 0.02, 0, 0, 0, 0, 0, 0, 1691, 25677, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192082;
INSERT INTO gameobject_template VALUES 
(192082, 3, 8223, "Horn Fragment", "", "", "", 0, 0, 0.02, 0, 0, 0, 0, 0, 0, 1691, 25677, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192127;
INSERT INTO gameobject_template VALUES 
(192127, 3, 8231, "Frozen Iron Scrap", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 1691, 25684, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192187;
INSERT INTO gameobject_template VALUES 
(192187, 3, 8247, "Everfrost Shard", "", "", "", 0, 0, 0.06, 0, 0, 0, 0, 0, 0, 1691, 25695, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192188;
INSERT INTO gameobject_template VALUES 
(192188, 3, 8247, "Everfrost Shard", "", "", "", 0, 0, 0.09, 0, 0, 0, 0, 0, 0, 1691, 25695, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192189;
INSERT INTO gameobject_template VALUES 
(192189, 3, 8247, "Everfrost Shard", "", "", "", 0, 0, 0.03, 0, 0, 0, 0, 0, 0, 1691, 25695, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192190;
INSERT INTO gameobject_template VALUES 
(192190, 3, 8247, "Everfrost Shard", "", "", "", 0, 0, 0.03, 0, 0, 0, 0, 0, 0, 1691, 25695, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192191;
INSERT INTO gameobject_template VALUES 
(192191, 3, 8247, "Everfrost Shard", "", "", "", 0, 0, 0.09, 0, 0, 0, 0, 0, 0, 1691, 25695, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192192;
INSERT INTO gameobject_template VALUES 
(192192, 3, 8247, "Everfrost Shard", "", "", "", 0, 0, 0.05, 0, 0, 0, 0, 0, 0, 1691, 25695, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192536;
INSERT INTO gameobject_template VALUES 
(192536, 3, 7398, "Small Proto-Drake Egg", "", "Collecting", "", 0, 0, 1.7, 0, 0, 0, 0, 0, 0, 1691, 25749, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192676;
INSERT INTO gameobject_template VALUES 
(192676, 3, 424, "Emerald Acorn", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1690, 25756, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192910;
INSERT INTO gameobject_template VALUES 
(192910, 3, 8354, "Ancient Elven Masonry", "", "", "", 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 1634, 25912, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192911;
INSERT INTO gameobject_template VALUES 
(192911, 3, 8355, "Ancient Elven Masonry", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1634, 25912, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192912;
INSERT INTO gameobject_template VALUES 
(192912, 3, 8356, "Ancient Elven Masonry", "", "", "", 0, 0, 0.15, 0, 0, 0, 0, 0, 0, 1634, 25912, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=192943;
INSERT INTO gameobject_template VALUES 
(192943, 3, 7075, "Shiny Bauble", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 1691, 25926, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193038;
INSERT INTO gameobject_template VALUES 
(193038, 3, 3711, "Eternal Embers", "", "", "", 0, 0, 0.1, 0, 0, 0, 0, 0, 0, 1690, 26006, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=193046;
INSERT INTO gameobject_template VALUES 
(193046, 3, 7624, "Rusty Armor", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 26105, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=193047;
INSERT INTO gameobject_template VALUES 
(193047, 3, 6327, "Splintered Dragon Bone", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 26106, 30, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=193091;
INSERT INTO gameobject_template VALUES 
(193091, 3, 1747, "Spool of Thread", "", "", "", 0, 0, 1.75, 0, 0, 0, 0, 0, 0, 1691, 26189, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=193092;
INSERT INTO gameobject_template VALUES 
(193092, 3, 8392, "The Doctor\'s Cleaver", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 26190, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=193196;
INSERT INTO gameobject_template VALUES 
(193196, 3, 8416, "Fordragon\'s Shield", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1635, 26230, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193197;
INSERT INTO gameobject_template VALUES 
(193197, 3, 8501, "Saurfang\'s Battle Armor", "", "", "", 0, 0, 1.2, 0, 0, 0, 0, 0, 0, 1635, 26232, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193199;
INSERT INTO gameobject_template VALUES 
(193199, 3, 6998, "Pile of Bones", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1691, 26237, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193419;
INSERT INTO gameobject_template VALUES 
(193419, 3, 8449, "Sewer Noggenfogger Elixir", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 26359, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=193426;
INSERT INTO gameobject_template VALUES 
(193426, 3, 1387, "Four Horsemen Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 25193, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=193767;
INSERT INTO gameobject_template VALUES 
(193767, 3, 8122, "Shard of Horror", "Attack", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 99, 26666, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193792;
INSERT INTO gameobject_template VALUES 
(193792, 3, 8122, "Shard of Despair", "Attack", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 99, 26667, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193793;
INSERT INTO gameobject_template VALUES 
(193793, 3, 8122, "Shard of Suffering", "Attack", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 99, 26668, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14545); 

DELETE FROM gameobject_template WHERE entry=193905;
INSERT INTO gameobject_template VALUES 
(193905, 3, 8513, "Alexstrasza\'s Gift", "", "", "", 0, 0, 15, 0, 0, 0, 0, 0, 0, 1818, 26094, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193944;
INSERT INTO gameobject_template VALUES 
(193944, 3, 8508, "Alumeth\'s Heart", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 26682, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193953;
INSERT INTO gameobject_template VALUES 
(193953, 3, 7804, "Saronite Deposit", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1783, 26691, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=193954;
INSERT INTO gameobject_template VALUES 
(193954, 3, 7804, "Rich Saronite Deposit", "", "", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 1784, 26692, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=193967;
INSERT INTO gameobject_template VALUES 
(193967, 3, 8513, "Alexstrasza\'s Gift", "", "", "", 0, 0, 15, 0, 0, 0, 0, 0, 0, 1818, 26097, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=193996;
INSERT INTO gameobject_template VALUES 
(193996, 3, 1387, "Tribunal Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 26260, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194158;
INSERT INTO gameobject_template VALUES 
(194158, 3, 8555, "Heart of Magic", "", "", "", 0, 0, 7, 0, 0, 0, 0, 0, 0, 1818, 26859, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194159;
INSERT INTO gameobject_template VALUES 
(194159, 3, 8555, "Heart of Magic", "", "", "", 0, 0, 7, 0, 0, 0, 0, 0, 0, 1818, 26860, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194200;
INSERT INTO gameobject_template VALUES 
(194200, 3, 8630, "Rare Cache of Winter", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 27069, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194201;
INSERT INTO gameobject_template VALUES 
(194201, 3, 8630, "Rare Cache of Winter", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 26950, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=194308;
INSERT INTO gameobject_template VALUES 
(194308, 3, 8685, "Cache of Winter", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 26946, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=194312;
INSERT INTO gameobject_template VALUES 
(194312, 3, 8627, "Cache of Storms", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 27073, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=194313;
INSERT INTO gameobject_template VALUES 
(194313, 3, 8627, "Cache of Storms", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 27074, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194314;
INSERT INTO gameobject_template VALUES 
(194314, 3, 8627, "Cache of Storms", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 26955, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=194315;
INSERT INTO gameobject_template VALUES 
(194315, 3, 8627, "Cache of Storms", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 26956, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 0); 

DELETE FROM gameobject_template WHERE entry=194325;
INSERT INTO gameobject_template VALUES 
(194325, 3, 8628, "Freya\'s Gift", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27079, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11159); 

DELETE FROM gameobject_template WHERE entry=194326;
INSERT INTO gameobject_template VALUES 
(194326, 3, 8628, "Freya\'s Gift", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27080, 0, 1, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -1); 

DELETE FROM gameobject_template WHERE entry=194327;
INSERT INTO gameobject_template VALUES 
(194327, 3, 8628, "Freya\'s Gift", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27081, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194328;
INSERT INTO gameobject_template VALUES 
(194328, 3, 8628, "Freya\'s Gift", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 26959, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -1); 

DELETE FROM gameobject_template WHERE entry=194329;
INSERT INTO gameobject_template VALUES 
(194329, 3, 8628, "Freya\'s Gift", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 26960, 0, 1, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -1); 

DELETE FROM gameobject_template WHERE entry=194330;
INSERT INTO gameobject_template VALUES 
(194330, 3, 8628, "Freya\'s Gift", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 26961, 0, 1, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -1); 

DELETE FROM gameobject_template WHERE entry=194331;
INSERT INTO gameobject_template VALUES 
(194331, 3, 8628, "Freya\'s Gift", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 26962, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=194341;
INSERT INTO gameobject_template VALUES 
(194341, 3, 470, "Dusty Journal", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 26878, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194431;
INSERT INTO gameobject_template VALUES 
(194431, 3, 242, "Dead Fish", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 3627, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=194432;
INSERT INTO gameobject_template VALUES 
(194432, 3, 275, "Crate", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 57, 23153, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=194433;
INSERT INTO gameobject_template VALUES 
(194433, 3, 225, "Bottle", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 16572, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=194789;
INSERT INTO gameobject_template VALUES 
(194789, 3, 8686, "Cache of Innovation", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 27085, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194821;
INSERT INTO gameobject_template VALUES 
(194821, 3, 8691, "Gift of the Observer", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 27030, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=194822;
INSERT INTO gameobject_template VALUES 
(194822, 3, 8691, "Gift of the Observer", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 26974, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=194956;
INSERT INTO gameobject_template VALUES 
(194956, 3, 8686, "Cache of Innovation", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 26963, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -1); 

DELETE FROM gameobject_template WHERE entry=194957;
INSERT INTO gameobject_template VALUES 
(194957, 3, 8686, "Cache of Innovation", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 27086, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=194958;
INSERT INTO gameobject_template VALUES 
(194958, 3, 8686, "Cache of Innovation", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 26967, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=195047;
INSERT INTO gameobject_template VALUES 
(195047, 3, 8685, "Cache of Living Stone", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 26929, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=195075;
INSERT INTO gameobject_template VALUES 
(195075, 3, 6895, "Dellylah\'s Stolen Beans", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 27257, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=195076;
INSERT INTO gameobject_template VALUES 
(195076, 3, 32, "Dellylah\'s Stolen Water", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 27259, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=195183;
INSERT INTO gameobject_template VALUES 
(195183, 3, 8952, "Black Mandrake", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 27284, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=195323;
INSERT INTO gameobject_template VALUES 
(195323, 3, 9069, "Confessor\'s Cache", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27327, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=195324;
INSERT INTO gameobject_template VALUES 
(195324, 3, 9069, "Confessor\'s Cache", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27417, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=195374;
INSERT INTO gameobject_template VALUES 
(195374, 3, 9069, "Eadric\'s Cache", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27325, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=195375;
INSERT INTO gameobject_template VALUES 
(195375, 3, 9069, "Eadric\'s Cache", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27416, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=195440;
INSERT INTO gameobject_template VALUES 
(195440, 3, 434, "Melonfruit", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 1691, 27444, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=195519;
INSERT INTO gameobject_template VALUES 
(195519, 3, 9056, "Weapon Rack", "", "", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 1691, 27511, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=195535;
INSERT INTO gameobject_template VALUES 
(195535, 3, 293, "Bleached Skullpile", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 27521, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=195632;
INSERT INTO gameobject_template VALUES 
(195632, 3, 9069, "Champions\' Cache", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 27503, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=195633;
INSERT INTO gameobject_template VALUES 
(195633, 3, 9069, "Champions\' Cache", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 27335, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=195635;
INSERT INTO gameobject_template VALUES 
(195635, 3, 9069, "Champions\' Cache", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 1634, 27356, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=195709;
INSERT INTO gameobject_template VALUES 
(195709, 3, 9069, "Champion\'s Cache", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27321, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=195710;
INSERT INTO gameobject_template VALUES 
(195710, 3, 9069, "Champion\'s Cache", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1634, 27414, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=196395;
INSERT INTO gameobject_template VALUES 
(196395, 3, 406, "Defiled Relic", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 27572, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=199330;
INSERT INTO gameobject_template VALUES 
(199330, 3, 2652, "Highborne Tablet", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 43, 27715, 0, 1, 0, 0, 0, 0, 14486, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=199331;
INSERT INTO gameobject_template VALUES 
(199331, 3, 2653, "Highborne Tablet", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 43, 27715, 0, 1, 0, 0, 0, 0, 14486, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=199332;
INSERT INTO gameobject_template VALUES 
(199332, 3, 2654, "Highborne Tablet", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 43, 27715, 0, 1, 0, 0, 0, 0, 14486, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=201384;
INSERT INTO gameobject_template VALUES 
(201384, 3, 7679, "Clean Laundry", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 27725, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=201562;
INSERT INTO gameobject_template VALUES 
(201562, 3, 7756, "Seaweed Frond", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 23395, 30, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=201572;
INSERT INTO gameobject_template VALUES 
(201572, 3, 9182, "SFG", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 27729, 0, 1, 0, 0, 0, 0, 14470, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=201579;
INSERT INTO gameobject_template VALUES 
(201579, 3, 9185, "Keystone Shard", "", "Retrieving", "", 0, 0, 0.45, 0, 0, 0, 0, 0, 0, 93, 27554, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=201738;
INSERT INTO gameobject_template VALUES 
(201738, 3, 3231, "Budding Flower", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 259, 27751, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=201778;
INSERT INTO gameobject_template VALUES 
(201778, 3, 6656, "Crown Chemical Co. Supplies", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 27766, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=201794;
INSERT INTO gameobject_template VALUES 
(201794, 3, 9310, "Quel\'Delar", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1691, 27768, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=201813;
INSERT INTO gameobject_template VALUES 
(201813, 3, 9228, "Shadow\'s Edge", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1691, 27772, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=201905;
INSERT INTO gameobject_template VALUES 
(201905, 3, 412, "Bloodtalon Eggs", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2495, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=201924;
INSERT INTO gameobject_template VALUES 
(201924, 3, 9240, "Boar Skull", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 27785, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=201937;
INSERT INTO gameobject_template VALUES 
(201937, 3, 8213, "Light\'s Vengeance", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 27787, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "SmartGameObjectAI", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202080;
INSERT INTO gameobject_template VALUES 
(202080, 3, 7202, "Dart\'s Nest", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 27828, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202081;
INSERT INTO gameobject_template VALUES 
(202081, 3, 7202, "Takk\'s Nest", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 27827, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202082;
INSERT INTO gameobject_template VALUES 
(202082, 3, 7202, "Ravasaur Matriarch\'s Nest", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 27829, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=202137;
INSERT INTO gameobject_template VALUES 
(202137, 3, 406, "Kaldorei Artifact", "", "", "", 0, 0, 3, 0, 0, 0, 0, 0, 0, 43, 27845, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202158;
INSERT INTO gameobject_template VALUES 
(202158, 3, 6606, "Discarded Supplies", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 27848, 0, 1, 0, 0, 0, 202208, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202159;
INSERT INTO gameobject_template VALUES 
(202159, 3, 31, "Discarded Supplies", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 27848, 0, 1, 0, 0, 0, 202208, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202160;
INSERT INTO gameobject_template VALUES 
(202160, 3, 36, "Discarded Supplies", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 27848, 0, 1, 0, 0, 0, 202208, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202165;
INSERT INTO gameobject_template VALUES 
(202165, 3, 20, "Suspicious Mound of Dirt", "", "Digging", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 27849, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35059, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=202177;
INSERT INTO gameobject_template VALUES 
(202177, 3, 9281, "Gunship Armory", "", "", "", 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 1634, 28057, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=202178;
INSERT INTO gameobject_template VALUES 
(202178, 3, 9281, "Gunship Armory", "", "", "", 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 1634, 28045, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14007); 

DELETE FROM gameobject_template WHERE entry=202179;
INSERT INTO gameobject_template VALUES 
(202179, 3, 9281, "Gunship Armory", "", "", "", 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 1634, 28090, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15050); 

DELETE FROM gameobject_template WHERE entry=202180;
INSERT INTO gameobject_template VALUES 
(202180, 3, 9281, "Gunship Armory", "", "", "", 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 1634, 28072, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 11723); 

DELETE FROM gameobject_template WHERE entry=202238;
INSERT INTO gameobject_template VALUES 
(202238, 3, 9233, "Deathbringer\'s Cache", "", "", "", 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 1634, 28058, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=202241;
INSERT INTO gameobject_template VALUES 
(202241, 3, 9233, "Deathbringer\'s Cache", "", "", "", 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 1634, 28088, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202337;
INSERT INTO gameobject_template VALUES 
(202337, 3, 9281, "The Captain\'s Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 27993, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202338;
INSERT INTO gameobject_template VALUES 
(202338, 3, 9233, "Cache of the Dreamwalker", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 57, 28064, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=202339;
INSERT INTO gameobject_template VALUES 
(202339, 3, 9233, "Cache of the Dreamwalker", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 57, 28082, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 12340); 

DELETE FROM gameobject_template WHERE entry=202340;
INSERT INTO gameobject_template VALUES 
(202340, 3, 9233, "Cache of the Dreamwalker", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 28096, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15050); 

DELETE FROM gameobject_template WHERE entry=202423;
INSERT INTO gameobject_template VALUES 
(202423, 3, 1767, "Risen Dune", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 28236, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202441;
INSERT INTO gameobject_template VALUES 
(202441, 3, 768, "Jang\'thraze the Protector", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 28238, 0, 1, 0, 0, 23786, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11711, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202473;
INSERT INTO gameobject_template VALUES 
(202473, 3, 7763, "Meatface\'s Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 28371, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202478;
INSERT INTO gameobject_template VALUES 
(202478, 3, 450, "Siege Engine Scrap", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 28373, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202480;
INSERT INTO gameobject_template VALUES 
(202480, 3, 5744, "Reinforced Nakada Chest", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 57, 55, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202553;
INSERT INTO gameobject_template VALUES 
(202553, 3, 9358, "Kaja\'Cola Zero-One", "", "Grabbing", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1818, 28398, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37379, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202554;
INSERT INTO gameobject_template VALUES 
(202554, 3, 9359, "Kaja\'Cola Zero-One", "", "Grabbing", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1818, 28398, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37379, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202556;
INSERT INTO gameobject_template VALUES 
(202556, 3, 9363, "Oxygenated Seaweed", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 28401, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202567;
INSERT INTO gameobject_template VALUES 
(202567, 3, 7414, "Keg of Ol\' Barkerstout", "", "", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 93, 28414, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202573;
INSERT INTO gameobject_template VALUES 
(202573, 3, 7414, "Keg of Ol\' Barkerstout - TEST", "", "", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 93, 28414, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202608;
INSERT INTO gameobject_template VALUES 
(202608, 3, 5051, "Spare Shredder Parts", "", "Salvaging", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 28420, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39388, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202654;
INSERT INTO gameobject_template VALUES 
(202654, 3, 52, "Dwarf Archaeology Chest 04", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1859, 28434, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202743;
INSERT INTO gameobject_template VALUES 
(202743, 3, 9398, "Lightning Channel", "", "", "", 0, 0, 1.2, 0, 0, 0, 0, 0, 0, 93, 28489, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202777;
INSERT INTO gameobject_template VALUES 
(202777, 25, 6482, "Highland Guppy School", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 28556, 3, 5, 1628, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202779;
INSERT INTO gameobject_template VALUES 
(202779, 25, 6482, "Blackbelly Mudfish School", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 28561, 3, 5, 1628, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202783;
INSERT INTO gameobject_template VALUES 
(202783, 25, 6482, "(TESTING) Crafty\'s Special Fishing School", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 28567, 50, 50, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=202793;
INSERT INTO gameobject_template VALUES 
(202793, 3, 20, "Loose Soil", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 1691, 28573, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202875;
INSERT INTO gameobject_template VALUES 
(202875, 3, 627, "Waterlogged Driftwood", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 28599, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202876;
INSERT INTO gameobject_template VALUES 
(202876, 3, 9556, "Fibrous Vine", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 28600, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202896;
INSERT INTO gameobject_template VALUES 
(202896, 3, 8938, "Sambino\'s Air Valve", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 28630, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202957;
INSERT INTO gameobject_template VALUES 
(202957, 3, 449, "Rocket Car Parts", "", "Collecting", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 43, 28689, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202958;
INSERT INTO gameobject_template VALUES 
(202958, 3, 451, "Rocket Car Parts", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 28689, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202959;
INSERT INTO gameobject_template VALUES 
(202959, 3, 452, "Rocket Car Parts", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 28689, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202960;
INSERT INTO gameobject_template VALUES 
(202960, 3, 453, "Rocket Car Parts", "", "Collecting", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 43, 28689, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=202961;
INSERT INTO gameobject_template VALUES 
(202961, 3, 454, "Rocket Car Parts", "", "Collecting", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 43, 28689, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203017;
INSERT INTO gameobject_template VALUES 
(203017, 3, 9487, "Captain Taylor\'s Flare Gun", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 29306, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203019;
INSERT INTO gameobject_template VALUES 
(203019, 3, 8367, "Pirate Booty", "", "", "", 0, 0, 0.7, 0, 0, 0, 0, 0, 0, 1691, 27856, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203021;
INSERT INTO gameobject_template VALUES 
(203021, 3, 7075, "Pirate Booty", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 27856, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203022;
INSERT INTO gameobject_template VALUES 
(203022, 3, 9488, "Pirate Booty", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 1691, 27856, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203068;
INSERT INTO gameobject_template VALUES 
(203068, 3, 8576, "Troll Archaeology Chest 02", "", "", "", 0, 0, 0.35, 0, 0, 0, 0, 0, 0, 1859, 24153, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203069;
INSERT INTO gameobject_template VALUES 
(203069, 3, 7495, "Troll Archaeology Chest 03", "", "", "", 0, 0, 0.35, 0, 0, 0, 0, 0, 0, 1859, 24153, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203070;
INSERT INTO gameobject_template VALUES 
(203070, 3, 9497, "Dwarf Archaeology Chest 02", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1859, 28434, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203072;
INSERT INTO gameobject_template VALUES 
(203072, 3, 6821, "Night Elfl Archaeology Chest 03", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1859, 28434, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203073;
INSERT INTO gameobject_template VALUES 
(203073, 3, 406, "Night Elf Archaeology Chest 02", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1859, 28434, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203074;
INSERT INTO gameobject_template VALUES 
(203074, 3, 8299, "Dwarf Archaeology Chest 03", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1859, 28434, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203075;
INSERT INTO gameobject_template VALUES 
(203075, 3, 10490, "Fossil", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1859, 28434, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203076;
INSERT INTO gameobject_template VALUES 
(203076, 3, 9498, "Fossil", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1859, 28434, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203077;
INSERT INTO gameobject_template VALUES 
(203077, 3, 9499, "Lost Aqir Object", "", "", "", 0, 0, 0.35, 0, 0, 0, 0, 0, 0, 1859, 24153, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203099;
INSERT INTO gameobject_template VALUES 
(203099, 3, 5391, "Fiasco\'s Stray Part", "", "Retrieving", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 1690, 29524, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203100;
INSERT INTO gameobject_template VALUES 
(203100, 3, 8108, "Fiasco\'s Stray Part", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 29524, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203101;
INSERT INTO gameobject_template VALUES 
(203101, 3, 6868, "Fiasco\'s Stray Part", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 29524, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203102;
INSERT INTO gameobject_template VALUES 
(203102, 3, 449, "Fiasco\'s Stray Part", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 29524, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203103;
INSERT INTO gameobject_template VALUES 
(203103, 3, 6867, "Fiasco\'s Stray Part", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1690, 29524, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203104;
INSERT INTO gameobject_template VALUES 
(203104, 3, 7000, "Fiasco\'s Stray Part", "", "Retrieving", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1690, 29524, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203172;
INSERT INTO gameobject_template VALUES 
(203172, 3, 748, "Rusty Harpoon", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 29564, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203184;
INSERT INTO gameobject_template VALUES 
(203184, 3, 2091, "Thelgen Seismograph", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 93, 29575, 0, 0, 0, 0, 24668, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203188;
INSERT INTO gameobject_template VALUES 
(203188, 3, 384, "Incendicite Mineral Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1896, 29574, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203198;
INSERT INTO gameobject_template VALUES 
(203198, 3, 454, "Twilight Armor Plate", "", "Collecting", "", 0, 0, 0.45, 0, 0, 0, 0, 0, 0, 43, 29580, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203205;
INSERT INTO gameobject_template VALUES 
(203205, 3, 4192, "Dreadmaul Cache", "", "", "", 0, 0, 1.7, 0, 0, 0, 0, 0, 0, 43, 29582, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203206;
INSERT INTO gameobject_template VALUES 
(203206, 3, 4192, "Dreadmaul Cache", "", "", "", 0, 0, 1.7, 0, 0, 0, 0, 0, 0, 43, 29583, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203215;
INSERT INTO gameobject_template VALUES 
(203215, 3, 404, "Eldre\'thar Relic", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 29585, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203216;
INSERT INTO gameobject_template VALUES 
(203216, 3, 405, "Eldre\'thar Relic", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 29585, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203230;
INSERT INTO gameobject_template VALUES 
(203230, 3, 4411, "Head of Grol", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 29600, 0, 1, 0, 0, 24694, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9940, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203232;
INSERT INTO gameobject_template VALUES 
(203232, 3, 9538, "Ancient Artifact", "", "", "", 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 1691, 29604, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203264;
INSERT INTO gameobject_template VALUES 
(203264, 3, 9259, "Wobbling Raptor Egg", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 29624, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203278;
INSERT INTO gameobject_template VALUES 
(203278, 3, 6650, "Obsidium Deposit", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 1861, 28490, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203280;
INSERT INTO gameobject_template VALUES 
(203280, 3, 8053, "Alliance Weapon Crate", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 29604, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203283;
INSERT INTO gameobject_template VALUES 
(203283, 3, 318, "Archaeologist\'s Tools", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 29626, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=203286;
INSERT INTO gameobject_template VALUES 
(203286, 3, 449, "Swiftgear Gizmo", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 29627, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203287;
INSERT INTO gameobject_template VALUES 
(203287, 3, 6867, "Swiftgear Gizmo", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 29627, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203288;
INSERT INTO gameobject_template VALUES 
(203288, 3, 6868, "Swiftgear Gizmo", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 29627, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203298;
INSERT INTO gameobject_template VALUES 
(203298, 3, 310, "Copper Vein", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 38, 1502, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203307;
INSERT INTO gameobject_template VALUES 
(203307, 3, 9571, "Wiggleweed", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1691, 29638, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=203396;
INSERT INTO gameobject_template VALUES 
(203396, 3, 9487, "Nazgrim\'s Flare Gun", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 29667, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203403;
INSERT INTO gameobject_template VALUES 
(203403, 3, 7539, "Survival Kit Remnants", "", "Searching", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 29668, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19680, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=203410;
INSERT INTO gameobject_template VALUES 
(203410, 3, 7539, "Survival Kit Remnants", "", "Searching", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 29668, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19680, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=203453;
INSERT INTO gameobject_template VALUES 
(203453, 3, 10057, "Scalding Shroom", "", "Collecting", "", 0, 0, 6, 0, 0, 0, 0, 0, 0, 1691, 29737, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15354); 

DELETE FROM gameobject_template WHERE entry=204133;
INSERT INTO gameobject_template VALUES 
(204133, 3, 2450, "Cache of Shadra", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 30439, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=204297;
INSERT INTO gameobject_template VALUES 
(204297, 3, 9716, "Chalky Crystal Formation", "", "Retrieving", "", 0, 0, 0.08, 0, 0, 0, 0, 0, 0, 1691, 30858, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=204464;
INSERT INTO gameobject_template VALUES 
(204464, 3, 9749, "Pile of Scraps", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 30940, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=204960;
INSERT INTO gameobject_template VALUES 
(204960, 3, 259, "Test Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 2772, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=204965;
INSERT INTO gameobject_template VALUES 
(204965, 3, 9782, "The Middle Fragment of the World Pillar", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 93, 31472, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=205093;
INSERT INTO gameobject_template VALUES 
(205093, 3, 9837, "Nascent Elementium", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 43, 31999, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=205094;
INSERT INTO gameobject_template VALUES 
(205094, 3, 9838, "Nascent Elementium", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 43, 31999, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=205095;
INSERT INTO gameobject_template VALUES 
(205095, 3, 9839, "Nascent Elementium", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 43, 31999, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=205554;
INSERT INTO gameobject_template VALUES 
(205554, 3, 228, "Stolen Silversnap Ice", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 34717, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=206085;
INSERT INTO gameobject_template VALUES 
(206085, 3, 8085, "Frozen Herb", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 45, 34868, 0, 1, 1, 1, 0, 0, 0, 25, 0, 0, 0, 0, 0, 0, 0, 0, 25, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206292;
INSERT INTO gameobject_template VALUES 
(206292, 3, 7415, "Wildhammer Ale Cask", "", "Retrieving", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 1691, 35331, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206510;
INSERT INTO gameobject_template VALUES 
(206510, 3, 8685, "Scavenged Treasure Chest", "", "", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 43, 33841, 30, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=206563;
INSERT INTO gameobject_template VALUES 
(206563, 3, 10092, "Well-preserved Idol", "", "Carefully Collecting", "", 0, 0, 0.2, 0, 0, 0, 0, 0, 0, 43, 35518, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47358, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206584;
INSERT INTO gameobject_template VALUES 
(206584, 3, 5744, "Neferset Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 35538, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=206588;
INSERT INTO gameobject_template VALUES 
(206588, 3, 10100, "Neferset Armor", "", "Stealing", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 35540, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26365, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206591;
INSERT INTO gameobject_template VALUES 
(206591, 3, 10104, "Neferset Armor", "", "Stealing", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 35540, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26365, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206592;
INSERT INTO gameobject_template VALUES 
(206592, 25, 6291, "Brilliant Smallfish School", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 35544, 2, 3, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=206651;
INSERT INTO gameobject_template VALUES 
(206651, 3, 6867, "Siege Scrap", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 35556, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206652;
INSERT INTO gameobject_template VALUES 
(206652, 3, 9567, "Siege Scrap", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 35556, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206672;
INSERT INTO gameobject_template VALUES 
(206672, 3, 9921, "Dragonmaw Weapon Rack", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 35358, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206673;
INSERT INTO gameobject_template VALUES 
(206673, 3, 9561, "Dragonmaw Weapon Axe", "", "Retrieving", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 35358, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=206724;
INSERT INTO gameobject_template VALUES 
(206724, 3, 10146, "The Demon Chain", "", "Grabbing", "", 0, 0, 0.75, 0, 0, 0, 0, 0, 0, 43, 35625, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37379, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 14007); 

DELETE FROM gameobject_template WHERE entry=206836;
INSERT INTO gameobject_template VALUES 
(206836, 3, 10490, "Fossil Archaeology Find", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1859, 35733, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 85, 2, 0, 0, 0, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=207090;
INSERT INTO gameobject_template VALUES 
(207090, 3, 8446, "Used Blight Canister", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 43, 35870, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=207143;
INSERT INTO gameobject_template VALUES 
(207143, 3, 9587, "Alliance Battle Plans", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1852, 35947, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207158;
INSERT INTO gameobject_template VALUES 
(207158, 3, 3651, "Pristine Owl Feather", "", "Collecting", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 43, 35989, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=207162;
INSERT INTO gameobject_template VALUES 
(207162, 3, 9105, "Crate of Fine Cloth", "", "Stealing", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 93, 35990, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26365, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=207346;
INSERT INTO gameobject_template VALUES 
(207346, 3, 10242, "Moonpetal Lily", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 9605, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=207481;
INSERT INTO gameobject_template VALUES 
(207481, 3, 259, "Silverbound Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39343, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207482;
INSERT INTO gameobject_template VALUES 
(207482, 3, 259, "Silverbound Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39344, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207483;
INSERT INTO gameobject_template VALUES 
(207483, 3, 259, "Silverbound Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39345, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207490;
INSERT INTO gameobject_template VALUES 
(207490, 3, 10313, "Sturdy Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39340, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207491;
INSERT INTO gameobject_template VALUES 
(207491, 3, 10313, "Sturdy Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39341, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207499;
INSERT INTO gameobject_template VALUES 
(207499, 3, 10314, "Dark Iron Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39337, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207501;
INSERT INTO gameobject_template VALUES 
(207501, 3, 10314, "Dark Iron Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39339, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207502;
INSERT INTO gameobject_template VALUES 
(207502, 3, 10314, "Dark Iron Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39340, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207503;
INSERT INTO gameobject_template VALUES 
(207503, 3, 10314, "Dark Iron Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39341, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207504;
INSERT INTO gameobject_template VALUES 
(207504, 3, 10314, "Dark Iron Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39342, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=207505;
INSERT INTO gameobject_template VALUES 
(207505, 3, 10314, "Dark Iron Treasure Chest", "", "", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 57, 39343, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", -18019); 

DELETE FROM gameobject_template WHERE entry=208431;
INSERT INTO gameobject_template VALUES 
(208431, 3, 10538, "Cinderweb Egg Sac", "", "Collecting", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 43, 39488, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208442;
INSERT INTO gameobject_template VALUES 
(208442, 3, 414, "Blueroot Vine", "GatherHerbs", "Gathering", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 39495, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24982, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208544;
INSERT INTO gameobject_template VALUES 
(208544, 3, 10568, "Magmolia", "", "Collecting", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1714, 39507, 0, 1, 0, 0, 0, 208543, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208587;
INSERT INTO gameobject_template VALUES 
(208587, 3, 10160, "Obsidium Meteorite", "", "Collecting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 39701, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208590;
INSERT INTO gameobject_template VALUES 
(208590, 3, 8345, "Flame Druid Spellbook", "", "Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1634, 39706, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208672;
INSERT INTO gameobject_template VALUES 
(208672, 3, 10159, "Obsidium Meteorite", "", "Collecting", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 43, 39701, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208803;
INSERT INTO gameobject_template VALUES 
(208803, 3, 10609, "Living Obsidium Chip", "", "Collecting", "", 0, 0, 0.12, 0, 0, 0, 0, 0, 0, 43, 39726, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19676, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208818;
INSERT INTO gameobject_template VALUES 
(208818, 3, 5493, "Blessed Rice Cakes", "", "", "", 0, 0, 1.33, 0, 0, 0, 0, 0, 0, 1691, 39756, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208819;
INSERT INTO gameobject_template VALUES 
(208819, 3, 8159, "Blessed Rice Cakes", "", "", "", 0, 0, 2, 0, 0, 0, 0, 0, 0, 1691, 39756, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208828;
INSERT INTO gameobject_template VALUES 
(208828, 3, 20, "Corpse Worm Mound", "", "Digging", "", 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 259, 39770, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35059, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208831;
INSERT INTO gameobject_template VALUES 
(208831, 3, 261, "Teldrassil Clam", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1691, 39774, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208839;
INSERT INTO gameobject_template VALUES 
(208839, 3, 336, "Cockroach Cabin", "", "Gathering", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 39779, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24982, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208867;
INSERT INTO gameobject_template VALUES 
(208867, 3, 10627, "Shiny Stones", "", "Gathering", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 899, 39787, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24982, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208874;
INSERT INTO gameobject_template VALUES 
(208874, 3, 14, "Fly Covered \"Meat\"", "Interact", "Gathering", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 39791, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24982, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208875;
INSERT INTO gameobject_template VALUES 
(208875, 3, 424, "Mulgore Pine Cone", "", "Gathering", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 259, 39792, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24982, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208876;
INSERT INTO gameobject_template VALUES 
(208876, 3, 2951, "Fly Covered \"Meat\"", "Interact", "Gathering", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 43, 39791, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24982, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=208967;
INSERT INTO gameobject_template VALUES 
(208967, 3, 10684, "Cache of the Fire Lord", "", "", "", 0, 0, 3.5, 0, 0, 0, 0, 0, 0, 1634, 40061, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15211); 

DELETE FROM gameobject_template WHERE entry=209001;
INSERT INTO gameobject_template VALUES 
(209001, 3, 8819, "Fruit Bowl", "", "", "", 0, 0, 0.6, 0, 0, 0, 0, 0, 0, 1691, 24734, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=209033;
INSERT INTO gameobject_template VALUES 
(209033, 3, 10627, "Rhyolite Fragment", "", "Looting", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1691, 39842, 0, 1, 0, 0, 0, 0, 29234, 0, 0, 0, 0, 0, 37733, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=209035;
INSERT INTO gameobject_template VALUES 
(209035, 3, 6835, "Emberstone Fragment", "", "Looting", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 1691, 39843, 0, 1, 0, 0, 0, 0, 29234, 0, 0, 0, 0, 0, 37733, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=209036;
INSERT INTO gameobject_template VALUES 
(209036, 3, 8061, "Pyreshell Fragment", "", "Looting", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 1691, 39844, 0, 1, 0, 0, 0, 0, 29234, 0, 0, 0, 0, 0, 37733, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=209037;
INSERT INTO gameobject_template VALUES 
(209037, 3, 10705, "Obsidian-Flecked Chitin", "", "Looting", "", 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 1691, 39845, 0, 1, 0, 0, 0, 0, 29234, 0, 0, 0, 0, 0, 37733, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=209242;
INSERT INTO gameobject_template VALUES 
(209242, 3, 10740, "Windswept Balloon", "", "Carefully Collecting", "", 0, 0, 1, 0, 0, 0, 0, 0, 0, 1691, 39846, 30, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47358, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=210079;
INSERT INTO gameobject_template VALUES 
(210079, 3, 11056, "Elementium Fragment", "", "", "", 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 1634, 41161, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 85, 0, 0, 0, 0, 1299, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=210221;
INSERT INTO gameobject_template VALUES 
(210221, 3, 11020, "Lesser Cache of the Aspects", "", "", "", 0, 0, 1.5, 0, 0, 0, 0, 0, 0, 1634, 41183, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 85, 0, 0, 0, 0, 1297, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 

DELETE FROM gameobject_template WHERE entry=210222;
INSERT INTO gameobject_template VALUES 
(210222, 3, 11020, "Greater Cache of the Aspects", "", "", "", 0, 0, 2.25, 0, 0, 0, 0, 0, 0, 1634, 41185, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 85, 0, 0, 0, 0, 1291, 0, 0, 0, 0, 0, 0, 0, "", "", 15595); 



