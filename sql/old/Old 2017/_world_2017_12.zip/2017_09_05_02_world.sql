
-- Stormfury Revenant (Normal)
UPDATE quest_template SET QuestGiverPortrait=0 WHERE Id=28826;

