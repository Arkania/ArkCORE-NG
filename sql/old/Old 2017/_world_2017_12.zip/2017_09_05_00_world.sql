
update version set db_version="ArkDB 7.9.26 - 2017-SEP-01 for ArkCORE4 NG"
