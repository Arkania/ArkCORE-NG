
ALTER TABLE `areatrigger_questender`
DROP PRIMARY KEY,
ADD PRIMARY KEY (`id`, `quest`);

