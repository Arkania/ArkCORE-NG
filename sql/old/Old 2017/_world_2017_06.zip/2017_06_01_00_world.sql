
-- fix missing waypoint for Slinky Sharpshiv <Rogue Trainer>

DELETE FROM creature_addon WHERE guid=272093;
INSERT INTO creature_addon VALUES 
(272093, 3239580, 0, 0, 1, 0, 0, 0, 0, "");

DELETE FROM creature_addon WHERE guid=272094;
INSERT INTO creature_addon VALUES 
(272094, 3239580, 0, 0, 1, 0, 0, 0, 0, "");

DELETE FROM creature_addon WHERE guid=272095;
INSERT INTO creature_addon VALUES 
(272095, 3239580, 0, 0, 1, 0, 0, 0, 0, "");

DELETE FROM creature_addon WHERE guid=272096;
INSERT INTO creature_addon VALUES 
(272096, 3239580, 0, 0, 1, 0, 0, 0, 0, "");

DELETE FROM creature_addon WHERE guid=272097;
INSERT INTO creature_addon VALUES 
(272097, 3239580, 0, 0, 1, 0, 0, 0, 0, "");

DELETE FROM creature_addon WHERE guid=272098;
INSERT INTO creature_addon VALUES 
(272098, 3239580, 0, 0, 1, 0, 0, 0, 0, "");

DELETE FROM creature_addon WHERE guid=272099;
INSERT INTO creature_addon VALUES 
(272099, 3239580, 0, 0, 1, 0, 0, 0, 0, "");



