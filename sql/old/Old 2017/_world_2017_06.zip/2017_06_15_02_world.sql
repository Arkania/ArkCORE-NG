
-- fix Deepholm
-- fix quest 26247 Diplomacy First

-- remove the wrong ship
delete from gameobject where id=211105 and guid=400636;


UPDATE creature SET map=747, position_x=5.0923, position_y=20.4243, position_z=-5.201, orientation=4.6539 WHERE guid=242243;

UPDATE creature SET map=747, position_x=-38.9904, position_y=19.7193, position_z=-5.2027, orientation=1.8175 WHERE guid=242244;

UPDATE creature SET map=747, position_x=-55.2278, position_y=-9.6424, position_z=-5.1975, orientation=4.6672 WHERE guid=242245;

UPDATE creature SET map=747, position_x=22.9905, position_y=6.5847, position_z=-5.2167, orientation=1.3266 WHERE guid=242246;

UPDATE creature SET map=747, position_x=44.5399, position_y=-9.4793, position_z=-2.0768, orientation=5.7563 WHERE guid=242247;

UPDATE creature SET map=747, position_x=-24.8589, position_y=-29.0843, position_z=-4.7759, orientation=4.4097 WHERE guid=242248;

UPDATE creature SET map=747, position_x=54.9059, position_y=7.2123, position_z=-2.0546, orientation=3.0013 WHERE guid=242249;

UPDATE creature SET map=747, position_x=17.6023, position_y=-17.73, position_z=-5.1832, orientation=1.0816 WHERE guid=242250;

UPDATE creature SET map=747, position_x=32.9281, position_y=6.904, position_z=9.6099, orientation=4.7551 WHERE guid=242251;

UPDATE creature SET map=747, position_x=23.1065, position_y=-12.3247, position_z=9.6194, orientation=.0647 WHERE guid=242252;

UPDATE creature SET map=747, position_x=48.6462, position_y=-5.9357, position_z=9.2105, orientation=5.8877 WHERE guid=242253;

UPDATE creature SET map=747, position_x=-.0535, position_y=22.4434, position_z=9.64, orientation=.7913 WHERE guid=242254;

UPDATE creature SET map=747, position_x=-45.2493, position_y=18.66, position_z=9.6105, orientation=4.8126 WHERE guid=242255;

UPDATE creature SET map=747, position_x=14.5348, position_y=9.1547, position_z=9.55, orientation=3.228 WHERE guid=242256;

UPDATE creature SET id=40350, map=747, position_x=49.5812, position_y=18.193, position_z=46.161, orientation=3.9444 WHERE guid=242257;

UPDATE creature SET id=40350, map=747, position_x=-21.9116, position_y=57.4225, position_z=25.879, orientation=3.9444 WHERE guid=242258;

UPDATE creature SET id=40350, map=747, position_x=-24.3035, position_y=61.4472, position_z=3.7285, orientation=1.2566 WHERE guid=242259;

UPDATE creature SET id=40350, map=747, position_x=-18.6721, position_y=62.316, position_z=4.2177, orientation=1.2566 WHERE guid=242260;

UPDATE creature SET id=40350, map=747, position_x=-24.6196, position_y=55.3271, position_z=5.0026, orientation=4.7822 WHERE guid=242261;

UPDATE creature SET id=40350, map=747, position_x=50.3677, position_y=1.5935, position_z=42.2482, orientation=3.9444 WHERE guid=242262;

UPDATE creature SET id=40350, map=747, position_x=-17.385, position_y=55.5016, position_z=4.2177, orientation=4.9567 WHERE guid=242263;

UPDATE creature SET id=40350, map=747, position_x=-22.0063, position_y=53.3257, position_z=4.2034, orientation=4.9567 WHERE guid=242264;

UPDATE creature SET id=40350, map=747, position_x=37.0378, position_y=42.3963, position_z=41.9248, orientation=3.9444 WHERE guid=242265;

UPDATE creature SET id=40350, map=747, position_x=-21.9806, position_y=57.688, position_z=9.4194, orientation=3.9444 WHERE guid=242266;

UPDATE creature SET id=40350, map=747, position_x=6.5831, position_y=-26.1589, position_z=-42.1733, orientation=.5411 WHERE guid=242267;

UPDATE creature SET id=40350, map=747, position_x=3.0071, position_y=.6878, position_z=-35.9638, orientation=.5411 WHERE guid=242268;

UPDATE creature SET id=40350, map=747, position_x=-32.2004, position_y=.5743, position_z=13.4672, orientation=.5411 WHERE guid=242269;

UPDATE creature SET map=747, position_x=7.349, position_y=1.0123, position_z=20.6393, orientation=2.1991 WHERE guid=242453;

UPDATE creature SET map=747, position_x=-47.4634, position_y=10.647, position_z=22.5756, orientation=4.9916 WHERE guid=242454;

UPDATE creature SET map=747, position_x=39.3066, position_y=-41.2642, position_z=25.1144, orientation=2.1991 WHERE guid=242455;

UPDATE creature SET map=747, position_x=35.7927, position_y=6.7662, position_z=40.1641, orientation=5.2534 WHERE guid=242458;

UPDATE creature SET map=747, position_x=31.6575, position_y=-7.4624, position_z=23.3631, orientation=1.3614 WHERE guid=242459;

UPDATE creature SET map=747, position_x=18.2789, position_y=-11.4342, position_z=20.4628, orientation=4.3284 WHERE guid=242460;

UPDATE creature SET id=42682, map=747, position_x=-11.369, position_y=8.6558, position_z=20.5166, orientation=.733 WHERE guid=242270;

UPDATE creature SET id=42682, map=747, position_x=-43.7861, position_y=.475, position_z=20.6098, orientation=6.1785 WHERE guid=242271;

UPDATE creature SET id=42682, map=747, position_x=35.1597, position_y=33.2773, position_z=25.1148, orientation=5.5501 WHERE guid=242272;

UPDATE creature SET id=42682, map=747, position_x=3.0285, position_y=18.1254, position_z=20.5377, orientation=5.2534 WHERE guid=242273;

UPDATE creature SET map=747, position_x=-33.6852, position_y=14.858, position_z=20.703, orientation=3.3685 WHERE guid=242325;

UPDATE creature SET id=42681, map=747, position_x=31.942, position_y=1.2246, position_z=23.3718, orientation=4.7648 WHERE guid=242274;

UPDATE creature SET id=42681, map=747, position_x=-58.6095, position_y=-.0956, position_z=23.5665, orientation=1.3265 WHERE guid=242275;

UPDATE creature SET id=42681, map=747, position_x=-12.8836, position_y=.3604, position_z=25.3638, orientation=5.4629 WHERE guid=242276;

UPDATE creature SET id=42681, map=747, position_x=-13.731, position_y=14.5807, position_z=20.4705, orientation=5.7421 WHERE guid=242277;

UPDATE creature SET id=42681, map=747, position_x=-8.0983, position_y=-10.1304, position_z=20.5101, orientation=4.3284 WHERE guid=242278;

UPDATE creature SET id=42681, map=747, position_x=-62.3053, position_y=4.8, position_z=23.5488, orientation=.4538 WHERE guid=242279;

UPDATE creature SET id=42681, map=747, position_x=4.632, position_y=-13.9708, position_z=20.8881, orientation=1.4137 WHERE guid=242280;

UPDATE creature SET id=42681, map=747, position_x=40.8804, position_y=43.126, position_z=25.1171, orientation=5.044 WHERE guid=242281;

UPDATE creature SET id=42681, map=747, position_x=16.1249, position_y=-3.937, position_z=20.5141, orientation=4.852 WHERE guid=242282;

UPDATE creature SET id=42681, map=747, position_x=38.5457, position_y=-4.7347, position_z=40.167, orientation=5.7421 WHERE guid=242283;

UPDATE creature SET id=42681, map=747, position_x=-36.9719, position_y=-12.3529, position_z=20.5275, orientation=2.0944 WHERE guid=242284;

UPDATE creature SET id=42681, map=747, position_x=35.6438, position_y=22.1494, position_z=25.1158, orientation=5.7421 WHERE guid=242285;

UPDATE creature SET map=747, position_x=48.7156, position_y=11.3266, position_z=40.5068, orientation=3.7874 WHERE guid=242234;

UPDATE creature SET map=747, position_x=28.9031, position_y=7.9286, position_z=23.3699, orientation=3.3859 WHERE guid=242287;

UPDATE creature SET map=747, position_x=28.9662, position_y=7.749, position_z=23.3659, orientation=6.2308, spawndist=0, MovementType=0 WHERE guid=242456;

UPDATE creature SET map=747, position_x=49.7274, position_y=18.2279, position_z=42.5802, orientation=3.8397, spawndist=0, MovementType=0 WHERE guid=242457;

UPDATE creature SET map=747, position_x=-34.1696, position_y=.603, position_z=8.5556, spawndist=0, MovementType=0 WHERE guid=242324;

UPDATE creature SET map=747, position_x=-64.8368, position_y=.0338, position_z=9.904 WHERE guid=242237;

DELETE FROM creature WHERE id=42681 AND guid=42888;
INSERT INTO creature VALUES 
(42888, 42681, 747, 0, 0, 1, 169, 0, 0, 0, 15.77466, 16.16105, 20.59039, 2.076941, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0);

DELETE FROM creature WHERE id=42681 AND guid=42898;
INSERT INTO creature VALUES 
(42898, 42681, 747, 0, 0, 1, 169, 0, 0, 0, 41.02726, -20.22445, 25.11503, 3.420845, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0);

DELETE FROM creature WHERE id=42681 AND guid=42911;
INSERT INTO creature VALUES 
(42911, 42681, 747, 0, 0, 1, 169, 0, 0, 0, 32.83448, -24.09242, 25.11685, 5.742133, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0);

DELETE FROM creature WHERE id=42681 AND guid=42926;
INSERT INTO creature VALUES 
(42926, 42681, 747, 0, 0, 1, 169, 0, 0, 0, -36.3671, 8.293001, 20.53229, 5.462881, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0);

DELETE FROM creature WHERE id=42681 AND guid=42953;
INSERT INTO creature VALUES 
(42953, 42681, 747, 0, 0, 1, 169, 0, 0, 0, -28.55183, -12.62104, 20.55605, 1.22173, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0);

UPDATE gameobject SET map=747, position_x=1.20738, position_y=25.3906, position_z=25.634, orientation=0.9156023, rotation2=-0.9510565, rotation3=0.3090171 WHERE guid=180034;

UPDATE gameobject SET map=747, position_x=44.1827, position_y=6.19141, position_z=10.4048, orientation=0.9156023, rotation2=-0.9510565, rotation3=0.3090171 WHERE guid=180051;

UPDATE gameobject SET map=747, position_x=-6.2442, position_y=-5.59698, position_z=20.4536, orientation=0.6072826, rotation2=-0.9510565, rotation3=0.3090171 WHERE guid=180052;

UPDATE gameobject SET map=747, position_x=-63.1212, position_y=-5.60142, position_z=23.4866, orientation=5.319671, rotation2=0.8910065, rotation3=0.4539906 WHERE guid=167758;

DELETE FROM gameobject WHERE id=204279;
INSERT INTO gameobject VALUES 
(167758, 204279, 747, 0, 0, 1, 169, 0, -63.1212, -5.60142, 23.4866, 5.31967, 0, 0, 0.891007, 0.453991, 300, 100, 1),
(3165, 204279, 747, 0, 0, 1, 169, 0, -22.6119, 16.5843, 20.4029, 5.62799, 0, 0, 0.891007, 0.453991, 300, 100, 1),
(3166, 204279, 747, 0, 0, 1, 169, 0, -37.0487, -3.5828, 20.4435, 5.31967, 0, 0, 0.891007, 0.453991, 300, 100, 1);

delete from gameobject where map=646 and id=180653;

delete from creature where id in (42747, 42757, 43346);




















