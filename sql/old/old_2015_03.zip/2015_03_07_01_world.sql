
update quest_template set OfferRewardText="Anotha newblood, eh?$B$BYa actually look ta be in shape though. Steady hands. Fierce eyes. I may be able ta turn ya into a real $C.$B$BLets not waste anymore time 'den." where Id=24706;
update quest_template set OfferRewardText="Anotha newblood, eh?$B$BYa actually have an intense look about ya though. Fiery eyes. You might have the makings of a real $C.$B$BLets not waste anymore time 'den." where Id=24750;  
update quest_template set OfferRewardText="Anotha newblood, eh?$B$BYa actually have a weathered look about ya though. Wise eyes. You might have the makings of a real $C.$B$BLets not waste anymore time 'den." where Id=24758;
update quest_template set OfferRewardText="Anotha newblood, eh?$B$BYa actually have a wild look about ya though. Fierce eyes. You might have the makings of a real $C.$B$BLets not waste anymore time 'den." where Id=24764;
update quest_template set OfferRewardText="Anotha newblood, eh?$B$BYa actually have a sly look about ya though. Fierce eyes. You might have the makings of a real $C.$B$BLets not waste anymore time 'den." where Id=24770;
update quest_template set OfferRewardText="Anotha newblood, eh?$B$BYa actually have a balanced look about ya though. Calm eyes. You might have the makings of a real $C.$B$BLets not waste anymore time 'den." where Id=24782;
update quest_template set OfferRewardText="Anotha newblood, eh?$B$BYa actually have an intense look about ya though. Fiery eyes. You might have the makings of a real $C.$B$BLets not waste anymore time 'den." where Id=26272;

update quest_template set OfferRewardText="Not bad, mon. Ya have a natural flow to ya swings - you may have a talent for dis.$B$BSome rough edges ta be sure, but we'll get dose ironed out here and I'll teach ya a few new tings as we go." where Id=24239;
update quest_template set OfferRewardText="Not bad, mon. Ya have a natural flow to ya spells - you may have a talent for dis.$B$BSome rough edges ta be sure, but we'll get dose ironed out here and I'll teach ya a few new tings as we go." where Id=24751;
update quest_template set OfferRewardText="Not bad, mon. Ya have a natural flow to ya spells - you may have a talent for dis.$B$BSome rough edges ta be sure, but we'll get dose ironed out here and I'll teach ya a few new tings as we go." where Id=24759;
update quest_template set OfferRewardText="Not bad, mon. Ya have a natural flow to ya casts - you may have a talent for dis.$B$BSome rough edges ta be sure, but we'll get dose ironed out here and I'll teach ya a few new tings as we go." where Id=24765;
update quest_template set OfferRewardText="Not bad, mon. Ya have a natural flow to ya swings - you may have a talent for dis.$B$BSome rough edges ta be sure, but we'll get dose ironed out here and I'll teach ya a few new tings as we go." where Id=24771;
update quest_template set OfferRewardText="Not bad, mon. Ya have a natural flow to ya spells - you may have a talent for dis.$B$BSome rough edges ta be sure, but we'll get dose ironed out here and I'll teach ya a few new tings as we go." where Id=24783;
update quest_template set OfferRewardText="Not bad, mon. Ya have a deep power in ya spells - you may have a talent for dis.$B$BSome rough edges ta be sure, but we'll get dose ironed out here and I'll teach ya a few new tings as we go." where Id=26273;

update quest_template set OfferRewardText="Dese are some fine pelts, $G boy:girl;. We could make some hefty cloaks outta dese.", RequestItemsText="I doubt dey too much of a challenge, mon, but they'll still claw up ya ankles if ya don't stay quick footed. " where Id=24641;
update quest_template set OfferRewardText="Dese are some fine pelts, $G boy:girl;. We could make some hefty cloaks outta dese.", RequestItemsText="I doubt dey too much of a challenge, mon, but they'll still claw up ya ankles if ya don't stay quick footed. " where Id=24753;
update quest_template set OfferRewardText="Dese are some fine pelts, $G boy:girl;. We could make some hefty cloaks outta dese.", RequestItemsText="I doubt dey too much of a challenge, mon, but they'll still claw up ya ankles if ya don't stay quick footed. " where Id=24761;
update quest_template set OfferRewardText="Dese are some fine pelts, $G boy:girl;. We could make some hefty cloaks outta dese.", RequestItemsText="I doubt dey too much of a challenge, mon, but they'll still claw up ya ankles if ya don't stay quick footed." where Id=24767;
update quest_template set OfferRewardText="Dese are some fine pelts, $G boy:girl;. We could make some hefty cloaks outta dese.", RequestItemsText="I doubt dey too much of a challenge, mon, but they'll still claw up ya ankles if ya don't stay quick footed." where Id=24773;
update quest_template set OfferRewardText="Dese are some fine pelts, $G boy:girl;. We could make some hefty cloaks outta dese.", RequestItemsText="I doubt dey too much of a challenge, mon, but they'll still claw up ya ankles if ya don't stay quick footed." where Id=24785;
update quest_template set OfferRewardText="Dese are some fine pelts, $G boy:girl;. We could make some hefty cloaks outta dese.", RequestItemsText="I doubt dey too much of a challenge, mon, but they'll still claw up ya ankles if ya don't stay quick footed." where Id=26275;

update quest_template set OfferRewardText="Ya handle yerself quite well. Ya gonna be quite powerful some day." where Id=24642;
update quest_template set OfferRewardText="Ya handle yerself quite well. Ya gonna be quite powerful some day." where Id=24754;
update quest_template set OfferRewardText="Ya handle yerself quite well. Ya gonna be quite powerful some day." where Id=24762;
update quest_template set OfferRewardText="Ya handle yerself quite well. Ya gonna be quite powerful some day." where Id=24768;
update quest_template set OfferRewardText="Ya handle yerself quite well. Ya gonna be quite powerful some day." where Id=24774;
update quest_template set OfferRewardText="Ya handle yerself quite well. Ya gonna be quite powerful some day." where Id=24786;
update quest_template set OfferRewardText="Ya handle yerself quite well. Ya gonna be quite powerful some day." where Id=26276;

update quest_template set OfferRewardText="Good work, mon! Dis stuff come easy to ya." where Id=24640;
update quest_template set OfferRewardText="Good work, mon! Dis stuff come easy to ya." where Id=24752;
update quest_template set OfferRewardText="Good work, mon! Dis stuff come easy to ya." where Id=24760;
update quest_template set OfferRewardText="Good work, mon! Dis stuff come easy to ya." where Id=24766;
update quest_template set OfferRewardText="Good work, mon! Dis stuff come easy to ya." where Id=24772;
update quest_template set OfferRewardText="Good work, mon! Dis stuff come easy to ya." where Id=24784;
update quest_template set OfferRewardText="Good work, mon! Dis stuff come easy to ya." where Id=26274;

update quest_template set OfferRewardText="Ya tha new recruit everyone's talkin' about, eh? Welcome ta tha Darkspear." where Id=24643;
update quest_template set OfferRewardText="Ya tha new recruit everyone's talkin' about, eh? Welcome ta tha Darkspear." where Id=24755;
update quest_template set OfferRewardText="Ya tha new recruit everyone's talkin' about, eh? Welcome ta tha Darkspear." where Id=24763;
update quest_template set OfferRewardText="Ya tha new recruit everyone's talkin' about, eh? Welcome ta tha Darkspear." where Id=24769;
update quest_template set OfferRewardText="Ya tha new recruit everyone's talkin' about, eh? Welcome ta tha Darkspear." where Id=24775;
update quest_template set OfferRewardText="Ya tha new recruit everyone's talkin' about, eh? Welcome ta tha Darkspear." where Id=24787;
update quest_template set OfferRewardText="Ya tha new recruit everyone's talkin' about, eh? Welcome ta tha Darkspear." where Id=26274;



















