
delete from spell_script_names where spell_id=72116;
insert into spell_script_names values 
(72116, "spell_shoot_liam_72116");

