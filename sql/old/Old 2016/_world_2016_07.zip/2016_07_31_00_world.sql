
delete from creature_equip_template where entry=42141 and id=1;
insert into creature_equip_template values 
(42141, 1, 10612, 11019, 0);

delete from creature where map=749;

delete from creature where id=43791;

delete from creature_equip_template where entry=43566 and id=1;
insert into creature_equip_template values 
(43566, 1, 52528, 52528, 52052);


