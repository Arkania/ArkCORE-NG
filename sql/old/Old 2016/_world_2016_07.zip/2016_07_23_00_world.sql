
delete from creature where id=2548 and guid=58932;

UPDATE locales_quest SET Title_loc3="Dämonen in der Zitadelle", Objectives_loc3="Tötet Omor den Narbenlosen und bringt seinen Huf zu Vorhutsspäher Chadwick.", Details_loc3="Einer unserer Späher berichtet, er habe irgendwo im Bollwerk einen Agenten der Brennenden Legion gesehen. Wenn das stimmt, laufen wir Gefahr, dass die Ehrenfeste von zwei Seiten angegriffen wird!$B$BWenn Ihr diesen Teufel findet, dann bringt ihn um.", OfferRewardText_loc3="Dann ist es also wahr. Die Höllenorcs und die Brennende Legion arbeiten auf irgendeine Weise zusammen.", RequestItemsText_loc3="Habt Ihr dort drinnen Dämonen entdeckt?", CompletedText_loc3="Kehrt zu Vorhutsspäher Chadwick im Höllenfeuerbollwerk zurück." WHERE Id=29529;


