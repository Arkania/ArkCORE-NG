

update creature set spawndist=5, MovementType=1 where id=37786;

UPDATE locales_quest SET CompletedText_loc3="Kehrt zu Lorna Crowley an der Pferdewechselstation zurück." WHERE Id=24676;

DELETE FROM creature WHERE id=37694;
INSERT INTO creature VALUES 
(11769, 37694, 654, 1, 131072, 0, 1, -1186.89, 1056.82, 36.5959, 0.162504, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(12828, 37694, 654, 1, 131072, 0, 1, -1168.19, 1025.52, 44.1099, 1.93357, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(12842, 37694, 654, 1, 131072, 0, 1, -1148.06, 1026.14, 43.1266, 0.951819, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(12929, 37694, 654, 1, 131072, 0, 1, -1093.75, 990.254, 46.3326, 5.30684, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(12935, 37694, 654, 1, 131072, 0, 1, -1074.54, 941.435, 40.3701, 0.299929, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13023, 37694, 654, 1, 131072, 0, 1, -1056.73, 928.564, 41.3563, 4.89844, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13298, 37694, 654, 1, 131072, 0, 1, -1187, 871.539, 23.454, 0.679256, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13299, 37694, 654, 1, 131072, 0, 1, -1171.35, 870.151, 23.5801, 2.99619, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24527, 37694, 654, 1, 131072, 0, 1, -1063.12, 849.325, 36.485, 4.82223, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13319, 37694, 654, 1, 131072, 0, 1, -1111.47, 931.023, 40.6145, 5.52516, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13358, 37694, 654, 1, 131072, 0, 1, -1139.83, 955.963, 41.4392, 1.94767, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13651, 37694, 654, 1, 131072, 0, 1, -1052.01, 964.368, 44.9263, 6.15033, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13652, 37694, 654, 1, 131072, 0, 1, -1018.42, 996.065, 40.508, 0.06742, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13653, 37694, 654, 1, 131072, 0, 1, -1083.37, 906.908, 37.2065, 3.52712, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(13662, 37694, 654, 1, 131072, 0, 1, -1095.49, 835.184, 36.5694, 4.31644, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24501, 37694, 654, 1, 131072, 0, 1, -1019.08, 998.416, 41.0556, 5.85549, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24503, 37694, 654, 1, 131072, 0, 1, -1016.77, 981.136, 39.34, 4.15118, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24528, 37694, 654, 1, 131072, 0, 1, -1052.76, 936.901, 44.0279, 5.20124, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24530, 37694, 654, 1, 131072, 0, 1, -1069.6, 874.684, 36.2062, 5.08343, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24533, 37694, 654, 1, 131072, 0, 1, -1142.55, 909.74, 23.8047, 2.98249, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24534, 37694, 654, 1, 131072, 0, 1, -1149.84, 898.92, 23.0663, 3.70113, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24535, 37694, 654, 1, 131072, 0, 1, -1133.06, 852.951, 31.2773, 5.26407, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24536, 37694, 654, 1, 131072, 0, 1, -1182.98, 917.642, 22.8266, 2.67226, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24537, 37694, 654, 1, 131072, 0, 1, -1167.73, 920.708, 22.6695, 6.05732, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24538, 37694, 654, 1, 131072, 0, 1, -1214.88, 898.522, 23.5093, 0.143271, 500, 0, 0, 198, 0, 0, 0, 0, 0), 
(24539, 37694, 654, 1, 131072, 0, 1, -1176.6, 875.502, 23.0494, 4.18022, 500, 0, 0, 198, 0, 0, 0, 0, 0),
(24498, 37694, 654, 1, 131072, 0, 1, -1184.72, 951.238, 28.4192, 2.45111, 500, 0, 0, 198, 0, 0, 0, 0, 0);

SET @GUID=252644;

UPDATE creature SET spawndist=0, MovementType = 2 WHERE guid=@GUID;

INSERT IGNORE INTO creature_addon (guid) VALUE (@GUID);
UPDATE creature_addon SET path_id=@GUID WHERE guid=@GUID;

DELETE FROM waypoint_data WHERE id=@GUID;
INSERT INTO waypoint_data (id, point, position_x, position_y, position_z, orientation, delay, move_flag) values
(@GUID, 0, -1374.993, 1216.394, 35.55814, 4.984017, 0, 0),
(@GUID, 1, -1362.234, 1204.265, 35.53145, 5.494526, 0, 0),
(@GUID, 2, -1360.137, 1203.539, 35.40595, 5.985396, 5000, 0),
(@GUID, 3, -1362.792, 1205.249, 35.53916, 2.612113, 0, 0),
(@GUID, 4, -1374.572, 1216.225, 35.55812, 2.376494, 0, 0),
(@GUID, 5, -1375.303, 1225.966, 35.55812, 1.618584, 0, 0),
(@GUID, 6, -1367.401, 1236.093, 36.0089, 0.974558, 5000, 0),
(@GUID, 7, -1374.282, 1225.1, 35.55484, 4.175059, 0, 0);

UPDATE creature_template SET ScriptName="npc_lorna_crowley_37783" WHERE entry=37783;

DELETE FROM creature_text WHERE entry=37803 AND groupid=1 AND id=0;
INSERT INTO creature_text VALUES 
(37803, 1, 0, "This is our land -- they're not going to take it away without a fight!", 12, 0, 100, 1, 0, 0, "marcus", 37399);

UPDATE creature_template SET ScriptName="npc_marcus_37803" WHERE entry=37803;

delete from gossip_menu_option where menu_id=11061;
INSERT INTO `gossip_menu_option` VALUES 
(11061, 0, 0, 'Let us take back our city!', 38484, 1, 1, 0, 0, 0, 0, 0, '', 0),
(11061, 1, 0, 'The Battle for Gilneas City is underway!  You can head to the frontlines or wait until our men regroup for the next attack.', 38798, 1, 1, 0, 0, 0, 0, 0, NULL, 0);

UPDATE creature_template SET gossip_menu_id=0 WHERE entry=38553;

UPDATE creature SET phaseMask=262144 WHERE guid=251640;

UPDATE creature SET phaseMask=262144 WHERE guid=251663;

UPDATE creature SET phaseMask=262144 WHERE guid=251762;

delete from creature where id=38465 and guid=251606;

UPDATE gameobject SET phaseMask=8257536, state=0 WHERE guid=166772;
UPDATE gameobject SET phaseMask=65535, state=1 WHERE guid=401069;

delete from creature_equip_template where id=1 and entry in (36797, 36798, 38794, 38795, 38796, 38797, 38798, 38799);
insert into creature_equip_template values 
(36797, 1, 0, 0, 2552),
(36798, 1, 0, 0, 2552),
(38794, 1, 1908, 0, 0),
(38795, 1, 5276, 0, 0),
(38796, 1, 2184, 0, 0),
(38797, 1, 2559, 0, 0),
(38798, 1, 0, 0, 2552),
(38799, 1, 1908, 0, 0);

delete from areatrigger_scripts where entry=5605;
insert areatrigger_scripts values 
(5605, "at_hor_shadow_throne");

delete from creature_text where entry=38553 and groupid=1 and id=0;
insert into creature_text values 
(38553, 1, 0, "The Battle for Gilneas City is underway!  You can head to the frontlines or wait until our men regroup for the next attack.", 12, 0, 100, 0, 0, 0, "", 38798);

UPDATE creature_template SET AIName="", ScriptName="npc_prince_liam_greymane_38218" WHERE entry=38218;

UPDATE creature_template SET ScriptName="npc_sister_almyra_38466" WHERE entry=38466;

UPDATE creature_template SET ScriptName="npc_myriam_spellwaker_38465" WHERE entry=38465;

delete from creature where id=38218 and guid=251663;

DELETE FROM creature WHERE guid=251663;
INSERT INTO creature VALUES 
(251663, 38218, 654, 1, 262144, 30502, 0, -1408.661, 1260.017, 36.51123, 1.79, 300, 0, 0, 1116, 191, 0, 0, 0, 0);

delete from phase_definitions where entry=2 and phasemask=262144 and zoneid in (4714, 4755);
INSERT INTO `phase_definitions` VALUES (4714, 2, 262144, 0, 656, 679, 1, 'Fight for gilneas');
INSERT INTO `phase_definitions` VALUES (4755, 2, 262144, 0, 656, 679, 1, 'Fight for gilneas');

UPDATE gameobject_template SET flags=32 WHERE entry=195578;

delete from creature where id in (38424, 38420, 38464, 38331, 38469, 38470, 38473, 38425, 38221, 38415, 38348, 38426, 38467);

delete from creature where map=654 and id=44388 and guid>100000;

update creature set map=654 where map=0 and id=44388;

delete from smart_scripts where entryorguid=38218;





