
delete from spell_script_names where spell_id=72247;
insert into spell_script_names values 
(72247, "spell_iron_bomb_72247");

