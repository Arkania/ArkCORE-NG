
-- console error 

delete from smart_scripts where entryorguid=27693;

update creature_template set AIName="" where entry=27693;

update creature_addon set path_id=0 where guid=225068;

