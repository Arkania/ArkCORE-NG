
DELETE FROM `gameobject_template` WHERE `entry` IN (181290);
INSERT INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `IconName`, `castBarCaption`, `unk1`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `AIName`, `ScriptName`, `WDBVerified`) VALUES
(181290,6,0,'Midsummer Bonfire Spawn Trap','','','',0,0,1,0,0,0,28784,0,0,-1,0,0,0,0,0,0,'','',0);

