

-- insert locale text for npc 9559
update locales_creature_text set text_loc3="Kommt schon! Nehmt die 'Launische Minna' nach Kalimdor!" where entry=9559 and groupid=0 and id=0;
update locales_creature_text set text_loc3="Bewegt Euren Hintern oder Ihr verpasst das Schiff!" where entry=9559 and groupid=0 and id=1;
update locales_creature_text set text_loc3="Dumme Trolle! Wir nehmen nur Gold, wenn Ihr kein Gold habt, dann verschwindet!" where entry=9559 and groupid=0 and id=2;

