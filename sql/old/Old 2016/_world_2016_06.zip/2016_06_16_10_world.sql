
UPDATE creature SET position_x=9.7581, position_y=-7.8181, position_z=-16.679, orientation=0.01 WHERE guid=277844;

delete from npc_spellclick_spells where npc_entry=29460 and spell_id=54513;

