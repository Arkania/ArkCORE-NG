

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Gut gemacht, $N! Ganz ehrlich, goldene Steinfische bekommt man nur schwer. Das ist ein besonderer Leckerbissen.", RequestItemsText_loc3="Wie ist es da unten gelaufen? Hattet Ihr Glück mit den Schwänzen und den Steinfischen?", CompletedText_loc3="Liefert den goldenen Steinfisch bei Razgar in Orgrimmar ab." WHERE Id=26572;

