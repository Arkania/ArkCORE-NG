
-- fix issue #91
update gossip_menu_option set option_id=4, npc_option_npcflag=8192 where menu_id=13048;

