

update creature_template set Health_mod=1 where entry=43228;

