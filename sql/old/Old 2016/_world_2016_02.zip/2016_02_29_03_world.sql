
-- fix issue #94
delete from spell_script_names where spell_id=46374;
insert into spell_script_names values
(46374, "spell_windsoul_totem_aura");

