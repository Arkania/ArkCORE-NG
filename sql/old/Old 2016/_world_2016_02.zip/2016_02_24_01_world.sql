
-- fix issue #85

update creature_template set gossip_menu_id=4822 where entry=2485;

update creature_template set gossip_menu_id=4826 where entry=5958;

update creature_template set gossip_menu_id=9581 where entry=27703;

update creature_template set gossip_menu_id=11972 where entry=45139;

update creature_template set gossip_menu_id=12235 where entry=47253;

