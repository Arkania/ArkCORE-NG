

UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Kehrt zu Priesterin Dentaria in Lor'danel zurück." WHERE Id=13518;

