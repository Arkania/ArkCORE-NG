
-- fix issue #77
delete from gameobject where guid=400802 and id=600074;


