

delete from spell_script_names where spell_id=80962;
insert into spell_script_names values
(80962, "spell_kill_golden_stonefish_80962");


