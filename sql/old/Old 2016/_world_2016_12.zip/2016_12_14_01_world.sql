
update arkcore_string set content_default="Selected object:\n|cffffffff|Hgameobject:%d|h[%s]|h|r GUID: %u ID: %u\nX: %f Y: %f Z: %f MapId: %u\nOrientation: %f\nPhases: %u (%u)" where entry=524;

update arkcore_string set content_loc3="Ausgewähltes Objekt:\n|cffffffff|Hgameobject:%d|h[%s]|h|r GUID: %u ID: %u\nX: %f Y: %f Z: %f MapId: %u\nOrientierung: %f\nPhases: %u (%u)" where entry=524;

