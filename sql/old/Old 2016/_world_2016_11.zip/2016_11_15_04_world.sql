

update creature set phaseIds="", phaseGroup=429 where id in (38526, 38531);

UPDATE gameobject SET phaseIds="181" WHERE guid=168962;

UPDATE gameobject SET phaseIds="181" WHERE guid=168958;

UPDATE gameobject SET phaseIds="181" WHERE guid=168959;

UPDATE gameobject SET phaseIds="181" WHERE guid=168993;

UPDATE gameobject SET phaseIds="181" WHERE guid=168948;

UPDATE gameobject SET phaseIds="181" WHERE guid=168932;

UPDATE gameobject SET phaseIds="181" WHERE guid=168947;

UPDATE gameobject SET phaseIds="181" WHERE guid=168930;

UPDATE gameobject SET phaseIds="181" WHERE guid=168994;

update gameobject set phaseIds="", phaseGroup=443 where map=648 and id=1619;

update gameobject set phaseIds="", phaseGroup=443 where map=648 and id=1731;

UPDATE creature_template SET ScriptName="npc_bc_eliminator_38526" WHERE entry=38526;

UPDATE creature_template SET ScriptName="npc_oomlot_warrior_38531" WHERE entry=38531;

update creature set spawndist=0, MovementType=2 where guid=37194;

