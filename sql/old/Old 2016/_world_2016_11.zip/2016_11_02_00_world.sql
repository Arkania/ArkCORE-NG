
delete from phase_definitions where zoneId in (1519, 1637);