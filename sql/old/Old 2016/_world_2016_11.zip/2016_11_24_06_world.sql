
update creature set phaseIds=0, phaseGroup=368 where phaseIds="169 170 171"; 
update creature set phaseIds=0, phaseGroup=370 where phaseIds="169 177"; 
update creature set phaseIds=0, phaseGroup=371 where phaseIds="169 170"; 
update creature set phaseIds=0, phaseGroup=375 where phaseIds="169 176"; 
update creature set phaseIds=0, phaseGroup=383 where phaseIds="169 172"; 
update creature set phaseIds=0, phaseGroup=392 where phaseIds="170 172"; 
update creature set phaseIds=0, phaseGroup=407 where phaseIds="170 171"; 
update creature set phaseIds=0, phaseGroup=415 where phaseIds="180 181 182"; 
update creature set phaseIds=0, phaseGroup=419 where phaseIds="170 171 172"; 
update creature set phaseIds=0, phaseGroup=420 where phaseIds="170 171 172 179 180"; 
update creature set phaseIds=0, phaseGroup=430 where phaseIds="170 171 172 179"; 
update creature set phaseIds=0, phaseGroup=431 where phaseIds="181 182 183"; 
update creature set phaseIds=0, phaseGroup=431 where phaseIds="183 184 185 186"; 
update creature set phaseIds=0, phaseGroup=433 where phaseIds="181 182 183 184"; 
update creature set phaseIds=0, phaseGroup=402 where phaseIds="169 170 171 175";
update creature set phaseIds=0, phaseGroup=408 where phaseIds="171 175";
update creature set phaseIds=0, phaseGroup=403 where phaseIds="176 177";
update creature set phaseIds=0, phaseGroup=389 where phaseIds="169 170 171 175 176";
update creature set phaseIds=0, phaseGroup=460 where phaseIds="172 179";
update creature set phaseIds=0, phaseGroup=385 where phaseIds="169 170 171 172 173 174 175 176 177 178 179 180 181 182 183 184"; 
update creature set phaseIds=0, phaseGroup=385 where phaseIds="170 171 172 173 174 175 176 177 178 179 180 181 182 183 184"; 
update creature set phaseIds=0, phaseGroup=385 where phaseIds="169 176 177 178 179 180"; 
update creature set phaseIds=0, phaseGroup=385 where phaseIds="169 170 171 181 182 183"; 
update creature set phaseIds=0, phaseGroup=412 where phaseIds="169 170 171 172 173 174 175 176 177 179 180 181 182 183 184 185 186 187 188 189 190"; 
update creature set phaseIds=0, phaseGroup=443 where phaseIds="170 171 172 179 180 181 182 183";

