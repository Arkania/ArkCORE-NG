
update gameobject set phaseIds=0, phaseGroup=385 where phaseIds="169 170 171 172 173 174 175 176 177 178 179 180 181 182 183 184"; 
update gameobject set phaseIds=0, phaseGroup=381 where phaseIds="169 170 174"; 
update gameobject set phaseIds=0, phaseGroup=383 where phaseIds="169 172"; 
update gameobject set phaseIds=0, phaseGroup=381 where phaseIds="169 170"; 
update gameobject set phaseIds=0, phaseGroup=369 where phaseIds="175 176"; 
update gameobject set phaseIds=0, phaseGroup=396 where phaseIds="169 171"; 
update gameobject set phaseIds=0, phaseGroup=491 where phaseIds="169 176 177"; 
update gameobject set phaseIds=0, phaseGroup=431 where phaseIds="181 182 183"; 
update gameobject set phaseIds=0, phaseGroup=446 where phaseIds="169 170 171 172 179"; 
update gameobject set phaseIds=0, phaseGroup=430 where phaseIds="170 171 172 179"; 
update gameobject set phaseIds=0, phaseGroup=468 where phaseIds="169 176 177 178 179 180"; 
update gameobject set phaseIds=0, phaseGroup=379 where phaseIds="169 170 171 172"; 
update gameobject set phaseIds=0, phaseGroup=403 where phaseIds="176 177"; 
update gameobject set phaseIds=0, phaseGroup=407 where phaseIds="170 171"; 
update gameobject set phaseIds=0, phaseGroup=412 where phaseIds="169 170 171 172 173 174 175 176 177 178 179 180 181 182 183 184 185 186 187 188 189 190 191 192 193 194 195 196 197 198 199"; 



