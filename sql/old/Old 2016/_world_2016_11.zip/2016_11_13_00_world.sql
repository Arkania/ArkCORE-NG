

UPDATE creature_template SET ScriptName="npc_foreman_dampwick_36470" WHERE entry=36470;

UPDATE creature_template SET unit_flags2=0, dynamicflags=0, ScriptName="npc_foreman_dampwick_36471" WHERE entry=36471;

UPDATE creature_template SET unit_flags2=0, ScriptName="npc_hobart_grapplehammer_38120" WHERE entry=38120;

UPDATE creature_template SET unit_flags2=0, ScriptName="npc_bamm_megabomb_38122" WHERE entry=38122;

update creature_template set npcflag=16777216 where entry=38111;

