
DELETE FROM creature WHERE guid=2002;
INSERT INTO creature VALUES 
(2002, 39117, 0, 0, 0, 1, "169", 0, 31313, 0, 2242.28, 230.375, 34.5098, 0.383972, 90, 0, 0, 404, 456, 0, 0, 0, 0);

UPDATE quest_template SET RequiredNpcOrGo1=1675, RequiredNpcOrGo3=0, RequiredNpcOrGoCount1=5, RequiredNpcOrGoCount3=0, RequiredItemId1=2834, RequiredItemId4=0, RequiredItemCount1=6, RequiredItemCount4=0 WHERE Id=24997;


