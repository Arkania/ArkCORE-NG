
ALTER TABLE `creature`
CHANGE COLUMN `phaseId` `phaseIds`  text NOT NULL AFTER `phaseMask`;

