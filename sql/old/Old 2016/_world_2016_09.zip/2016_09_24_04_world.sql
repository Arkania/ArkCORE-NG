

DELETE FROM creature_text WHERE entry=35175;
INSERT INTO creature_text VALUES 
(35175, 1, 0, "I could really use a refill on my drink here.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40222),
(35175, 6, 0, "A fresh glass of bubbly. Just what the doctor ordered, $N.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35417),
(35175, 6, 1, "Thanks for the refill, $G sir : ma'am;!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35418),
(35175, 6, 2, "This sparkling white wine is delicious! Wherever did you get it?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35419),
(35175, 6, 3, "I think this one will have to be my last. I'm driving home after the party.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35420),

(35175, 2, 0, "Ugh... I need a bucket!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40223),
(35175, 7, 0, "Thanksh!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35421),
(35175, 7, 1, "I feel much better now...hic!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35422),
(35175, 7, 2, "Oh, my head hurtsh.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35423),
(35175, 7, 3, "Shorry about your shoes.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35424),

(35175, 3, 0, "If only I had someone to dance with.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40224),
(35175, 8, 0, "A disco ball?! Groovy!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35425),
(35175, 8, 1, "How do you like my moves, $N?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35426),
(35175, 8, 2, "We should totally have a pants-off dance-off!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35427),
(35175, 8, 3, "Shake it like a goblinoid picture!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35428),

(35175, 4, 0, "I love fireworks!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40225),
(35175, 9, 1, "Wow! That sure beats this puny, little sparkler!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35429),
(35175, 9, 2, "You really stop at no expense, $N! Amazing!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35430),
(35175, 9, 3, "Best... Party... Evar!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35431),
(35175, 9, 4, "Woo hoo, fireworks! More, more!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35432),

(35175, 5, 0, "This is delicious! Are there more hors d'oeuvres?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40226),
(35175, 10, 0, "Thanks. I was almost out. So hungry!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35433),
(35175, 10, 1, "These are the most delicious hors d'oeurves I have ever tasted. You must share your recipe, $N!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35434),
(35175, 10, 2, "Finger licking good!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35435),
(35175, 10, 3, "Nom, nom, nom!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35436);

DELETE FROM creature_text WHERE entry=35186;
INSERT INTO creature_text VALUES 
(35186, 1, 0, "I could really use a refill on my drink here.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40222),
(35186, 6, 0, "A fresh glass of bubbly. Just what the doctor ordered, $N.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35417),
(35186, 6, 1, "Thanks for the refill, $G sir : ma'am;!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35418),
(35186, 6, 2, "This sparkling white wine is delicious! Wherever did you get it?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35419),
(35186, 6, 3, "I think this one will have to be my last. I'm driving home after the party.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35420),

(35186, 2, 0, "Ugh... I need a bucket!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40223),
(35186, 7, 0, "Thanksh!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35421),
(35186, 7, 1, "I feel much better now...hic!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35422),
(35186, 7, 2, "Oh, my head hurtsh.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35423),
(35186, 7, 3, "Shorry about your shoes.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35424),

(35186, 3, 0, "If only I had someone to dance with.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40224),
(35186, 8, 0, "A disco ball?! Groovy!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35425),
(35186, 8, 1, "How do you like my moves, $N?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35426),
(35186, 8, 2, "We should totally have a pants-off dance-off!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35427),
(35186, 8, 3, "Shake it like a goblinoid picture!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35428),

(35186, 4, 0, "I love fireworks!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40225),
(35186, 9, 1, "Wow! That sure beats this puny, little sparkler!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35429),
(35186, 9, 2, "You really stop at no expense, $N! Amazing!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35430),
(35186, 9, 3, "Best... Party... Evar!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35431),
(35186, 9, 4, "Woo hoo, fireworks! More, more!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35432),

(35186, 5, 0, "This is delicious! Are there more hors d'oeuvres?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 40226),
(35186, 10, 0, "Thanks. I was almost out. So hungry!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35433),
(35186, 10, 1, "These are the most delicious hors d'oeurves I have ever tasted. You must share your recipe, $N!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35434),
(35186, 10, 2, "Finger licking good!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35435),
(35186, 10, 3, "Nom, nom, nom!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35436);

