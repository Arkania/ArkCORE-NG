
ALTER TABLE `gameobject`
CHANGE COLUMN `phaseId` `phaseIds`  text NOT NULL AFTER `phaseMask`;

