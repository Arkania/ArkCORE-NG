
ALTER TABLE `gameobject`
DROP COLUMN `phaseMask`;


