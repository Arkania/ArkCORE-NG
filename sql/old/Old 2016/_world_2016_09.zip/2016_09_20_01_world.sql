
update arkcore_string set content_default= "│ PhaseIds: %s" where entry=846;

update arkcore_string set content_loc3="│ Level: %u (%u/%u XP (%u XP fehlen))" where entry=843;
update arkcore_string set content_loc3="│ Geschlecht: %s | Rasse: %s | Klasse: %s" where entry=844;
update arkcore_string set content_loc3="│ Am Leben: %s" where entry=845;
update arkcore_string set content_loc3="│ PhaseIds: %s" where entry=846;
update arkcore_string set content_loc3="│ Geld: %ug%us%uc" where entry=847;
update arkcore_string set content_loc3="│ Karte: %s, Bereich: %s, Zone: %s" where entry=848;
update arkcore_string set content_loc3="│ Gilde: %s (ID: %u)" where entry=849;
update arkcore_string set content_loc3="├─Rang: %s" where entry=850;
update arkcore_string set content_loc3="├─Notiz: %s" where entry=851;
update arkcore_string set content_loc3="├─O. Notiz: %s" where entry=852;
update arkcore_string set content_loc3="│ Spielzeit: %s" where entry=853;
update arkcore_string set content_loc3="└ Mails: %d Read/%I64u Total" where entry=854;
update arkcore_string set content_loc3="Männlich" where entry=855;
 
update arkcore_string set content_loc3="│ Level: %u)" where entry=871;

update arkcore_string set content_loc3="│ Registrations Email: %s - Email: %s" where entry=879;

update arkcore_string set content_loc3="Öffnen folgender Datei fehlgeschlagen: %s" where entry=1112;

update arkcore_string set content_loc3="Dump file enthält fehlerhafte Daten!" where entry=1114;
update arkcore_string set content_loc3="Ungültiger Charakter Name!" where entry=1115;
update arkcore_string set content_loc3="Ungültige  Charakter Guid!" where entry=1116;
 
update arkcore_string set content_loc3="Ihr müsst 'male' (männlich) oder 'female' (weiblich) als Geschlecht benutzen." where entry=1119;
update arkcore_string set content_loc3="Ihr verändert das Geschlecht von %s auf %s." where entry=1120;
update arkcore_string set content_loc3="Euer Geschlecht wurde auf %s von %s geändert." where entry=1121;

