
ALTER TABLE `phase_definitions`
DROP COLUMN `phasemask`;


