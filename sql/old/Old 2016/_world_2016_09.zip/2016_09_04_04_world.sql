
update creature set phaseMask=0, phaseId=0, phaseGroups='378 379 380 381 382 383 384' where guid=245789 and id=6491;

update creature set phaseMask=0, phaseId=0, phaseGroups='378 379 380 381 382 383 384' where id=7395 and map=648;

update creature set phaseMask=0, phaseId=0, phaseGroups='378 383 384' where id=35063 and map=648;

update creature set phaseMask=0, phaseId=0, phaseGroups='378 383 384' where id=35075 and map=648;

update creature set phaseMask=0, phaseId=0, phaseGroups='378 379 380 382' where id=35239 and map=648;

update creature set phaseMask=0, phaseId=0, phaseGroups='384' where guid=245782 and id=34673;

update creature set phaseMask=0, phaseId=0, phaseGroups='384' where guid=249703 and id=34689; 

update creature set phaseMask=0, phaseId=0, phaseGroups='384' where guid=249704 and id=34695; 

update creature set phaseMask=0, phaseId=0, phaseGroups='384' where guid=249702 and id=34696; 	

update creature set phaseMask=0, phaseId=0, phaseGroups='384' where guid=245278 and id=34874;  

update creature set phaseMask=0, phaseId=0, phaseGroups='384' where guid=13663 and id=35053; 

update creature set phaseMask=0, phaseId=0, phaseGroups='384' where guid=245957 and id=35222;

update creature set phaseMask=0, phaseId=0, phaseGroups='383' where id in (35486, 35609, 35613) and map=648;

-- spawned by script: ELM General Purpose Bunny 
-- 248977	35193
-- 248984	35274
-- 248987	35277

update gameobject set phaseMask=0, phaseId=0, phaseGroups='378 382' where id=188215 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='378 382 383' where id=201798 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='378 382' where id=195492 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='383' where id=195516 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='378' where id=201603 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='382 383 384' where id=201719 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='382 383 384' where id=201720 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='382 383 384' where id=201721 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='384' where id=201768 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='384' where id=201770 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='384' where id=201790 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='384' where id=201791 and map=648;

update gameobject set phaseMask=0, phaseId=0, phaseGroups='378 382' where id=202865 and map=648;

-- spawned by script
-- div 		195492
-- 403804	195523
-- 403810	196838


