
ALTER TABLE `creature`
DROP COLUMN `phaseMask`;

