
DROP TABLE IF EXISTS phase_spell;


