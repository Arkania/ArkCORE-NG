

update creature set phaseMask=0, phaseGroups='380' where id=35200 and map=648;

update creature set phaseMask=0, phaseGroups='379' where id=35175 and map=648;

update creature set phaseMask=0, phaseGroups='379' where id=35186 and map=648;

update creature set phaseMask=0, phaseGroups='378 379 383' where id=40071 and map=648;

update creature set phaseMask=0, phaseGroups='383' where id=35234 and map=648;

update creature set phaseMask=0, phaseGroups='378 379 380 381 382 383 384' where id=2110 and map=648;

update creature set phaseMask=0, phaseGroups='378 379 380 381 382 383 384' where id=34865 and map=648;

update creature set phaseMask=0, phaseGroups='378 383 384' where id=34865 and map=648;

update creature set phaseMask=0, phaseGroups='378 383' where id=48961 and map=648;

update creature set phaseMask=0, phaseGroups='378 383 384' where id=49131 and map=648;

update creature set phaseMask=0, phaseGroups='383 384' where id=35294 and map=648;

update creature set phaseMask=0, phaseGroups='379' where id=35185 and map=648;

update creature set phaseMask=0, phaseGroups='384' where guid=250085 and id=34668 and map=648;

update creature set phaseMask=0, phaseGroups='384' where id=37683 and map=648;

