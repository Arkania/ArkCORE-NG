
update creature set phaseMask=0, phaseIds='', phaseGroups='379' where id=48721 and map=648;

update creature set phaseIds='' where phaseIds='0';

update gameobject set phaseIds='' where phaseIds='0';

