
-- quest 14070
DELETE FROM creature_text WHERE entry=34835;
INSERT INTO creature_text VALUES 
(34835, 0, 0, "I was just comin' to see you. Honest!", 12, 0, 100, 0, 0, 0, "Bruno Flameretardant Say Start", 48863),
(34835, 1, 0, "Darn, you got me!", 12, 0, 100, 0, 0, 0, "Bruno Flameretardant Say", 35126),
(34835, 2, 0, "Darn, you got me!", 12, 0, 100, 0, 0, 0, "Bruno Flameretardant Say End", 35127),
(34835, 3, 0, "Pay up, Bruno!", 12, 0, 100, 0, 0, 0, "Say to Bruno Flameretardant", 35128);


DELETE FROM creature_text WHERE entry=34876;
INSERT INTO creature_text VALUES 
(34876, 0, 0, "Oh no you didn't!", 12, 0, 100, 0, 0, 0, "Frankie Gearslipper Female Say Start", 48866),
(34876, 1, 0, "What? Fine, fine... I got it, I got it!", 12, 0, 100, 0, 0, 0, "Frankie Gearslipper Female Say ", 35131),
(34876, 2, 0, "What? Fine, fine... I'll pay my protection moolah to your goons!", 12, 0, 100, 0, 0, 0, "Frankie Gearslipper Female Say End", 35129),
(34876, 3, 0, "Hand it over, Frankie!", 12, 0, 100, 0, 0, 0, "Frankie Gearslipper", 35130);

DELETE FROM creature_text WHERE entry=34877;
INSERT INTO creature_text VALUES 
(34877, 0, 0, "<Jack grunts something about the hammer being his weapon... you think.>", 12, 0, 100, 0, 0, 0, "Jack the Hammer Say Start", 48865),
(34877, 1, 0, "<Grunt>", 16, 0, 100, 0, 0, 0, "Jack the Hammer Say", 35133),
(34877, 2, 0, "%s grunts and gives up, clearly beaten.", 16, 0, 100, 0, 0, 0, "Jack the Hammer Say End", 35132),
(34877, 3, 0, "Don't play stupid with me, Jack. I know that you have the moolah!", 12, 0, 100, 0, 0, 0, "Say to Jack the Hammer", 35134);

DELETE FROM creature_text WHERE entry=34878;
INSERT INTO creature_text VALUES 
(34878, 0, 0, "I'm tryin' to run a business here!", 12, 0, 100, 0, 0, 0, "Sudsy Magee Say Start", 48864),
(34878, 1, 0, "Not the face, not the face!", 12, 0, 100, 0, 0, 0, "Sudsy Magee Say End", 35135),
(34878, 2, 0, "Not the face, not the face!", 12, 0, 100, 0, 0, 0, "Sudsy Magee Say End", 35136),
(34878, 3, 0, "Business been bad lately, Sudsy?", 12, 0, 100, 0, 0, 0, "Say to Sudsy Magee ", 35137);

