

delete from fishing_loot_template where Entry=1 and Item=69931;
delete from fishing_loot_template where Entry=8 and Item=16970;
delete from fishing_loot_template where Entry=12 and Item in (49751, 58856, 58899);
delete from fishing_loot_template where Entry=14 and Item=52080;
delete from fishing_loot_template where Entry=33 and Item=16969;
delete from fishing_loot_template where Entry=61 and Item=58899;
delete from fishing_loot_template where Entry=65 and Item=45904;
delete from fishing_loot_template where Entry=148 and Item in (6717, 6718);
delete from fishing_loot_template where Entry=405 and Item=16968;
delete from fishing_loot_template where Entry=443 and Item=6718;
delete from fishing_loot_template where Entry=445 and Item in (6717, 6718);
delete from fishing_loot_template where Entry=448 and Item in (6717, 6718);
delete from fishing_loot_template where Entry=449 and Item=6717;
delete from fishing_loot_template where Entry=454 and Item in (6717, 6718);
delete from fishing_loot_template where Entry=456 and Item in (6717, 6718);
delete from fishing_loot_template where Entry=1497 and Item=69901;
delete from fishing_loot_template where Entry=1519 and Item in (57245, 58503, 58787,58856);
delete from fishing_loot_template where Entry=1537 and Item in (34864, 49751, 69932, 69933);
delete from fishing_loot_template where Entry=1578 and Item=16969;
delete from fishing_loot_template where Entry=1617 and Item=58856;
delete from fishing_loot_template where Entry=1637 and Item in (34864, 52080, 58945, 58946);
delete from fishing_loot_template where Entry=1657 and Item in (69912, 69914);
delete from fishing_loot_template where Entry=2077 and Item in (6717, 6718);
delete from fishing_loot_template where Entry=2403 and Item=16970;
delete from fishing_loot_template where Entry=2406 and Item=16968;
delete from fishing_loot_template where Entry=2408 and Item=16968;
delete from fishing_loot_template where Entry=2521 and Item=16967;
delete from fishing_loot_template where Entry=3518 and Item=34868;
delete from fishing_loot_template where Entry=3537 and Item=45905;
delete from fishing_loot_template where Entry=3636 and Item=34868;
delete from fishing_loot_template where Entry=3979 and Item=45328;
delete from fishing_loot_template where Entry=4567 and Item=45328;
delete from fishing_loot_template where Entry=5287 and Item=16969;
delete from fishing_loot_template where Entry=5339 and Item=16969;
delete from fishing_loot_template where Entry=5390 and Item=58503;
delete from fishing_loot_template where Entry=5861 and Item=73269;

INSERT INTO fishing_loot_template VALUES (1,69931,0,42.9281,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (8,16970,0,1.20143,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (12,49751,0,0.000176208,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (12,58856,0,0.000234944,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (12,58899,0,34.6708,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (14,52080,0,0.000266977,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (33,16969,0,0.62361,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (61,58899,0,40,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (65,45904,0,2.31889,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (148,6717,0,25,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (148,6718,0,0.210441,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (405,16968,0,2.36401,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (443,6718,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (445,6717,0,100,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (445,6718,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (448,6717,0,100,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (448,6718,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (449,6717,0,100,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (454,6717,0,100,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (454,6718,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (456,6717,0,100,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (456,6718,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (1497,69901,0,4.35459,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1519,57245,0,3.98271,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1519,58503,0,24.6427,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1519,58787,0,3.2415,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1519,58856,0,6.69964,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1537,34864,0,0.0439936,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1537,49751,0,0.000604253,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1537,69932,0,0.216362,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1537,69933,0,0.664952,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1578,16969,0,20,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (1617,58856,0,35,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (1637,34864,0,20,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (1637,52080,0,0.000544055,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1637,58945,0,16.3946,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1637,58946,0,2.79019,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1657,69912,0,18.5264,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (1657,69914,0,3.80077,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (2077,6717,0,100,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (2077,6718,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (2403,16970,0,20,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (2406,16968,0,20,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (2408,16968,0,20,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (2521,16967,0,20,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (3518,34868,0,2.51026,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (3537,45905,0,6.42058,True,1,1,1,3,'');
INSERT INTO fishing_loot_template VALUES (3636,34868,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (3979,45328,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (4567,45328,0,25,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (5287,16969,0,0.117902,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (5339,16969,0,0.224321,True,1,1,1,1,'');
INSERT INTO fishing_loot_template VALUES (5390,58503,0,26,True,1,0,1,1,'');
INSERT INTO fishing_loot_template VALUES (5861,73269,0,20.8722,True,1,0,1,1,'');









