
-- console error
DELETE FROM creature_addon WHERE guid=152069;

-- achievement removed befor client 4.03.. now observer 10569 is used..
DELETE FROM achievement_criteria_data WHERE criteria_id=10570;
DELETE FROM achievement_criteria_data WHERE criteria_id=10568;


