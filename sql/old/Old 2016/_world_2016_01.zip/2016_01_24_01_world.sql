
update creature set position_z=280.1 where guid=56742 and id=2861;
update creature set phaseMask=1 where guid=29684 and id=2861;
