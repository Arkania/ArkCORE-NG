

update creature_template set InhabitType=4 where entry=46861;

