
-- training-dummy
update creature_template set minlevel=1, maxlevel=1, AIname="", ScriptName="npc_training_dummy" where entry=4952;


