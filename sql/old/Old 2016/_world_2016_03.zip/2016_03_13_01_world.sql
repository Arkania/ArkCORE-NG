
update creature set phaseMask=1 where map=654 and id in (42853,38783,38365);
update creature set phaseMask=2 where map=654 and id in (35874,35871,35869);
update creature set phaseMask=8 where map=654 and id in (35229);
update creature set phaseMask=32 where map=654 and id in (37716,37718,37783,37802,37692,37784,38218,37735,37786,37694,37686,37701,37876,38553,37875,38764,37733,38143,37803,37685);
update creature set phaseMask=64 where map=654 and id in (37885,37884);
update creature set phaseMask=128 where map=654 and id in (50271,38780,43727,37921,16512,37939,37914,38150,43747,37916,37938,38287,38363,38364,38149,38781,38144,50274,50273,50275,38344);
update creature set phaseMask=416 where map=654 and id in (37889,37892,37891);
update creature set phaseMask=1095 where map=654 and id in (4075);
update creature set phaseMask=2049 where map=654 and id in (36198);
update creature set phaseMask=4096 where map=654 and id in (36190,36810,36170,36205);
update creature set phaseMask=8192 where map=654 and id in (36312,36283,36140,36399,36397,36236,36396,36231,36211,34511,36288,36287,36289);
update creature set phaseMask=12288 where map=654 and id in (44125,34571,36132);
update creature set phaseMask=12295 where map=654 and id in (14881);
update creature set phaseMask=16384 where map=654 and id in (50252,36456,36454,36491,36455,36488,36671,36460,36440,36653,36458,36693,36528,36452,36459,36451);
update creature set phaseMask=20480 where map=654 and id in (36602);
update creature set phaseMask=24576 where map=654 and id in (36690,36290,36779,36291);
update creature set phaseMask=24577 where map=654 and id in (36286);
update creature set phaseMask=28672 where map=654 and id in (36698,36512,36713,36631,36628,36453,36717,36629,36630,36457,36540,36695,36651,36632,36652,38791,50574,50567);
update creature set phaseMask=32767 where map=654 and id in (50260);
update creature set phaseMask=32768 where map=654 and id in (37045,37492,37067,37499,36882,50570,36293,36813,37065,37102,37815,43558,38755,38792,38022,37785,37822,42953,37197,37195,37870,36814,37873,37489);
update creature set phaseMask=32769 where map=654 and id in (37757,41561);
update creature set phaseMask=32800 where map=654 and id in (38794,38799,38798,38793,38795,38797,37874,38796);
update creature set phaseMask=41089 where map=654 and id in (36616);
update creature set phaseMask=45229 where map=654 and id in (1933);
update creature set phaseMask=49152 where map=654 and id in (36606,36742,36743);
update creature set phaseMask=61440 where map=654 and id in (50252,50247);
update creature set phaseMask=61441 where map=654 and id in (385,36714);
update creature set phaseMask=67108863 where map=654 and id in (35374,36449,39660,883);

update gameobject set phaseMask=32 where id in (201775);
update gameobject set phaseMask=64 where id in (201964,201871);
update gameobject set phaseMask=4096 where id in (196394,197337);
update gameobject set phaseMask=8192 where id in (196411,196403);
update gameobject set phaseMask=16384 where id in (196808,196404,197333,196809,196810);
update gameobject set phaseMask=24576 where id in (196465,196472,196473);
update gameobject set phaseMask=28672 where id in (196880,196849,196854,196866,196879,196841,196846);
update gameobject set phaseMask=30720 where id in (196850,196851,196868,196867,196869);
update gameobject set phaseMask=32767 where id in (207417);
update gameobject set phaseMask=32768 where id in (205005,205009,201594,201952,201950,201951,201939);
update gameobject set phaseMask=32769 where id in (201914,201607);
update gameobject set phaseMask=49568 where id in (196412);

-- update gameobject set phaseMask=1 where id in (202624,202625,202632,202633,202634,202643,202644,202645,202646,205021,205024,205028,205032,202626,202627,202628,202629,202630,202631,202635,202636,202637,202638,202639,202640,202641,202642,205030,205034);
-- update gameobject set phaseMask=65535 where id in (1731);

