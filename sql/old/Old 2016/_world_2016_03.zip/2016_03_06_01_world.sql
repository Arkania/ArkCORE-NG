
-- fix issue #101
update creature_template set minlevel=26, maxlevel=27 where entry=698;

