
delete from phase_definitions where zoneId=4714 and entry=7;
insert into phase_definitions values 
(4714, 7, 4096, 0, 638, 683, 1, "Duskhaven start phase 4096");

delete from phase_area where areaId=4714 and entry=7;
insert into phase_area values 
(4714, 7 , 14222, 14375, 64, 1, 1, "Duskhaven start phase 4096");

