

update arkcore_string set content_default="Position: %f %f %f %f.", content_loc3=NULL, content_loc8=NULL  where entry=544;

update arkcore_string set content_loc3="Karte: %u (%s) Zone: %u (%s) Gebiet: %u (%s) Phase: %uX: %f Y: %f Z: %f Orientierung: %fgrid[%u,%u]Zelle[%u,%u] InstanzID: %u ZoneX: %f ZoneY: %fGroundZ: %f FloorZ: %f Have height data (Map: %u VMap: %u)" where entry=101;

