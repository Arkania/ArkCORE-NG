
DELETE FROM creature_text WHERE entry=34872 AND groupid=5 AND id=0;
INSERT INTO creature_text VALUES 
(34872, 5, 0, "Boss, tell Sassy that I'll get her more Kaja'Cola just as soon as production resumes.", 12, 0, 100, 0, 0, 0, "Foreman Dampwick", 49017);

DELETE FROM creature_text WHERE entry=35075;
INSERT INTO creature_text VALUES 
(35075, 0, 0, "You're gonna hear from my lawyer!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35309),
(35075, 0, 1, "Watch where you're going!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35310),
(35075, 0, 2, "Learn how to drive you maniac!", 14, 0, 100, 5, 0, 0, "", 35311),
(35075, 0, 3, "Ouch!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35312),
(35075, 0, 4, "My neck! I'm gonna sue!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35313),
(35075, 0, 5, "I'll get you, $N!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35314),
(35075, 0, 6, "You're a public nuisance, $N!", 12, 0, 100, 5, 0, 18500, "", 35315),
(35075, 0, 7, "The Trade Prince will hear about this, $N!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35316),
(35075, 1, 0, "Hey look, it's $N. I bet $G he's : she's; loaded. I hear that $G he's : she's; going after the Trade Prince's job!", 12, 0, 100, 5, 0, 0, "Kezan Citizen", 40307);

DELETE FROM creature_text WHERE entry=35063;
INSERT INTO creature_text VALUES 
(35063, 0, 0, "You're gonna hear from my lawyer!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35309),
(35063, 0, 1, "Watch where you're going!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35310),
(35063, 0, 2, "Learn how to drive you maniac!", 14, 0, 100, 5, 0, 0, "", 35311),
(35063, 0, 3, "Ouch!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35312),
(35063, 0, 4, "My neck! I'm gonna sue!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35313),
(35063, 0, 5, "I'll get you, $N!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35314),
(35063, 0, 6, "You're a public nuisance, $N!", 12, 0, 100, 5, 0, 18500, "", 35315),
(35063, 0, 7, "The Trade Prince will hear about this, $N!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 35316),
(35063, 1, 0, "Hey look, it's $N. I bet $G he's : she's; loaded. I hear that $G he's : she's; going after the Trade Prince's job!", 12, 0, 100, 5, 0, 0, "Kezan Citizen", 40307);

DELETE FROM creature_text WHERE entry=34874 AND groupid=1 AND id=0;
INSERT INTO creature_text VALUES 
(34874, 1, 0, "There they are! Okay, you three make sure that you help $G him : her; out today. $G He's : She's; got a lot of stuff to take care of before the party!", 12, 0, 100, 1, 0, 0, "Megs Dreadshredder", 49020);

DELETE FROM creature_text WHERE entry=35222 AND groupid=2 AND id=0;
INSERT INTO creature_text VALUES 
(35222, 2, 0, "Is that you, $N? What are you doing away from headquarters? Get back to work!", 14, 0, 100, 5, 0, 19546, "Trade Prince Gallywix", 37243);

DELETE FROM creature_text WHERE entry=34835 AND groupid=2 AND id=0;
INSERT INTO creature_text VALUES 
(34835, 2, 0, "Darn, you got me!", 12, 0, 100, 0, 0, 0, "Bruno Flameretardant", 35126);

DELETE FROM creature_text WHERE entry=34877 AND groupid=1 AND id=0;
INSERT INTO creature_text VALUES 
(34877, 1, 0, "%s grunts and gives up, clearly beaten.", 16, 0, 100, 0, 0, 0, "Jack the Hammer", 35132);

DELETE FROM creature_text WHERE entry=34959 AND groupid=2 AND id=0;
INSERT INTO creature_text VALUES 
(34959, 2, 0, "Go for the face! Go for the face!", 12, 0, 100, 0, 0, 0, "Izzy", 35385);

DELETE FROM creature_text WHERE entry=34878 AND groupid=1 AND id=0;
INSERT INTO creature_text VALUES 
(34878, 1, 0, "Not the face, not the face!", 12, 0, 100, 0, 0, 0, "Sudsy Magee", 35135);

DELETE FROM creature_text WHERE entry=34957 AND groupid=2 AND id=0;
INSERT INTO creature_text VALUES 
(34957, 2, 0, "You do NOT mess with us!", 12, 0, 100, 0, 0, 0, "Ace", 35390);

DELETE FROM creature_text WHERE entry=34835 AND groupid=2 AND id=0;
INSERT INTO creature_text VALUES 
(34835, 2, 0, "Darn, you got me!", 12, 0, 100, 0, 0, 0, "Bruno Flameretardant", 35126);

DELETE FROM creature_text WHERE entry=34959 AND groupid=3 AND id=0;
INSERT INTO creature_text VALUES 
(34959, 3, 0, "I been waitin' all day for this!", 12, 0, 100, 0, 0, 0, "Izzy", 35392);

DELETE FROM creature_text WHERE entry=34959 AND groupid=4 AND id=0;
INSERT INTO creature_text VALUES 
(34959, 4, 0, "You lookin' at me?", 12, 0, 100, 0, 0, 0, "Izzy", 35391);

DELETE FROM creature_text WHERE entry=34876 AND groupid=2 AND id=0;
INSERT INTO creature_text VALUES 
(34876, 2, 0, "What? Fine, fine... I'll pay my protection moolah to your goons!", 12, 0, 100, 0, 0, 0, "Frankie Gearslipper", 35129);

DELETE FROM creature_text WHERE entry=35120 AND groupid=1 AND id=0;
INSERT INTO creature_text VALUES 
(35120, 1, 0, "Next please!", 12, 0, 100, 5, 0, 0, "FBoK Bank Teller", 35920);

DELETE FROM creature_text WHERE entry=35063 AND groupid=2 AND id=0;
INSERT INTO creature_text VALUES 
(35063, 2, 0, "Szabo. He's so hot right now!", 12, 0, 100, 0, 0, 0, "Kezan Citizen", 40308);

DELETE FROM creature_text WHERE entry=35222 AND groupid=3 AND id=0;
INSERT INTO creature_text VALUES 
(35222, 3, 0, "All hail the greatest trade prince on Azeroth... me!", 14, 0, 100, 5, 0, 19547, "Trade Prince Gallywix", 37244);

DELETE FROM creature_text WHERE entry=35222 AND groupid=4 AND id=0;
INSERT INTO creature_text VALUES 
(35222, 4, 0, "I'm beginning to regret promoting you, $N!", 14, 0, 100, 1, 0, 19550, "Trade Prince Gallywix", 37247);

DELETE FROM creature_text WHERE entry=37106 AND groupid=3 AND id=0;
INSERT INTO creature_text VALUES 
(37106, 3, 0, "Get into that shredder and win the game. The Bilgewater Cartel's counting on you!", 12, 0, 100, 25, 0, 0, "Coach Crosscheck", 49026);

DELETE FROM creature_text WHERE entry=34957 AND groupid=3 AND id=0;
INSERT INTO creature_text VALUES 
(34957, 3, 0, "What was that thing, $G dude : toots;?", 12, 0, 100, 0, 0, 0, "Ace", 48862);

DELETE FROM creature_text WHERE entry=34959 AND groupid=5 AND id=0;
INSERT INTO creature_text VALUES 
(34959, 5, 0, "Why's the ground shaking, $N?!", 12, 0, 100, 0, 0, 0, "Izzy", 48861);

DELETE FROM creature_text WHERE entry=37106 AND groupid=3 AND id=0;
INSERT INTO creature_text VALUES 
(37106, 3, 0, "You got the juice, kid. That's for sure! Too bad that dragon had to come and ruin everything. No matter. You made us proud. Now get back to headquarters.", 12, 0, 100, 4, 0, 0, "Coach Crosscheck", 49027);

DELETE FROM creature_text WHERE entry=34689 AND groupid=1 AND id=0;
INSERT INTO creature_text VALUES 
(34689, 1, 0, "All you gotta do is let me teach you how to do an Eviscerate. Then, head over to one of those training dummies that Bamm is shooting at and attack it with a Sinister Strike. Once you've done that, finish it off with the Eviscerate.", 12, 0, 100, 463, 0, 0, "Fizz Lighter", 49031);

DELETE FROM creature_text WHERE entry=34959 AND groupid=6 AND id=0;
INSERT INTO creature_text VALUES 
(34959, 6, 0, "Is this the deadbeat?", 12, 0, 100, 0, 0, 0, "Izzy", 35386);

DELETE FROM creature_text WHERE entry=34957 AND groupid=4 AND id=0;
INSERT INTO creature_text VALUES 
(34957, 4, 0, "Get 'em!", 12, 0, 100, 0, 0, 0, "Ace", 35387);


DELETE FROM creature_text WHERE entry=48496;
INSERT INTO creature_text VALUES 
(48496, 0, 0, "You don't have to yell, Hobart, I'm standing right here. Sheesh!", 12, 0, 100, 274, 0, 0, "", 49102),
(48496, 1, 0, "Greely coughs.", 16, 0, 100, 25, 0, 0, "", 49113),
(48496, 2, 0, "Um, Hobart, you're at the controls.", 12, 0, 100, 273, 0, 0, "Assistant Greely", 49114),
(48496, 3, 0, "Um, Hobart, you're wearing them.", 12, 0, 100, 0, 0, 0, "Assistant Greely", 49248),
(48496, 4, 0, "Yeah, a real party that I was actually invited to. Why does something always happen and I never get to go? I could use a drink.", 12, 0, 100, 0, 0, 0, "Assistant Greely", 49247),
(48496, 5, 0, "Technically speaking, that's not true, doctor. The rocks that fly out of a volcano like Mount Kajaro are called ejecta. It's not the sky. It's molten rock, or tephra. It cools as it descends, becoming lava bombs. Very appropriate, wouldn't you say?", 12, 0, 100, 0, 0, 0, "Assistant Greely", 49246),
(48496, 6, 0, "Right away. I'll flag the Lab-In-A-Box for deployment in Azshara.  I'll pack her little cushion in with her, too. She's so cute!", 12, 0, 100, 0, 0, 0, "Assistant Greely", 49245),
(48496, 7, 0, "You're going to blow if you don't calm down! Don't you think it was a little bit convenient? The dragon flying over right as the winning field goal for the footbomb finals was kicked into Mount Kajaro?", 12, 0, 100, 0, 0, 0, "Assistant Greely", 49244),
(48496, 8, 0, "Hmm, I know I saw it around here somewhere, but are you sure? That thing turns the user into a brute instead of projecting an image of one about fifty percent of the time. And then they explode!", 12, 0, 100, 0, 0, 0, "Assistant Greely", 49243),
(48496, 9, 0, "I will, I will. But, Hobart, you have to calm down. Your blood pressure! You're turning deep green!", 12, 0, 100, 0, 0, 0, "Assistant Greely", 49242),
(48496, 10, 0, "I'm on it, doctor. Schematics, check. Toothbrush, check.", 12, 0, 100, 0, 0, 0, "Assistant Greely", 49241),
(48496, 11, 0, "Don't worry about Hobart, boss. He's just having a bit of a breakdown right now.$B$BThe Cataclysm couldn't have come at a worse time for him. He was so close to being done with the Micro Mechachicken.", 12, 0, 100, 1, 0, 0, "Assistant Greely", 49240);

DELETE FROM creature_text WHERE entry=48494;
INSERT INTO creature_text VALUES 
(48494, 0, 0, "Prepare the Micro Mechachicken!", 14, 0, 100, 25, 0, 0, "", 49101),
(48494, 1, 0, "Flip the switch!", 12, 0, 100, 22, 0, 0, "", 49112),
(48494, 2, 0, "Quite right, Greely. You passed today's pop quiz.", 12, 0, 100, 0, 0, 0, "Hobart Grapplehammer", 49115),
(48494, 3, 0, "I am now flipping the switch!", 12, 0, 100, 1, 0, 0, "Hobart Grapplehammer", 49116),
(48494, 4, 0, "Greely, can you feel it? My moment of success is at hand!", 12, 0, 100, 6, 0, 0, "Hobart Grapplehammer", 49117),
(48494, 5, 0, "Grocery store owners everywhere will owe me a percentage of their profits!", 12, 0, 100, 4, 0, 0, "Hobart Grapplehammer", 49118),
(48494, 6, 0, "I'm flipping the second switch!", 12, 0, 100, 1, 0, 0, "Hobart Grapplehammer", 49119),
(48494, 7, 0, "There's just not enough time to pack all of this stuff up! Grab only the important stuff! Where'd I put my Blastproof Underwater G-Ray Goggles?!", 12, 0, 100, 6, 0, 0, "Hobart Grapplehammer", 49239),
(48494, 8, 0, "A party? Can you believe it? A party and the whole island is about to explode?! What are they thinking!!!", 12, 0, 100, 15, 0, 0, "Hobart Grapplehammer", 49238),
(48494, 9, 0, "The sky is falling!", 12, 0, 100, 0, 0, 0, "Hobart Grapplehammer", 49237),
(48494, 10, 0, "How are we going to get Subject Nine through customs? I know! Pack her into the Lab-In-A-Box!", 12, 0, 100, 6, 0, 0, "Hobart Grapplehammer", 49236),
(48494, 11, 0, "Deathwing?! The Cataclysm?! We're doomed!! We have to get off of Kezan before Mount Kajaro blows for good!!!", 12, 0, 100, 5, 0, 0, "Hobart Grapplehammer", 49235),
(48494, 12, 0, "Whatever you do, don't let me forget my Ingenious Cap of Mook Foolery!", 12, 0, 100, 0, 0, 0, "Hobart Grapplehammer", 49234),
(48494, 13, 0, "Get everything packed! We have to find a way off of Kezan! We'll jump into the closest Town-In-A-Box! They'll load it on the Trade Prince's yacht.", 12, 0, 100, 0, 0, 0, "Hobart Grapplehammer", 49233),
(48494, 14, 0, "We have to get off the island! Quick, Greely, grab the schematics! And my toothbrush!", 12, 0, 100, 396, 0, 0, "Hobart Grapplehammer", 49232),
(48494, 15, 0, "$N?! What are you still doing here?$B$BYou have to get off of the island, or better yet, into one of my Town-In-A-Boxes!$B$BDon't wait too long, my $G boy : girl;! The Cataclysm is upon us!", 12, 0, 100, 5, 0, 0, "Hobart Grapplehammer", 49231);

DELETE FROM creature_text WHERE entry=35175;
INSERT INTO creature_text VALUES 
(35175, 0, 0, "A fresh glass of bubbly. Just what the doctor ordered, $N.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35417),
(35175, 0, 1, "Thanks for the refill, $G sir : ma'am;!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35418),
(35175, 0, 2, "This sparkling white wine is delicious! Wherever did you get it?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35419),
(35175, 0, 3, "I think this one will have to be my last. I'm driving home after the party.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35420),
(35175, 0, 4, "Thanksh!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35421),
(35175, 0, 5, "I feel much better now...hic!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35422),
(35175, 0, 6, "Oh, my head hurtsh.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35423),
(35175, 0, 7, "Shorry about your shoes.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35424),
(35175, 0, 8, "A disco ball?! Groovy!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35425),
(35175, 0, 9, "How do you like my moves, $N?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35426),
(35175, 0, 10, "We should totally have a pants-off dance-off!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35427),
(35175, 0, 11, "Shake it like a goblinoid picture!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35428),
(35175, 0, 12, "Wow! That sure beats this puny, little sparkler!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35429),
(35175, 0, 13, "You really stop at no expense, $N! Amazing!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35430),
(35175, 0, 14, "Best... Party... Evar!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35431),
(35175, 0, 15, "Woo hoo, fireworks! More, more!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35432),
(35175, 0, 16, "Thanks. I was almost out. So hungry!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35433),
(35175, 0, 17, "These are the most delicious hors d'oeurves I have ever tasted. You must share your recipe, $N!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35434),
(35175, 0, 18, "Finger licking good!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35435),
(35175, 0, 19, "Nom, nom, nom!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35436);

DELETE FROM creature_text WHERE entry=35186;
INSERT INTO creature_text VALUES 
(35186, 0, 0, "A fresh glass of bubbly. Just what the doctor ordered, $N.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35417),
(35186, 0, 1, "Thanks for the refill, $G sir : ma'am;!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35418),
(35186, 0, 2, "This sparkling white wine is delicious! Wherever did you get it?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35419),
(35186, 0, 3, "I think this one will have to be my last. I'm driving home after the party.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35420),
(35186, 0, 4, "Thanksh!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35421),
(35186, 0, 5, "I feel much better now...hic!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35422),
(35186, 0, 6, "Oh, my head hurtsh.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35423),
(35186, 0, 7, "Shorry about your shoes.", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35424),
(35186, 0, 8, "A disco ball?! Groovy!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35425),
(35186, 0, 9, "How do you like my moves, $N?", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35426),
(35186, 0, 10, "We should totally have a pants-off dance-off!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35427),
(35186, 0, 11, "Shake it like a goblinoid picture!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35428),
(35186, 0, 12, "Wow! That sure beats this puny, little sparkler!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35429),
(35186, 0, 13, "You really stop at no expense, $N! Amazing!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35430),
(35186, 0, 14, "Best... Party... Evar!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35431),
(35186, 0, 15, "Woo hoo, fireworks! More, more!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35432),
(35186, 0, 16, "Thanks. I was almost out. So hungry!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35433),
(35186, 0, 17, "These are the most delicious hors d'oeurves I have ever tasted. You must share your recipe, $N!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35434),
(35186, 0, 18, "Finger licking good!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35435),
(35186, 0, 19, "Nom, nom, nom!", 12, 0, 100, 0, 0, 0, "Kezan Partygoer", 35436);

DELETE FROM creature_text WHERE entry=35053 AND groupid=1 AND id=0;
INSERT INTO creature_text VALUES 
(35053, 1, 0, "You're the most handsome boyfriend a girl could hope for. Knock 'em dead, honey!", 12, 0, 100, 0, 0, 0, "Candy Cane", 49012);

DELETE FROM creature_text WHERE entry=37804 AND groupid=0 AND id=6;
INSERT INTO creature_text VALUES 
(37804, 0, 6, "All new Kaja'Cola! Now with 100 percent more ideas!", 12, 0, 100, 0, 0, 0, "Kaja'Cola Balloon", 37402);

DELETE FROM creature_text WHERE entry=34695 AND groupid=2 AND id=0;
INSERT INTO creature_text VALUES 
(34695, 2, 0, "How did the two of you ever make it to the executive level?", 12, 0, 100, 0, 0, 0, "Maxx Avalanche", 36785);

DELETE FROM creature_text WHERE entry=34872 AND groupid=6 AND id=0;
INSERT INTO creature_text VALUES 
(34872, 6, 0, "I can't believe the nerve of those trolls. Rebelling after all that I've done for them!", 12, 0, 100, 0, 0, 0, "Foreman Dampwick", 49038);

DELETE FROM creature_text WHERE entry=35294;
INSERT INTO creature_text VALUES 
(35294, 0, 0, "I can't believe the nerve of those trolls. Rebelling after all that I've done for them!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49038),
(35294, 0, 1, "Ya got some nerve, mon!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49039),
(35294, 0, 2, "Ya bring down da big badda dragon an' destroy da island!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49040),
(35294, 0, 3, "I not gonna take it anymore, mon!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49041),
(35294, 0, 4, "Kezan for da trolls!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49042),
(35294, 0, 5, "Outa my way, mon. I'm off ta join da pirates!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49043),
(35294, 0, 6, "Maybe I take dem bombs from ya an' we see who go boom!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49044),
(35294, 0, 7, "Dis here be our kaja'mite! We mine it up with our own sweat an' blood!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49045),
(35294, 0, 8, "Lil' green goblin gonna bleed for all ya done!", 12, 0, 100, 0, 0, 0, "Rebellious Troll", 49046),
(35294, 0, 9, "Yeah? Whadya want, ya mook? Be on the lookout for that no-good $N!$B$BNow get back to work!", 12, 0, 100, 25, 0, 0, "Rebellious Troll", 49047);

DELETE FROM creature_text WHERE entry=35222 AND groupid=5 AND id=0;
INSERT INTO creature_text VALUES 
(35222, 5, 0, "It doesn't matter that Mount Kajaro has blown. All that matters is that I stay on top!", 14, 0, 100, 274, 0, 19553, "Trade Prince Gallywix", 35916);

DELETE FROM creature_text WHERE entry=35222 AND groupid=6 AND id=0;
INSERT INTO creature_text VALUES 
(35222, 6, 0, "Ready my yacht! We ride with the tide and only the most wealthy and fit will be welcome to come with us!", 14, 0, 100, 5, 0, 19555, "Trade Prince Gallywix", 35918);

DELETE FROM creature_text WHERE entry=35222 AND groupid=7 AND id=0;
INSERT INTO creature_text VALUES 
(35222, 7, 0, "Papers to weigh? Doors to stop? Windows to break? bam, Bam, BAM! Volcano rocks.", 14, 0, 100, 0, 0, 0, "Trade Prince Gallywix", 37103);

DELETE FROM creature_text WHERE entry=37500;
INSERT INTO creature_text VALUES 
(37500, 0, 0, "Volcano rocks! Get your volcano rocks here!", 14, 0, 100, 0, 0, 0, "Vinny Slapchop", 37098),
(37500, 0, 1, "Volcano rocks for sale! Hot off the mountain! You want 'em, I got 'em!", 14, 0, 100, 0, 0, 0, "Vinny Slapchop", 37099),
(37500, 0, 2, "Volcano rocks - new low price! You're gonna love my rocks.", 14, 0, 100, 0, 0, 0, "Vinny Slapchop", 37100),
(37500, 0, 3, "Get your volcano rocks here! ...Great for cats!", 14, 0, 100, 0, 0, 0, "Vinny Slapchop", 37101),
(37500, 0, 4, "Take home a piece of the Cataclysm! Volcano rocks for sale - hot, Hot, HOT!", 14, 0, 100, 0, 0, 0, "Vinny Slapchop", 37102),
(37500, 0, 5, "Papers to weigh? Doors to stop? Windows to break? bam, Bam, BAM! Volcano rocks.", 14, 0, 100, 0, 0, 0, "Vinny Slapchop", 37103),
(37500, 0, 6, "Volcano rocks. Million and one uses. Lava, java, sauna, banana....", 14, 0, 100, 0, 0, 0, "Vinny Slapchop", 37104);

DELETE FROM creature_text WHERE entry=35486;
INSERT INTO creature_text VALUES 
(35486, 0, 0, "You are breaking into the vault to retrieve your Personal Riches!", 42, 0, 100, 0, 0, 0, "", 35566),
(35486, 1, 0, "Use what is called for in your Goblin All-In-1-Der Belt below to crack open the vault!$B|TInterface\Icons\INV_Misc_EngGizmos_20.blp:64|t |TInterface\Icons\INV_Misc_Bomb_07.blp:64|t |TInterface\Icons\INV_Misc_Ear_NightElf_02.blp:64|t |TInterface\Icons\INV_Misc_EngGizmos_swissArmy.blp:64|t |TInterface\Icons\INV_Weapon_ShortBlade_21.blp:64|t", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35567),
(35486, 2, 0, "The vault will be cracked once the |cFFFF2222Vault Breaking progress bar reaches 100 percent!|r$B|TInterface\Icons\INV_Misc_coin_02.blp:64|t$BDoing the wrong thing at the wrong time will reduce the progress of the bar.", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35568),
(35486, 3, 0, "Good luck!", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35569),
(35486, 4, 0, "Use your |cFFFF2222Kaja'mite Drill!|r$B|TInterface\Icons\INV_Weapon_ShortBlade_21.blp:64|t", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35576),
(35486, 5, 0, "Use your |cFFFF2222Blastcrackers!|r$B|TInterface\Icons\INV_Misc_Bomb_07.blp:64|t", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35577),
(35486, 6, 0, "Use your |cFFFF2222Ear-O-Scope!|r$B|TInterface\Icons\INV_Misc_Ear_NightElf_02.blp:64|t", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35578),
(35486, 7, 0, "Use your |cFFFF2222Infinifold Lockpick!|r$B|TInterface\Icons\INV_Misc_EngGizmos_swissArmy.blp:64|t", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35579),
(35486, 8, 0, "Use your |cFFFF2222Amazing G-Ray!|r$B|TInterface\Icons\INV_Misc_EngGizmos_20.blp:64|t", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35700),
(35486, 9, 0, "Correct!", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35702),
(35486, 10, 0, "Incorrect!", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35704),
(35486, 11, 0, "Success! You have your Personal Riches!$B$B|TInterface\Icons\INV_Misc_coin_02.blp:64|t", 42, 0, 100, 0, 0, 0, "First Bank of Kezan Vault", 35852);

DELETE FROM creature_text WHERE entry=34668;
INSERT INTO creature_text VALUES 
(34668, 0, 0, "Haha! That should be a blast!", 12, 0, 100, 11, 0, 0, "Say Text on Quest Accept", 43954),
(34668, 1, 0, "Ace, Izzy, Gobber, you three make sure you tag along with $N and help them take care of those deadbeats!", 12, 0, 100, 11, 0, 0, "Say Text on Quest Accept", 49021),
(34668, 2, 0, "The Trade Prince's yacht is about to set sail. Everyone, get to the dock! Hand over the keys, boss. I'm driving. Just let me know when you're ready to go.", 12, 0, 100, 11, 0, 0, "Say Text on Quest Accept", 40278),
(34668, 3, 0, "He'll get me more later? How are we supposed to get you promoted to Trade $G Prince : Princess; without our number one product on the shelves?!!!", 12, 0, 100, 0, 0, 0, "Sassy Hardwrench", 49018),
(34668, 4, 0, "Go get 'em, boss!", 12, 0, 100, 0, 0, 0, "Sassy Hardwrench", 37318),
(34668, 5, 0, "You better get upstairs pronto, boss. Trade Prince Gallywix is waiting for you.", 12, 0, 100, 0, 0, 0, "Sassy Hardwrench", 49015),
(34668, 6, 0, "$N, you have to hurry and break your moolah out of the bank!", 12, 0, 100, 0, 0, 0, "Sassy Hardwrench", 49016),
(34668, 7, 0, "I can't stand to watch. So many good memories. So much profit.", 12, 0, 100, 0, 0, 0, "Sassy Hardwrench", 49071);

DELETE FROM creature_text WHERE entry=37680;
INSERT INTO creature_text VALUES 
(37680, 0, 0, "We'll have to go around.", 12, 0, 100, 0, 0, 1411, "", 37257),
(37680, 1, 0, "OUT OF THE WAY!", 14, 0, 100, 0, 0, 0, "Sassy Hardwrench", 37258),
(37680, 2, 0, "Here we are, safe and... OH NO! We've been double-crossed!", 12, 0, 100, 0, 0, 0, "Sassy Hardwrench", 37259);

DELETE FROM creature_text WHERE entry=36608;
INSERT INTO creature_text VALUES 
(36608, 0, 0, "Gizmo, what are you doing just sitting there? Don't you recognize who that is laying next to you?!", 14, 0, 100, 396, 0, 0, "Doc Zapnozzle", 36543),
(36608, 1, 0, "That's $N! $G He's : She's; the whole reason we're still breathing and not crispy fried critters back on Kezan.", 12, 0, 100, 396, 0, 0, "", 36544),
(36608, 2, 0, "Stay back, I'm going to resuscitate $Ghim:her;! I hope these wet jumper cables don't kill us all!", 14, 0, 100, 396, 0, 0, "Doc Zapnozzle", 36545),
(36608, 3, 0, "Come on! Clear!", 14, 0, 100, 396, 0, 0, "Doc Zapnozzle", 36546),
(36608, 4, 0, "That's all I've got. It's up to $Ghim:her; now. You hear me, $N? Come on, snap out of it! Don't go into the Light!", 14, 0, 100, 396, 0, 0, "Doc Zapnozzle", 36547),
(36608, 5, 0, "You made the right choice. We all owe you a great deal, $N. Try not to get yourself killed out here.", 14, 0, 100, 396, 0, 0, "Doc Zapnozzle", 36548),
(36608, 6, 0, "There are more survivors to tend to. I'll see you on the shore.", 14, 0, 100, 397, 0, 0, "Doc Zapnozzle", 36549);











