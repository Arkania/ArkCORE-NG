

ALTER TABLE `phase_definitions`
ADD COLUMN `phaseGroup`  smallint(5) NOT NULL AFTER `phaseId`;


