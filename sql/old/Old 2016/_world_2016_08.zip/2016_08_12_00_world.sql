
 
UPDATE creature_template SET unit_flags2=1073743872 WHERE entry=36616;
 
