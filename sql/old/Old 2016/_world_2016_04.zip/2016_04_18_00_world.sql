
-- fix issue #98
update creature_template set minlevel=40, maxlevel=41 where entry=10940;
