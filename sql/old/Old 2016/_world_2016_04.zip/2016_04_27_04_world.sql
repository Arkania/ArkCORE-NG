

delete from smart_scripts where entryorguid=7273;
update creature_template set AIName="" where entry=7273;

delete from smart_scripts where entryorguid=27699;
delete from smart_scripts where entryorguid=34846;
delete from smart_scripts where entryorguid=15274;
delete from smart_scripts where entryorguid=36459;
delete from smart_scripts where entryorguid=36488;
delete from smart_scripts where entryorguid=36555;
delete from smart_scripts where entryorguid=44367;
delete from smart_scripts where entryorguid=47091;


