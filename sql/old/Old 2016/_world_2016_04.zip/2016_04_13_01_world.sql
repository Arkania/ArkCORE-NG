

-- fix issue #130

delete from creature where id=35627 and position_z < 29.0;


