
update creature_template set AIName="", ScriptName="npc_spitescale_showfight" where entry in (38300, 38301, 38302);
update creature_template set AIName="", ScriptName="npc_darkspear_showfight" where entry in (38324, 38326);


