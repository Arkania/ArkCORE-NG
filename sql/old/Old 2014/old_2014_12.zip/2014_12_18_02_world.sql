

update game_event set start_time="2013-02-10 20:01:00", end_time="2020-02-24 16:00:00",occurence=475000,length=20160 where eventEntry=8; -- 14 days

update game_event set start_time="2013-10-17 20:01:00", end_time="2020-11-01 16:00:00",occurence=475000,length=21600 where eventEntry=12; -- 15 days

