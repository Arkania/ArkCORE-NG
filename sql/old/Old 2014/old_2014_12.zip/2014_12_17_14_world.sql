
delete from creature_queststarter where id=13444 and quest=7023;
delete from creature_queststarter where id=13445 and quest=7024;
