

update creature_text set BroadcastTextID=49916 where entry=50378 and groupid=1 and id=0;
update creature_text set BroadcastTextID=49918 where entry=50378 and groupid=1 and id=1;
update creature_text set BroadcastTextID=49917 where entry=50378 and groupid=1 and id=2;
update creature_text set BroadcastTextID=49919 where entry=50378 and groupid=1 and id=3;
update creature_text set BroadcastTextID=49915 where entry=50378 and groupid=1 and id=4;
update creature_text set BroadcastTextID=49922 where entry=50378 and groupid=1 and id=5;


