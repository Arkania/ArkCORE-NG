
update `creature_template` set `AIName`="", `ScriptName`="npc_woundet_trainee" where `entry`=44564;

