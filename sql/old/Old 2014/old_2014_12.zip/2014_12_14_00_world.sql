
UPDATE `creature_template_addon` SET `auras`=NULL WHERE `entry`=49874; -- 92857 Verstohlenheit

UPDATE `creature_template` SET `AIName`="", `ScriptName`="npc_blackrock_spy" where entry = 49874;