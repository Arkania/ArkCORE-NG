
update creature_template set AIName="",ScriptName="npc_princess" where entry=330;
update creature_template set AIName="",ScriptName="npc_porcine_encourage" where entry=390;
