
update creature_template set questItem1=60401 where entry=113;
