
update creature set phaseMask=1 where id in(42308,42309,42383,42390,42400,589,594,449,42407);

