

UPDATE  creature_template  SET  unit_flags  = 8 WHERE  creature_template . entry in (12427,12429,12423 );
