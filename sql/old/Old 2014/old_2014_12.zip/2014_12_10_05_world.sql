
update creature_text set BroadcastTextID=49804 where entry=49869 and groupid=0 and id=0;
update creature_text set BroadcastTextID=49807 where entry=49869 and groupid=0 and id=1;
update creature_text set BroadcastTextID=49809 where entry=49869 and groupid=0 and id=2;
update creature_text set BroadcastTextID=49806 where entry=49869 and groupid=0 and id=3;
update creature_text set BroadcastTextID=49808 where entry=49869 and groupid=0 and id=4;

update creature_text set BroadcastTextID=49897 where entry=49869 and groupid=1 and id=0;
update creature_text set BroadcastTextID=49895 where entry=49869 and groupid=1 and id=1;
update creature_text set BroadcastTextID=49898 where entry=49869 and groupid=1 and id=2;
update creature_text set BroadcastTextID=49896 where entry=49869 and groupid=1 and id=3;


