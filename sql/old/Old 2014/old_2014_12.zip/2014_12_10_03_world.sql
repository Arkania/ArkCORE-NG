
delete from gossip_menu where text_id=50000;
