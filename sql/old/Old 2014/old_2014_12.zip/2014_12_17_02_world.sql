
update creature_template set AIName="" where entry=14390;


