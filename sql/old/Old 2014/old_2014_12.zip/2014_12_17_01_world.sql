
update quest_template set RequestItemsText="Greetings!  Are you here for the party!  Or perhaps you just need to rest those weary feet of yours..." where Id=8860;



