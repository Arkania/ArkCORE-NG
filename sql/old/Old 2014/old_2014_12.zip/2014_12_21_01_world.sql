
-- spawn from script
delete from creature where id=42771;

-- wrong place, twice
delete from creature where guid=10800 and id=234;


update creature_template set AIName="", ScriptName="npc_riverpaw_sentinel_hill" where entry=54371;
update creature_template set AIName="", ScriptName="npc_riverpaw_sentinel_hill" where entry=54372;
update creature_template set AIName="", ScriptName="npc_riverpaw_sentinel_hill" where entry=54373;
update creature_template set AIName="", ScriptName="npc_sentinel_hill_guard" where entry=42407;
update creature_template set AIName="", ScriptName="npc_sentinel_hill_guard" where entry=51915;
update creature_template set AIName="", ScriptName="" where entry=42308;
update creature_template set AIName="", ScriptName="" where entry=42309;
update creature_template set AIName="", ScriptName="" where entry=43173;
update creature_template set AIName="", ScriptName="npc_defias_sentinel_hill" where entry=594;
update creature_template set AIName="", ScriptName="npc_defias_sentinel_hill" where entry=449;
update creature_template set AIName="", ScriptName="npc_defias_sentinel_hill" where entry=589;
update creature_template set AIName="", ScriptName="npc_salma_saldean" where entry=235;
update creature_template set AIName="", ScriptName="npc_riverpaw_westfall" where entry=124;
update creature_template set AIName="", ScriptName="npc_riverpaw_westfall" where entry=452;
update creature_template set AIName="", ScriptName="npc_riverpaw_westfall" where entry=501;
update creature_template set AIName="", ScriptName="npc_homeless_stormwind_citizen_42384" where entry=42384;
update creature_template set AIName="", ScriptName="npc_homeless_stormwind_citizen_42386" where entry=42386;



