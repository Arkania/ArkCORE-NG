
update quest_template set SourceSpellId=0 where Id=26215; 

