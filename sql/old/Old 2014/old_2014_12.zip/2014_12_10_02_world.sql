
update gossip_menu_option set OptionBroadcastTextID=3370 where menu_id=0 and id=1;
update gossip_menu_option set OptionBroadcastTextID=3266 where menu_id=0 and id=3;
update gossip_menu_option set OptionBroadcastTextID=2822 where menu_id=0 and id=6;
update gossip_menu_option set OptionBroadcastTextID=3413 where menu_id=0 and id=8;
update gossip_menu_option set OptionBroadcastTextID=3415 where menu_id=0 and id=9;
update gossip_menu_option set OptionBroadcastTextID=8912 where menu_id=0 and id=12;
update gossip_menu_option set OptionBroadcastTextID=3370 where menu_id=0 and id=13;
update gossip_menu_option set OptionBroadcastTextID=8271 where menu_id=0 and id=14;


