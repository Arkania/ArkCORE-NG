
update gossip_menu_option set option_text="I need a ride." ,OptionBroadcastTextID=3409 where menu_id=0 and id=2;
