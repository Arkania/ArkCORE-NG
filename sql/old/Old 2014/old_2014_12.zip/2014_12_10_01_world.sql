
delete from gossip_menu where entry=10260 and text_id=50000;
delete from npc_text where ID=50000;
delete from locales_npc_text where ID=50000;
 