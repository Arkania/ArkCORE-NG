
update creature_template set AIName="" where entry=327;

update creature_loot_template set mincountOrRef=1 where entry=327 and item in (727,954,2140,2406);


