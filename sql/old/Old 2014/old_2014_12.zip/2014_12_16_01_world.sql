
update creature_text set BroadcastTextID=49839 where entry=50039 and groupid=0 and id=0;
update creature_text set BroadcastTextID=49838 where entry=50039 and groupid=0 and id=1;
update creature_text set BroadcastTextID=49837 where entry=50039 and groupid=0 and id=2;
update creature_text set BroadcastTextID=49840 where entry=50039 and groupid=0 and id=3;
