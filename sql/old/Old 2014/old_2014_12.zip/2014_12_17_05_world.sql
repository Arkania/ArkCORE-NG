
update npc_text set BroadcastTextID0=42172 where ID=16211;

