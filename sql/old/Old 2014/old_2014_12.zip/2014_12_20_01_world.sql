
update creature_addon set bytes1=50331648, auras=NULL where guid=68632;