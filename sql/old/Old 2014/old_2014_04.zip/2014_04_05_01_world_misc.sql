
delete from creature_text where entry=21823 and groupid between 0 and 4 and id=0;
insert into creature_text (`entry`,`groupid`,`id`,`text`,`type`,`language`,`probability`,`emote`,`duration`,`sound`,`comment`) values 
(21823,0,0,"NOOOOooooooo!",14,0,100,0,0,0,""),
(21823,1,0,"Muahahahahaha! You fool! you've released me from my banishment in the interstices between space and time",12,0,100,0,0,0,""),
(21823,2,0,"All of Draenor shall quake beneath my feet! i Will destroy this world and reshape it in my immage",12,0,100,0,0,0,""),
(21823,3,0,"Where shall i Begin? i cannot bother myself with a worm such as yourself. Theres a World to be Conquered",12,0,100,0,0,0,""),
(21823,4,0,"No doubt the fools that banished me are long dead. i shall take the wing and survey my new demense, Pray to whatever gods you hold dear that we do not meet again.",12,0,100,0,0,0,"");


