
update creature_template set AIName="", ScriptName="npc_son_of_flame" where entry=12143;

