
update creature_template set AIName="", ScriptName="npc_feero_ironhand" where entry=33348;
update creature_template set AIName="", ScriptName="npc_delgren_the_purifier" where entry=33347;
update creature_template set AIName="", ScriptName="npc_bolyun_1" where entry=3698;
update creature_template set AIName="", ScriptName="npc_bolyun_2" where entry=34599;
update creature_template set AIName="", ScriptName="npc_big_baobob" where entry=34604;
update creature_template set AIName="", ScriptName="npc_astranaar_burning_fire_bunny" where entry=34123;

