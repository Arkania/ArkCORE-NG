
UPDATE quest_template SET NextQuestId=114 WHERE Id=112;
UPDATE quest_template SET PrevQuestId=112 WHERE Id=114;
