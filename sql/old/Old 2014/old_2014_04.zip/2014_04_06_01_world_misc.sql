

update creature_template set AIName="", ScriptName="npc_gwen_armstead_phase4" where entry=35840;

UPDATE quest_template SET PrevQuestId=14099 WHERE Id=14265;

