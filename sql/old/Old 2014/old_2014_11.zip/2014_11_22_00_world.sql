

delete from creature_text where entry=16151;
insert into creature_text values (16151, 0, 0, "Well done Midnight!", 14, 0, 100, 0, 0, 9173, "attumen SAY_MIDNIGHT_KILL", 15334);
insert into creature_text values (16151, 1, 0, "Cowards! Wretches!", 14, 0, 100, 0, 0, 9167, "attumen SAY_APPEAR1", 13459);
insert into creature_text values (16151, 1, 1, "Who dares attack the steed of the Huntsman?", 14, 0, 100, 0, 0, 9298, "attumen SAY_APPEAR2", 15378);
insert into creature_text values (16151, 1, 2, "Perhaps you would rather test yourselves against a more formidable opponent?!", 14, 0, 100, 0, 0, 9299, "attumen SAY_APPEAR3", 15379);
insert into creature_text values (16151, 2, 0, "Come, Midnight, let's disperse this petty rabble!", 14, 0, 100, 0, 0, 9168, "attumen SAY_MOUNT", 13456);
insert into creature_text values (16151, 3, 0, "It was... inevitable.", 14, 0, 100, 0, 0, 9169, "attumen SAY_KILL1", 13460);
insert into creature_text values (16151, 3, 1, "Another trophy to add to my collection!", 14, 0, 100, 0, 0, 9300, "attumen SAY_KILL2", 15333);
insert into creature_text values (16151, 4, 0, "Weapons are merely a convenience for a warrior of my skill!", 14, 0, 100, 0, 0, 9166, "attumen SAY_DISARMED", 13490);
insert into creature_text values (16151, 5, 0, "I always knew... someday I would become... the hunted.", 14, 0, 100, 0, 0, 9165, "attumen SAY_DEATH", 13462);
insert into creature_text values (16151, 6, 0, "Such easy sport.", 14, 0, 100, 0, 0, 9170, "attumen SAY_RANDOM1", 0);
insert into creature_text values (16151, 6, 1, "Amateurs! Do not think you can best me! I kill for a living.", 14, 0, 100, 0, 0, 9304, "attumen SAY_RANDOM2", 0);
