
update creature_equip_template set itemEntry2=13609 where entry=16159;

