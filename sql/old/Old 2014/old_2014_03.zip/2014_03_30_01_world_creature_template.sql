

update creature_template set AIName="", ScriptName="npc_novice_darkspear_warrior" where entry=38268;

