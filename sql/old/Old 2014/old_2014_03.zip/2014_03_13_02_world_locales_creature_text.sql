
ALTER TABLE locales_creature_text DROP PRIMARY KEY, ADD PRIMARY KEY(entry, groupid, id);