-- Training Dummy for quest
UPDATE creature_template SET KillCredit1 = 44175, unit_flags = 4, ScriptName = 'npc_training_dummy' WHERE entry IN (
  44171
, 44389
, 44548
, 44614
, 44820
, 44848
, 44937
, 44703
, 48304
);