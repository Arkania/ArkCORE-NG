
update creature_template set AIName="", ScriptName="npc_fledgling_brave" where entry=36942;
update creature_template set AIName="", ScriptName="npc_bristleback_invader" where entry=36943;
