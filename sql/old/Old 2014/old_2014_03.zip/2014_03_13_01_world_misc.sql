

-- npc 34850
update creature_template set AIName="",ScriptName="npc_prince_liam_greymane_intro" where entry=34850;
update creature_text set groupid=1,id=0 where entry=34850 and groupid=0 and id=1;
update creature_text set groupid=2,id=0 where entry=34850 and groupid=0 and id=2;
-- npc 34863
update creature_template set AIName="",ScriptName="npc_lieutenant_walden" where entry=34863; 
-- npc 50260
update creature_template set AIName="",ScriptName="npc_gilnean_crow" where entry=50260; 
-- npc 44086
update creature_template set AIName="",ScriptName="npc_panicked_citizen_gate" where entry=44086; 
-- npc 34864
update creature_template set AIName="",ScriptName="npc_gilneas_city_guard_gate" where entry=34864; 

-- npc 34913
update creature_template set AIName="",ScriptName="npc_prince_liam_greymane_phase_1" where entry=34913; 






