
UPDATE quest_template SET Method=2,PrevQuestId=25724,Flags=524288,SpecialFlags=4 WHERE Id=313;
UPDATE quest_template SET Method=2,PrevQuestId=313,Flags=524288,SpecialFlags=4 WHERE Id=25792;
UPDATE quest_template SET Method=2,Flags=524296,SpecialFlags=4 WHERE Id=308;
UPDATE quest_template SET PrevQuestId=318 WHERE Id=415;
UPDATE quest_template SET PrevQuestId=24493,Flags=524288,SpecialFlags=4 WHERE Id=6387;
UPDATE quest_template SET PrevQuestId=24493 WHERE Id in (308,310,315,384,400,25667,25668);
UPDATE quest_template SET PrevQuestId=25667 WHERE Id=25724;
UPDATE quest_template SET PrevQuestId=25792 WHERE Id=25838;
UPDATE quest_template SET PrevQuestId=25838 WHERE Id=291;
UPDATE quest_template SET PrevQuestId=25724 WHERE Id=412;
UPDATE quest_template SET PrevQuestId=25724 WHERE Id=317;