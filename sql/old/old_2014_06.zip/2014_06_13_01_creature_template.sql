
UPDATE creature_template SET questItem1=49748 WHERE entry=704;
UPDATE creature_template SET questItem1=49747 WHERE entry=708;
