
delete from spell_script_names where spell_id=51755;
insert into spell_script_names values
(51755, "spell_hun_camouflage_visual");

delete from spell_script_names where spell_id=42103;
insert into spell_script_names values
(42103, "npc_captain_taylor_42103");

delete from spell_script_names where spell_id IN (42021, 42022);
insert into spell_script_names values
(42021, "npc_stormwind_soldier_42021"),
(42022, "npc_stormwind_soldier_42021");




