
DELETE FROM creature_addon WHERE guid=126070;
DELETE FROM creature_addon WHERE guid=126099;
DELETE FROM creature_addon WHERE guid=126191;
DELETE FROM creature_addon WHERE guid=126231;
DELETE FROM creature_addon WHERE guid=109823;
DELETE FROM creature_addon WHERE guid=109838;
DELETE FROM creature_addon WHERE guid=109863;
DELETE FROM creature_addon WHERE guid=109873;
DELETE FROM creature_addon WHERE guid=109915;
DELETE FROM creature_addon WHERE guid=109933;
DELETE FROM creature_addon WHERE guid=109966;
DELETE FROM creature_addon WHERE guid=109974;
DELETE FROM creature_addon WHERE guid=109981;
DELETE FROM creature_addon WHERE guid=110019;
DELETE FROM creature_addon WHERE guid=110063;
DELETE FROM creature_addon WHERE guid=110091;
DELETE FROM creature_addon WHERE guid=110107;
DELETE FROM creature_addon WHERE guid=110118;
DELETE FROM creature_addon WHERE guid=110145;
DELETE FROM creature_addon WHERE guid=110150;
DELETE FROM creature_addon WHERE guid=110170;
DELETE FROM creature_addon WHERE guid=110259;
DELETE FROM creature_addon WHERE guid=110262;

