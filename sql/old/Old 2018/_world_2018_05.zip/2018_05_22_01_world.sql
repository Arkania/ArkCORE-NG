
UPDATE quest_template SET PrevQuestId=13518 WHERE id=13521;

UPDATE quest_template SET PrevQuestId=13518 WHERE id=13520;

UPDATE quest_template SET PrevQuestId=13518 WHERE id=13537;

UPDATE quest_template SET PrevQuestId=13569 WHERE id=13567;

UPDATE quest_template SET PrevQuestId=13569 WHERE id=13568;

UPDATE quest_template SET PrevQuestId=13569 WHERE id=13597;

UPDATE quest_template SET PrevQuestId=13564 WHERE id=13565;

UPDATE quest_template SET PrevQuestId=13564 WHERE id=13566;

UPDATE quest_template SET PrevQuestId=13564 WHERE id=13598;

UPDATE quest_template SET PrevQuestId=13554 WHERE id=13564;

UPDATE quest_template SET PrevQuestId=13554 WHERE id=13562;

UPDATE quest_template SET PrevQuestId=13554 WHERE id=13563;

