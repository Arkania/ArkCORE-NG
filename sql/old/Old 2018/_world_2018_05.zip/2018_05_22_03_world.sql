UPDATE quest_template SET PrevQuestId=13589 WHERE id=13504;

UPDATE quest_template SET PrevQuestId=13589 WHERE id=13505;

UPDATE quest_template SET PrevQuestId=13505 WHERE id=13507;

UPDATE quest_template SET PrevQuestId=13508 WHERE id=13510;

UPDATE quest_template SET PrevQuestId=13507 WHERE id=13512;

UPDATE quest_template SET PrevQuestId=13507 WHERE id=13513;

UPDATE quest_template SET PrevQuestId=13590 WHERE id=13514;

UPDATE quest_template SET PrevQuestId=13591 WHERE id=13519;

UPDATE quest_template SET PrevQuestId=13591 WHERE id=13570;

UPDATE quest_template SET PrevQuestId=13544 WHERE id=13572;

UPDATE quest_template SET PrevQuestId=13582 WHERE id=13583;

UPDATE quest_template SET PrevQuestId=13513 WHERE id=13590;

UPDATE quest_template SET PrevQuestId=13591 WHERE id=13596;

UPDATE quest_template SET PrevQuestId=13569 WHERE id=13599;

UPDATE quest_template SET PrevQuestId=13519 WHERE id=13601;

UPDATE quest_template SET NextQuestId=13895 WHERE id=13893;

UPDATE quest_template SET PrevQuestId=13948 WHERE id=13896;

UPDATE quest_template SET PrevQuestId=13900 WHERE id=13897;

UPDATE quest_template SET PrevQuestId=13588 WHERE id=13902;

UPDATE quest_template SET PrevQuestId=13895 WHERE id=13953;

UPDATE quest_template SET PrevQuestId=13897 WHERE id=26408;

