-- Add furbolg creatures to kill count for quest 27994  (Felwood, Emerald sanctuary)
UPDATE creature_template SET KillCredit1=47329 WHERE entry=7153 OR entry=7154 OR entry=7155 OR entry=14342;