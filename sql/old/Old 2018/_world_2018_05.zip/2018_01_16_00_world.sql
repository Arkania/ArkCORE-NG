
DELETE FROM npc_spellclick_spells WHERE npc_entry=37598 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(37598, 46598, 0, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=37599 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(37599, 46598, 0, 0); 

