
DELETE FROM creature_queststarter WHERE id=17555 AND quest=9605; 


