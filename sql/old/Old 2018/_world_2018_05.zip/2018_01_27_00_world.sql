
DELETE FROM npc_spellclick_spells WHERE npc_entry=48341 AND spell_id=89908; 
INSERT INTO npc_spellclick_spells VALUES 
(48341, 89908, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=48342 AND spell_id=89908; 
INSERT INTO npc_spellclick_spells VALUES 
(48342, 89908, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=48343 AND spell_id=89908; 
INSERT INTO npc_spellclick_spells VALUES 
(48343, 89908, 1, 0); 

delete from creature_template where entry in (3683902, 3683903);

DELETE FROM npc_spellclick_spells WHERE npc_entry=27587 AND spell_id=49078; 
INSERT INTO npc_spellclick_spells VALUES 
(27587, 49078, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=28192 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(28192, 46598, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=29351 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29351, 46598, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=29358 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29358, 46598, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=35427 AND spell_id=43671; 
INSERT INTO npc_spellclick_spells VALUES 
(35427, 43671, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=36283 AND spell_id=69434; 
INSERT INTO npc_spellclick_spells VALUES 
(36283, 69434, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=36440 AND spell_id=68735; 
INSERT INTO npc_spellclick_spells VALUES 
(36440, 68735, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=48526 AND spell_id=70075; 
INSERT INTO npc_spellclick_spells VALUES 
(48526, 70075, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=37680 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(37680, 46598, 1, 0); 

DELETE FROM npc_spellclick_spells WHERE npc_entry=32627 AND spell_id IN (46598, 60968); 
INSERT INTO npc_spellclick_spells VALUES 
(32627, 46598, 1, 0), 
(32627, 60968, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=32930 AND spell_id=65343; 
INSERT INTO npc_spellclick_spells VALUES 
(32930, 65343, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33109 AND spell_id=62309; 
INSERT INTO npc_spellclick_spells VALUES 
(33109, 62309, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33060 AND spell_id=65031; 
INSERT INTO npc_spellclick_spells VALUES 
(33060, 65031, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33113 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(33113, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=36678 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(36678, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33214 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(33214, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35637 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35637, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35633 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35633, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35768 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35768, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=34658 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(34658, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35636 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35636, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35638 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35638, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35635 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35635, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35640 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35640, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35641 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35641, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35634 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35634, 46598, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=27661 AND spell_id=48365; 
INSERT INTO npc_spellclick_spells VALUES 
(27661, 48365, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29698 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29698, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33778 AND spell_id=43671; 
INSERT INTO npc_spellclick_spells VALUES 
(33778, 43671, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=32633 AND spell_id=61424; 
INSERT INTO npc_spellclick_spells VALUES 
(32633, 61424, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33669 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(33669, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28054 AND spell_id=50556; 
INSERT INTO npc_spellclick_spells VALUES 
(28054, 50556, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33414 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33414, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33301 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33301, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33408 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33408, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33300 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33300, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33409 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33409, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33418 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33418, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33299 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33299, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33318 AND spell_id=63151; 
INSERT INTO npc_spellclick_spells VALUES 
(33318, 63151, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33217 AND spell_id=63151; 
INSERT INTO npc_spellclick_spells VALUES 
(33217, 63151, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33322 AND spell_id=63151; 
INSERT INTO npc_spellclick_spells VALUES 
(33322, 63151, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33320 AND spell_id=63151; 
INSERT INTO npc_spellclick_spells VALUES 
(33320, 63151, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33323 AND spell_id=63151; 
INSERT INTO npc_spellclick_spells VALUES 
(33323, 63151, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33297 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33297, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33416 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33416, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33298 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(33298, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=30234 AND spell_id=61421; 
INSERT INTO npc_spellclick_spells VALUES 
(30234, 61421, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=30248 AND spell_id=61421; 
INSERT INTO npc_spellclick_spells VALUES 
(30248, 61421, 0, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=36891 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(36891, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=38500 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(38500, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=27626 AND spell_id=49138; 
INSERT INTO npc_spellclick_spells VALUES 
(27626, 49138, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28009 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(28009, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=30204 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(30204, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29351 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29351, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=30174 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(30174, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29460 AND spell_id=54513; 
INSERT INTO npc_spellclick_spells VALUES 
(29460, 54513, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29500 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29500, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=25968 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(25968, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=38431 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(38431, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=38585 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(38585, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=38586 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(38586, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29863 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29863, 46598, 0, 1);

DELETE FROM npc_spellclick_spells WHERE npc_entry=39860 AND spell_id=47020; 
INSERT INTO npc_spellclick_spells VALUES 
(39860, 47020, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=36896 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(36896, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=36794 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(36794, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29931 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29931, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=36661 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(36661, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=36476 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(36476, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=37968 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(37968, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33293 AND spell_id=63852; 
INSERT INTO npc_spellclick_spells VALUES 
(33293, 63852, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29838 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29838, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=31262 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(31262, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=31406 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(31406, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=31583 AND spell_id=59319; 
INSERT INTO npc_spellclick_spells VALUES 
(31583, 59319, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=31881 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(31881, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=31884 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(31884, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=32225 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(32225, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=32227 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(32227, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=32490 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(32490, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=32344 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(32344, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=27761 AND spell_id=43671; 
INSERT INTO npc_spellclick_spells VALUES 
(27761, 43671, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=24083 AND spell_id=55074; 
INSERT INTO npc_spellclick_spells VALUES 
(24083, 55074, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33114 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(33114, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35069 AND spell_id IN (46598, 66245); 
INSERT INTO npc_spellclick_spells VALUES 
(35069, 66245, 1, 0), 
(35069, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=34776 AND spell_id IN (46598, 66245); 
INSERT INTO npc_spellclick_spells VALUES 
(34776, 46598, 1, 0), 
(34776, 66245, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=53786 AND spell_id=98509; 
INSERT INTO npc_spellclick_spells VALUES 
(53786, 98509, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28710 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(28710, 46598, 1, 1);

DELETE FROM npc_spellclick_spells WHERE npc_entry=33109 AND spell_id=62309; 
INSERT INTO npc_spellclick_spells VALUES 
(33109, 62309, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=35299 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(35299, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=36283 AND spell_id=69434; 
INSERT INTO npc_spellclick_spells VALUES 
(36283, 69434, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=28669 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(28669, 46598, 0, 1);

DELETE FROM npc_spellclick_spells WHERE npc_entry=52363 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(52363, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=27587 AND spell_id=49078; 
INSERT INTO npc_spellclick_spells VALUES 
(27587, 49078, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=29358 AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(29358, 46598, 1, 0);

DELETE FROM npc_spellclick_spells WHERE npc_entry=30013 AND spell_id=43671; 
INSERT INTO npc_spellclick_spells VALUES 
(30013, 43671, 1, 0);

Update locales_creature set name_loc3="Wachwindreiter" where entry=34160;

DELETE FROM npc_spellclick_spells WHERE npc_entry IN (13210, 17804, 2041, 4262, 2500, 25049, 43259) AND spell_id=46598; 
DELETE FROM npc_spellclick_spells WHERE npc_entry IN (45942, 52385, 55914, 40573, 42399, 42400, 34160) AND spell_id=46598; 
INSERT INTO npc_spellclick_spells VALUES 
(13210, 46598, 1, 0),
(17804, 46598, 1, 0),
(2041, 46598, 1, 0),
(4262, 46598, 1, 0),
(2500, 46598, 1, 0),
(25049, 46598, 1, 0),
(43259, 46598, 1, 0),
(45942, 46598, 1, 0),
(52385, 46598, 1, 0),
(55914, 46598, 1, 0),
(40573, 46598, 1, 0),
(42399, 46598, 1, 0),
(42400, 46598, 1, 0),
(34160, 46598, 1, 0);



