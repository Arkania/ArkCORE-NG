
UPDATE creature_template SET AIName="", ScriptName="npc_lorna_crowley_phase8" WHERE entry=35378;
UPDATE creature_template SET AIName="", ScriptName="npc_gilneas_mastiff_phase8" WHERE entry=35631;
UPDATE creature_template SET AIName="", ScriptName="npc_bloodfang_lurker_phase8" WHERE entry=35463;
UPDATE creature_template SET AIName="", ScriptName="npc_gilneas_city_guard_phase8" WHERE entry=50474;



