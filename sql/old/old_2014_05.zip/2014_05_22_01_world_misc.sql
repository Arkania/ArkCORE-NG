
UPDATE creature_template SET AIName="",ScriptName="npc_lord_darius_crowley_phase8" WHERE entry=35552;
UPDATE creature_template SET AIName="",ScriptName="npc_king_genn_greymane2_phase8" WHERE entry=35911;



