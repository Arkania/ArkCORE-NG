-- Sinestra
DELETE FROM `creature_text` WHERE `entry`=45213 AND `groupid`>4;
INSERT INTO `creature_text`(`entry`,`groupid`,`id`,`type`,`sound`,`probability`,`comment`,`text`) VALUES
(45213,5,0,14,20209,100,'Sinestra','SUFFER!'),
(45213,5,1,14,20210,100,'Sinestra','FEEL MY HATRED!'),
(45213,6,0,14,20204,100,'Sinestra','I tire of this! Do you see this clutch amidst which you stand? I have nurtured the spark within them, but that lifeforce is, and always will be, MINE! Behold... power beyond your comprehension!'),
(45213,7,0,14,20206,100,'Sinestra','Enough! Drawing upon this source will set us back months... you should feel honored to be worthy of this expenditure! NOW DIE!'),
(45213,8,0,14,20203,100,'Sinestra','You mistake this for weakness? FOOL!'),
(45213,9,0,14,20205,100,'Sinestra','This will be your tomb as well as theirs!'),
(45213,10,0,14,20213,100,'Sinestra','My brood will feast upon your essence!'),
(45213,11,0,14,20200,100,'Sinestra','Deathwing... I have fallen... the brood... is lost...'),
(45213,12,0,14,20211,100,'Sinestra','Come forth children of Twilight!'),
(45213,13,0,14,20212,100,'Sinestra','YOUR MOTHER CALLS!'),
(45213,14,0,41,0,100,'Sinestra','Twilight Slicers are active!');
