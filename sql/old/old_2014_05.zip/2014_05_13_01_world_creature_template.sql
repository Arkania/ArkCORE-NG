UPDATE creature_template SET AIName='',ScriptName='npc_unstable_pyrelord' WHERE entry=53630;
UPDATE creature_template SET AIName='',ScriptName='npc_kar_the_everburning' WHERE entry=53616;