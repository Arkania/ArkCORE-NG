
UPDATE creature_template SET equipment_id=35378 WHERE entry=35378;

