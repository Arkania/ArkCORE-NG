
update creature_template set AIName="", ScriptName="" where entry in (918, 3328, 4163, 4583, 5165, 5167, 13283, 16684);

update creature_template set AIName="", ScriptName="npc_generic_harpoon_cannon" where entry in (27717, 30066, 30337);

update creature_template set AIName="", ScriptName="npc_mushroom" where entry=47649;

update creature_template set AIName="", ScriptName="npc_t12_fiery_imp" where entry=53491;

  
