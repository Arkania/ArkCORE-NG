

UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Kehrt zu Mull Donnerhorn im Dorf der Bluthufe zurück." WHERE Id=24441;

UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Kehrt zu Morin Wolkenpirscher in Mulgore zurück." WHERE Id=26180;

UPDATE locales_quest SET QuestGiverTextWindow_loc3="Eindringling der Borstennacken", QuestGiverTargetName_loc3="Borstennacken" WHERE Id=833;

update gossip_menu_option set option_id=3, npc_option_npcflag=128, OptionBroadcastTextID=2823 where menu_id=24 and id=1;

