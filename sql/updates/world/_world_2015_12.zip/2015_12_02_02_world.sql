
update creature_template set AIName="", Scriptname="npc_fez_34543" where entry=34543;
update creature_template set AIName="", Scriptname="" where entry=34544;

