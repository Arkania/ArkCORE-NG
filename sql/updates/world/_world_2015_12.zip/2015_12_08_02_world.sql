
-- banner is spawned from script
delete from gameobject where guid=183493 and id=195148;


