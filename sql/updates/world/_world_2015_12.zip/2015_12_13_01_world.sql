
-- https://cata-twinhead.twinstar.cz/?npc=49869
UPDATE creature_template SET mindmg=24, maxdmg=50, attackpower=100, rangeattacktime=2000, minrangedmg=16, maxrangedmg=24 WHERE entry=49869;


