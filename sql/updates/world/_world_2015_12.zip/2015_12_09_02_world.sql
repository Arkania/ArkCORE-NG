
-- spawned from script
delete from creature where id=41068 and guid=112607;
