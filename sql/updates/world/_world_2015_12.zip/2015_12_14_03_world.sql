
UPDATE quest_template SET Method=2 WHERE Id=26226;

