

delete from spell_script_names where spell_id=84617 and ScriptName="spell_rog_revealing_strike";
insert into spell_script_names values
(84617, "spell_rog_revealing_strike");

delete from spell_script_names where spell_id=53 and ScriptName="spell_rog_backstab";
insert into spell_script_names values
(53, "spell_rog_backstab");

delete from spell_script_names where spell_id=6770 and ScriptName="spell_rog_sap";
insert into spell_script_names values
(6770, "spell_rog_sap");

delete from spell_script_names where spell_id=1776 and ScriptName="spell_rog_gouge";
insert into spell_script_names values
(1776, "spell_rog_gouge");

delete from spell_script_names where spell_id=2094 and ScriptName="spell_rog_blind";
insert into spell_script_names values
(2094, "spell_rog_blind");
 
delete from spell_script_names where spell_id=76577 and ScriptName="spell_rog_smoke_bomb_inv";
insert into spell_script_names values
(76577, "spell_rog_smoke_bomb_inv");

delete from spell_script_names where spell_id in (51625, 51626) and ScriptName="spell_rog_deadly_brew";
insert into spell_script_names values
(51625, "spell_rog_deadly_brew"),
(51626, "spell_rog_deadly_brew"); 
 
delete from spell_script_names where spell_id=84590 and ScriptName="spell_rog_deadly_momentum";
insert into spell_script_names values
(84590, "spell_rog_deadly_momentum");
 
delete from spell_script_names where spell_id=2098 and ScriptName="spell_rog_eviscerate";
insert into spell_script_names values
(2098, "spell_rog_eviscerate"); 
 
delete from spell_script_names where spell_id=73981 and ScriptName="spell_rog_redirect";
insert into spell_script_names values
(73981, "spell_rog_redirect");  	

delete from spell_script_names where spell_id=56807 and ScriptName="spell_rog_glyph_of_hemorrhage";
insert into spell_script_names values
(56807, "spell_rog_glyph_of_hemorrhage");  

delete from spell_script_names where spell_id in (79095, 79096) and ScriptName="spell_rog_restless_blades";
insert into spell_script_names values
(79095, "spell_rog_restless_blades"),
(79096, "spell_rog_restless_blades"); 	




	
	
	
	
	
	
	
	