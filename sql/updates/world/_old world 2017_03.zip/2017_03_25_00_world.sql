
-- fix for Aliance quest=27239

UPDATE `quest_template` SET `Method`=2,`Flags`=16394,`SpecialFlags`=2 WHERE `Id`=27239;

