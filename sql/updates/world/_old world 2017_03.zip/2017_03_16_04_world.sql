

-- fix issue #240 - 2
UPDATE quest_template SET PrevQuestID = 26286 WHERE id=26289;
UPDATE quest_template SET PrevQuestID = 26291 WHERE id=26292;


