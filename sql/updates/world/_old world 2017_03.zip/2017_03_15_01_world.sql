
REPLACE INTO gameobject_loot_template VALUES (202655, 63115, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 63118, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 63120, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 63412, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 63413, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 63523, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 63524, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 64345, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 64346, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 64347, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 64348, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 64374, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 64375, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 64377, 0, 0.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (202655, 66058, 0, 6.8, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 63129, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 63130, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 63131, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 63407, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 63525, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 63526, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 63528, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64354, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64356, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64357, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64358, 0, 2, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64361, 0, 2, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64378, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64379, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64381, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64382, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64383, 0, 2, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64643, 0, 0.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64645, 0, 0.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64646, 0, 0.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64647, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64648, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64650, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 64651, 0, 0.5, 0, 1, 1, 1, 1, "");

REPLACE INTO gameobject_loot_template VALUES (203071, 66055, 0, 4.5, 0, 1, 1, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (603, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (4412, 5959, 0, 25, 1, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (4979, 16885, 0, 8.3333, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (6006, 16885, 0, 0.0028, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (7023, 8053, 0, 100, 1, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (8523, 16885, 0, 0.0049, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (9198, 16885, 0, 0.0145, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (9956, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (10199, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (10827, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (10940, 16885, 0, 10, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (10987, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (10991, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (11355, 16885, 0, 0.0132, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (11440, 16885, 0, 0.0161, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (11443, 16885, 0, 0.004, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (11602, 16885, 0, 9.5238, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (11604, 16885, 0, 62.5, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (11657, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (12396, 16885, 0, 0.2004, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (13088, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (13216, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (13447, 16885, 0, 100, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (25863, 2589, 0, 19.1295, 0, 1, 0, 1, 3, "");

REPLACE INTO creature_loot_template VALUES (25863, 2592, 0, 18.954, 0, 1, 0, 1, 2, "");

REPLACE INTO creature_loot_template VALUES (25863, 2698, 0, 0.0527, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (25866, 2589, 0, 19.5074, 0, 1, 0, 1, 3, "");

REPLACE INTO creature_loot_template VALUES (25866, 2592, 0, 20.1678, 0, 1, 0, 1, 2, "");

REPLACE INTO creature_loot_template VALUES (25866, 2698, 0, 0.0714, 0, 1, 0, 1, 1, "");

REPLACE INTO creature_loot_template VALUES (25924, 2589, 0, 22.5296, 0, 1, 0, 1, 3, "");

REPLACE INTO creature_loot_template VALUES (25924, 2592, 0, 20.9486, 0, 1, 0, 1, 2, "");


