
delete from fishing_loot_template where entry=168 and item in (858, 3385, 6289, 6291, 6308, 6309, 6310, 6311, 6363, 6364, 6645, 8350);
