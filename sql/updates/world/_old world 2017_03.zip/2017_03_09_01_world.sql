
delete from gameobject where guid in (184393, 184394, 184400, 184401, 184395, 184396, 184397, 184398, 184399);



			