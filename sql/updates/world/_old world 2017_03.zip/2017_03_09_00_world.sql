
delete from spell_script_names where spell_id=498;
INSERT INTO spell_script_names (spell_id, ScriptName) VALUES 
(498, 'spell_pal_divine_protection_498');

