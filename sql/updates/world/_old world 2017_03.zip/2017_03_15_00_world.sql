

delete from spell_loot_template where Entry=60445 and item in (43722, 43723, 43646);	

insert into spell_loot_template values 
(60445, 43646, 0, 64, 0, 1, 0, 1, 1, "");

update spell_loot_template set Chance=36 where Entry=60445 and item=11025;

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=3210;

INSERT INTO reference_loot_template VALUES 
(11004, 3210, 0, 0.01, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=3820;

INSERT INTO reference_loot_template VALUES 
(11004, 3820, 0, 0.9, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=4712;

INSERT INTO reference_loot_template VALUES 
(11004, 4712, 0, 0.01, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6291;

INSERT INTO reference_loot_template VALUES 
(11004, 6291, 0, 0.3, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6307;

INSERT INTO reference_loot_template VALUES 
(11004, 6307, 0, 0.05, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6309;

INSERT INTO reference_loot_template VALUES 
(11004, 6309, 0, 0.11, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6352;

INSERT INTO reference_loot_template VALUES 
(11004, 6352, 0, 0.05, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6354;

INSERT INTO reference_loot_template VALUES 
(11004, 6354, 0, 0.06, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6358;

INSERT INTO reference_loot_template VALUES 
(11004, 6358, 0, 6, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6359;

INSERT INTO reference_loot_template VALUES 
(11004, 6359, 0, 2, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6360;

INSERT INTO reference_loot_template VALUES 
(11004, 6360, 0, 0.01, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6361;

INSERT INTO reference_loot_template VALUES 
(11004, 6361, 0, 6, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=6362;

INSERT INTO reference_loot_template VALUES 
(11004, 6362, 0, 0.01, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=21071;

INSERT INTO reference_loot_template VALUES 
(11004, 21071, 0, 14, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=21113;

INSERT INTO reference_loot_template VALUES 
(11004, 21113, 0, 1.2, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=21114;

INSERT INTO reference_loot_template VALUES 
(11004, 21114, 0, 0.4, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=21150;

INSERT INTO reference_loot_template VALUES 
(11004, 21150, 0, 0.5, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=21151;

INSERT INTO reference_loot_template VALUES 
(11004, 21151, 0, 0.12, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45188;

INSERT INTO reference_loot_template VALUES 
(11004, 45188, 0, 0.2, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45189;

INSERT INTO reference_loot_template VALUES 
(11004, 45189, 0, 0.18, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45190;

INSERT INTO reference_loot_template VALUES 
(11004, 45190, 0, 0.9, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45191;

INSERT INTO reference_loot_template VALUES 
(11004, 45191, 0, 0.18, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45194;

INSERT INTO reference_loot_template VALUES 
(11004, 45194, 0, 0.8, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45195;

INSERT INTO reference_loot_template VALUES 
(11004, 45195, 0, 0.19, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45196;

INSERT INTO reference_loot_template VALUES 
(11004, 45196, 0, 0.7, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45197;

INSERT INTO reference_loot_template VALUES 
(11004, 45197, 0, 0.01, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45198;

INSERT INTO reference_loot_template VALUES 
(11004, 45198, 0, 0.7, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45199;

INSERT INTO reference_loot_template VALUES 
(11004, 45199, 0, 0.04, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45200;

INSERT INTO reference_loot_template VALUES 
(11004, 45200, 0, 0.7, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45201;

INSERT INTO reference_loot_template VALUES 
(11004, 45201, 0, 0.01, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11004 AND Item=45202;

INSERT INTO reference_loot_template VALUES 
(11004, 45202, 0, 0.03, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=33567;

INSERT INTO reference_loot_template VALUES 
(11022, 33567, 0, 0.02, 0, 1, 0, 3, 4, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45190;

INSERT INTO reference_loot_template VALUES 
(11022, 45190, 0, 3, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45194;

INSERT INTO reference_loot_template VALUES 
(11022, 45194, 0, 3, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45195;

INSERT INTO reference_loot_template VALUES 
(11022, 45195, 0, 0.06, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45196;

INSERT INTO reference_loot_template VALUES 
(11022, 45196, 0, 3, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45197;

INSERT INTO reference_loot_template VALUES 
(11022, 45197, 0, 0.06, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45198;

INSERT INTO reference_loot_template VALUES 
(11022, 45198, 0, 3, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45199;

INSERT INTO reference_loot_template VALUES 
(11022, 45199, 0, 0.06, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45200;

INSERT INTO reference_loot_template VALUES 
(11022, 45200, 0, 3, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45201;

INSERT INTO reference_loot_template VALUES 
(11022, 45201, 0, 0.06, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45202;

INSERT INTO reference_loot_template VALUES 
(11022, 45202, 0, 0.06, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=45902;

INSERT INTO reference_loot_template VALUES 
(11022, 45902, 0, 4, 1, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=46109;

INSERT INTO reference_loot_template VALUES 
(11022, 46109, 0, 0.02, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11022 AND Item=50289;

INSERT INTO reference_loot_template VALUES 
(11022, 50289, 0, 0.02, 0, 1, 0, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=22739;

INSERT INTO reference_loot_template VALUES 
(11050, 22739, 0, 0.02, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=45188;

INSERT INTO reference_loot_template VALUES 
(11050, 45188, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=45189;

INSERT INTO reference_loot_template VALUES 
(11050, 45189, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=45190;

INSERT INTO reference_loot_template VALUES 
(11050, 45190, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=45191;

INSERT INTO reference_loot_template VALUES 
(11050, 45191, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=45194;

INSERT INTO reference_loot_template VALUES 
(11050, 45194, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=45195;

INSERT INTO reference_loot_template VALUES 
(11050, 45195, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=45196;

INSERT INTO reference_loot_template VALUES 
(11050, 45196, 0, 0.2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=46109;

INSERT INTO reference_loot_template VALUES 
(11050, 46109, 0, 0.02, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=52326;

INSERT INTO reference_loot_template VALUES 
(11050, 52326, 0, 10, 0, 1, 1, 1, 3, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=52985;

INSERT INTO reference_loot_template VALUES 
(11050, 52985, 0, 4, 0, 1, 1, 1, 2, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=53069;

INSERT INTO reference_loot_template VALUES 
(11050, 53069, 0, 15, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=53070;

INSERT INTO reference_loot_template VALUES 
(11050, 53070, 0, 38.7, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=53071;

INSERT INTO reference_loot_template VALUES 
(11050, 53071, 0, 4, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=53072;

INSERT INTO reference_loot_template VALUES 
(11050, 53072, 0, 8, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11050 AND Item=67597;

INSERT INTO reference_loot_template VALUES 
(11050, 67597, 0, 8, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=22739;

INSERT INTO reference_loot_template VALUES 
(11051, 22739, 0, 0.02, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=45188;

INSERT INTO reference_loot_template VALUES 
(11051, 45188, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=45189;

INSERT INTO reference_loot_template VALUES 
(11051, 45189, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=45190;

INSERT INTO reference_loot_template VALUES 
(11051, 45190, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=45191;

INSERT INTO reference_loot_template VALUES 
(11051, 45191, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=45194;

INSERT INTO reference_loot_template VALUES 
(11051, 45194, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=45195;

INSERT INTO reference_loot_template VALUES 
(11051, 45195, 0, 2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=45196;

INSERT INTO reference_loot_template VALUES 
(11051, 45196, 0, 0.2, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=46109;

INSERT INTO reference_loot_template VALUES 
(11051, 46109, 0, 0.02, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=52326;

INSERT INTO reference_loot_template VALUES 
(11051, 52326, 0, 5, 0, 1, 1, 1, 3, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=52985;

INSERT INTO reference_loot_template VALUES 
(11051, 52985, 0, 4, 0, 1, 1, 1, 2, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=53069;

INSERT INTO reference_loot_template VALUES 
(11051, 53069, 0, 30, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=53071;

INSERT INTO reference_loot_template VALUES 
(11051, 53071, 0, 15, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=11051 AND Item=53072;

INSERT INTO reference_loot_template VALUES 
(11051, 53072, 0, 30, 0, 1, 1, 1, 1, "");

DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59221;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59223;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59224;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59225;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59233;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59234;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59310;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59311;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59313;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59314;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59329;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59340;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59355;
DELETE FROM reference_loot_template WHERE Entry=43296 AND Item=59451;

