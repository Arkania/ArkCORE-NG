
-- fix issue #240
UPDATE quest_template SET PrevQuestID = 26209 WHERE id=26213;
UPDATE quest_template SET PrevQuestID = 26209 WHERE id=26214;

