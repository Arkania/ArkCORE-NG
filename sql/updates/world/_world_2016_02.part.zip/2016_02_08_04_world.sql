
update creature set spawndist=0, MovementType=0 where guid in (104952, 104964);
