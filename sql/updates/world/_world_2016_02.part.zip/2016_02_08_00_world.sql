
-- boss_darkmaster_gandling spawns from script
delete from creature where guid=151643 and id=1853;
