
-- spell wild mushroom
update creature_template set AIName="", ScriptName="npc_mushroom_47649" where entry = 47649;
update creature_template set AIName="", ScriptName="npc_mushroom_43497" where entry = 43497;

