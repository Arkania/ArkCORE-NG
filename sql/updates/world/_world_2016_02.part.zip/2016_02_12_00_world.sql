

DELETE FROM spell_area WHERE spell=86749 AND area=980 AND quest_start=28557;
INSERT INTO spell_area (spell, area, quest_start, quest_end, aura_spell, racemask, gender, autocast, quest_start_status, quest_end_status) VALUES 
(86749, 980, 28557, 27003, 0, 946, 2, 1, 74, 1);

DELETE FROM spell_area WHERE spell=86749 AND area=980 AND quest_start=28558;
INSERT INTO spell_area (spell, area, quest_start, quest_end, aura_spell, racemask, gender, autocast, quest_start_status, quest_end_status) VALUES 
(86749, 980, 28558, 27003, 0, 2098253, 2, 1, 74, 1);

DELETE FROM spell_area WHERE spell=86749 AND area=980 AND quest_start=28295;
INSERT INTO spell_area (spell, area, quest_start, quest_end, aura_spell, racemask, gender, autocast, quest_start_status, quest_end_status) VALUES 
(86749, 980, 28295, 27003, 0, 2098253, 2, 1, 74, 1);

DELETE FROM spell_area WHERE spell=86749 AND area=980 AND quest_start=28296;
INSERT INTO spell_area (spell, area, quest_start, quest_end, aura_spell, racemask, gender, autocast, quest_start_status, quest_end_status) VALUES 
(86749, 980, 28296, 27003, 0, 946, 2, 1, 74, 1);

DELETE FROM spell_area WHERE spell=89521 AND area=980 AND quest_start=28557;
INSERT INTO spell_area (spell, area, quest_start, quest_end, aura_spell, racemask, gender, autocast, quest_start_status, quest_end_status) VALUES 
(89521, 980, 28557, 27003, 0, 946, 2, 1, 74, 1);

DELETE FROM spell_area WHERE spell=89521 AND area=980 AND quest_start=28558;
INSERT INTO spell_area (spell, area, quest_start, quest_end, aura_spell, racemask, gender, autocast, quest_start_status, quest_end_status) VALUES 
(89521, 980, 28558, 27003, 0, 2098253, 2, 1, 74, 1);

DELETE FROM spell_area WHERE spell=89521 AND area=980 AND quest_start=28295;
INSERT INTO spell_area (spell, area, quest_start, quest_end, aura_spell, racemask, gender, autocast, quest_start_status, quest_end_status) VALUES 
(89521, 980, 28295, 27003, 0, 2098253, 2, 1, 74, 1);

DELETE FROM spell_area WHERE spell=89521 AND area=980 AND quest_start=28296;
INSERT INTO spell_area (spell, area, quest_start, quest_end, aura_spell, racemask, gender, autocast, quest_start_status, quest_end_status) VALUES 
(89521, 980, 28296, 27003, 0, 946, 2, 1, 74, 1);
