

-- there is no reference in reference_loot_template with value of => 200000
DELETE FROM npc_trainer WHERE spell < -200000;

