

DELETE FROM creature_addon WHERE guid=83015;
DELETE FROM creature_addon WHERE guid=83181;
DELETE FROM creature_addon WHERE guid=83366;
DELETE FROM creature_addon WHERE guid=83376;
DELETE FROM creature_addon WHERE guid=83549;
DELETE FROM creature_addon WHERE guid=91855;

UPDATE quest_template SET ExclusiveGroup=918 WHERE id=918;

UPDATE quest_template SET ExclusiveGroup=918 WHERE id=919;

