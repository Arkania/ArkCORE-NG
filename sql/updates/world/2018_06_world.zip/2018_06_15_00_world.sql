
DELETE FROM creature WHERE guid=83015;

DELETE FROM creature WHERE guid=83181;

UPDATE creature SET spawndist=4.0 WHERE guid=83290;

DELETE FROM creature WHERE guid=83366;

DELETE FROM creature WHERE guid=83376;

DELETE FROM creature WHERE guid=83549;

DELETE FROM creature WHERE guid=91855;

UPDATE creature SET spawntimesecs=500, spawndist=5.0, MovementType=1 WHERE guid=83270;

UPDATE creature SET spawndist=7.0 WHERE guid=109301;

UPDATE quest_template SET PrevQuestId=918 WHERE id=7383;





