
UPDATE locales_quest SET OfferRewardText_loc3="Ihr habt uns ein wenig Zeit verschafft, $N, aber wir haben jetzt ein noch größeres Problem, um das wir uns kümmern müssen.", RequestItemsText_loc3="Habt Ihr die Kampfworgs des Schwarzfels zurückgeschlagen?", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück.", QuestGiverTextWindow_loc3="Dies ist ein Kampfworg des Schwarzfels.", QuestGiverTargetName_loc3="Kampfworg des Schwarzfels" WHERE Id=28762;
UPDATE locales_quest SET OfferRewardText_loc3="Ihr habt uns ein wenig Zeit verschafft, $N, aber wir haben jetzt ein noch größeres Problem, um das wir uns kümmern müssen.", RequestItemsText_loc3="Habt Ihr die Kampfworgs des Schwarzfels zurückgeschlagen?", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück.", QuestGiverTextWindow_loc3="Dies ist ein Kampfworg des Schwarzfels.", QuestGiverTargetName_loc3="Kampfworg des Schwarzfels" WHERE Id=28763;
UPDATE locales_quest SET OfferRewardText_loc3="Ihr habt uns ein wenig Zeit verschafft, $N, aber wir haben jetzt ein noch größeres Problem, um das wir uns kümmern müssen.", RequestItemsText_loc3="Habt Ihr die Kampfworgs des Schwarzfels zurückgeschlagen?", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück." WHERE Id=28766;
UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Ihr habt uns ein wenig Zeit verschafft, $N, aber wir haben jetzt ein noch größeres Problem, um das wir uns kümmern müssen.", RequestItemsText_loc3="Habt Ihr die Kampfworgs des Schwarzfels zurückgeschlagen?", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück.", QuestGiverTextWindow_loc3="Dies ist ein Kampfworg des Schwarzfels.", QuestGiverTargetName_loc3="Kampfworg des Schwarzfels" WHERE Id=28765;
UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Ihr habt uns ein wenig Zeit verschafft, $N, aber wir haben jetzt ein noch größeres Problem, um das wir uns kümmern müssen.", RequestItemsText_loc3="Habt Ihr die Kampfworgs des Schwarzfels zurückgeschlagen?", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück." WHERE Id=28767;
UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Ihr habt uns ein wenig Zeit verschafft, $N, aber wir haben jetzt ein noch größeres Problem, um das wir uns kümmern müssen.", RequestItemsText_loc3="Habt Ihr die Kampfworgs des Schwarzfels zurückgeschlagen?", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück." WHERE Id=29078;
UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück." WHERE Id=28764;







