


UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Kehrt zu Kargal in der Fernwacht im Nördlichen Brachland zurück.", QuestGiverTextWindow_loc3="Stacheleber vom Klingenmäenstamm", QuestGiverTargetName_loc3="Stacheleber vom Klingenmäenstamm" WHERE Id=871;

UPDATE quest_template SET RequiredNpcOrGo2=3265, RequiredNpcOrGo3=0, RequiredNpcOrGoCount2=3, RequiredNpcOrGoCount3=0 WHERE Id=871;


