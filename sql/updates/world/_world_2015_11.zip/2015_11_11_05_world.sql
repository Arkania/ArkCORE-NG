
-- quest 880
delete from creature where guid in (138097, 138097, 84020, 84017, 84010, 84014, 84002, 116094, 138760, 83992, 84015);

update creature set spawndist=10, MovementType=1 where id=3461;

