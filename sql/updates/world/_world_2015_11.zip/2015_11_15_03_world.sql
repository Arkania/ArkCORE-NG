

delete from event_scripts where id=2980;
insert into event_scripts values 
(2980, 0, 10, 3475, 180000, 0, -22.4567, -2387.38, 91.668, 1.372);

