
delete from creature where id=35631 and guid in (26569, 26570, 26571, 26574, 26575, 26576);
