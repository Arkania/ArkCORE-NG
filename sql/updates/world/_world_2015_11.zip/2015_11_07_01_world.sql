
delete from playercreateinfo_spell where spell=79684;
