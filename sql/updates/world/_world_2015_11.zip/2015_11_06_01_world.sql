
delete from playercreateinfo_spell where classmask=128 and spell=168;






