

-- quest  14067
UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Bringt das gestohlene Silber zu Gazrog vor Ratschet im N�rdlichen Brachland." WHERE Id=14067;

-- quest 13999
UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Bringt Helbrims Forschungsergebnisse zu Sashya in Ratschet im N�rdlichen Brachland." WHERE Id=13999;


