

delete from gossip_menu_option where menu_id=4341 and id=1;

update creature_template set maxlevel=7 where entry=3939;

UPDATE creature_template SET questItem1=5085 WHERE entry=3265;
UPDATE creature_template SET questItem1=5085 WHERE entry=3266;
UPDATE creature_template SET questItem2=5085 WHERE entry=3267;
UPDATE creature_template SET questItem2=5085 WHERE entry=3268;
UPDATE creature_template SET questItem2=5085 WHERE entry=3269;
UPDATE creature_template SET questItem2=5085 WHERE entry=3271;

