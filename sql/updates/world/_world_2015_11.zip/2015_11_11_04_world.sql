
-- quest 903

UPDATE creature_template SET questItem2=5096 WHERE entry=3415;
UPDATE creature_template SET spell1=75008, spell2=65884 WHERE entry=3415;

-- todo: some are sleeping, some are walking..



