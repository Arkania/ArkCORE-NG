
update creature set phaseId=0 where phaseId=169;

update gameobject set phaseId=0 where phaseId=169;
