

DELETE FROM game_event_gameobject WHERE guid IN (6207, 6208);

