
-- bonfire in city
UPDATE gameobject_template SET displayId=6756 WHERE entry=188352;
