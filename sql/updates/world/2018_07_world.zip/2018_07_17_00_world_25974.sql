
UPDATE creature_template SET faction=775, AIName="" WHERE entry=25974;
