

DELETE FROM game_event_creature WHERE guid IN (126948);

