

UPDATE creature_template SET AIName="", ScriptName="npc_torch_tossing_target_bunny_25535" WHERE entry=25535;
