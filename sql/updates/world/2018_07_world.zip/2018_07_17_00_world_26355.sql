
-- all Horde/Ally Dummys are mixed
-- npc delete + insert is inside npc 26258

DELETE FROM game_event_creature WHERE guid IN (1305, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1313);

DELETE FROM game_event_creature WHERE guid IN (126964, 126965, 126966, 126968, 126969, 126970, 126971, 126972, 126973, 126974, 126975, 126976);

DELETE FROM game_event_creature WHERE guid IN (161430, 161431, 161432, 161433);
