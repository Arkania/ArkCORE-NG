
delete from creature where id=38531;

delete from creature where id=36471 and guid=285769;

update creature set phaseId=0, phaseGroup=418 where guid=248262;

delete from creature where id=38122 and guid in (283387,283388);

update creature set phaseId=0, phaseGroup=415 where guid=657;

delete from creature where id=38387 and guid in (284427, 284428);

update creature set phaseId=0, phaseGroup=415 where guid=245284;

delete from creature where id=38745 and guid in(285786, 285808, 285772, 285784, 246786, 285809, 285783, 285806);

update creature set phaseId=0, phaseGroup=415 where id=38745 and phaseId between 180 and 182;

delete from creature where id=38514 and guid in (284881, 284882);

update creature set phaseId=0, phaseGroup=415 where guid=245296;

delete from creature where id=38515 and guid in (284883, 284884);

update creature set phaseId=0, phaseGroup=415 where guid=1848;

delete from creature where id=42473 and guid in (282926, 282927);

update creature set phaseId=0, phaseGroup=415 where guid=249595;

delete from creature where id=38517 and guid in (284887, 284888);

update creature set phaseId=0, phaseGroup=415 where guid=1992;

delete from creature where id=38124 and guid=283389;

update creature set phaseId=0, phaseGroup=418 where guid=944;

delete from creature where id=38120 and guid=283386;

update creature set phaseId=0, phaseGroup=418 where guid=1734;

delete from creature where id=38513 and guid in (284879, 284880);

update creature set phaseId=0, phaseGroup=415 where guid=954;

delete from creature where id=38526 and guid in (284894, 284895,249586,249590,249591);

update creature set phaseId=0, phaseGroup=418 where id=38526;

delete from creature where id=38518 and guid in (284889, 284890);

update creature set phaseId=0, phaseGroup=415 where guid=245292;

delete from creature where id=38409 and guid=284447;

delete from creature where id=38511 and guid=284878;

update creature set phaseId=0, phaseGroup=418 where id=38511 and guid=9088;

update creature set phaseId=0, phaseGroup=415 where guid=1774;

UPDATE creature SET position_x=908.517, position_y=2346.17 WHERE guid=1774;

delete from creature where id=38187 and guid in (245317,245343,283909,245315,283933,245347,283903,245338,283915,245324,245332,245331,283941,283945,283883,283910,283918,283907,245325);

delete from creature where id=38187 and guid in (283879,283884,283947,283934,283888,245337,283885,245322,283935,245333,283908,283898,245323,283900,283923,283886,283892,245339,283930);

delete from creature where id=38187 and guid in (283881,283912,283890,283940,283921,283932,283922,283927,245326,283920,245329,283899,283916,283913,245328,245327,283911,283949,283894);

update creature set phaseId=0, phaseGroup=415 where id=38187;

DELETE FROM creature_addon WHERE guid=283879;
DELETE FROM creature_addon WHERE guid=283881;
DELETE FROM creature_addon WHERE guid=283883;
DELETE FROM creature_addon WHERE guid=283884;
DELETE FROM creature_addon WHERE guid=283885;
DELETE FROM creature_addon WHERE guid=283886;
DELETE FROM creature_addon WHERE guid=283888;
DELETE FROM creature_addon WHERE guid=283890;
DELETE FROM creature_addon WHERE guid=283892;
DELETE FROM creature_addon WHERE guid=245317;
DELETE FROM creature_addon WHERE guid=245327;
DELETE FROM creature_addon WHERE guid=283898;
DELETE FROM creature_addon WHERE guid=283899;
DELETE FROM creature_addon WHERE guid=283900;
DELETE FROM creature_addon WHERE guid=245332;
DELETE FROM creature_addon WHERE guid=283903;
DELETE FROM creature_addon WHERE guid=283907;
DELETE FROM creature_addon WHERE guid=245338;
DELETE FROM creature_addon WHERE guid=245347;
DELETE FROM creature_addon WHERE guid=245322;
DELETE FROM creature_addon WHERE guid=283908;
DELETE FROM creature_addon WHERE guid=283909;
DELETE FROM creature_addon WHERE guid=245331;
DELETE FROM creature_addon WHERE guid=245326;
DELETE FROM creature_addon WHERE guid=283910;
DELETE FROM creature_addon WHERE guid=283911;
DELETE FROM creature_addon WHERE guid=283912;
DELETE FROM creature_addon WHERE guid=283913;
DELETE FROM creature_addon WHERE guid=283915;
DELETE FROM creature_addon WHERE guid=283916;
DELETE FROM creature_addon WHERE guid=283920;
DELETE FROM creature_addon WHERE guid=283921;
DELETE FROM creature_addon WHERE guid=283922;
DELETE FROM creature_addon WHERE guid=283923;
DELETE FROM creature_addon WHERE guid=245329;
DELETE FROM creature_addon WHERE guid=283927;
DELETE FROM creature_addon WHERE guid=283932;
DELETE FROM creature_addon WHERE guid=245333;
DELETE FROM creature_addon WHERE guid=245328;
DELETE FROM creature_addon WHERE guid=283933;
DELETE FROM creature_addon WHERE guid=283934;
DELETE FROM creature_addon WHERE guid=283935;
DELETE FROM creature_addon WHERE guid=283940;
DELETE FROM creature_addon WHERE guid=283941;
DELETE FROM creature_addon WHERE guid=283945;
DELETE FROM creature_addon WHERE guid=283947;
DELETE FROM creature_addon WHERE guid=245323;
DELETE FROM creature_addon WHERE guid=284880;
DELETE FROM creature_addon WHERE guid=283918;

delete from creature where id=40064 and guid in (286397,286415,286411,247105,247107,286284,286428,286382,286281,247108,286306,286359,286393,246871,286429,247109);
delete from creature where id=40064 and guid in (286351,246872,286331,247112,286250,248057,286262,286364,286260,286362,286271,246901,286282,286419,286394,286339);
delete from creature where id=40064 and guid in (286270,286366,286263,286337,286319,247114,286423,286264,286265,286346,247179,286268,286272,286276,286341);

update creature set phaseId=0, phaseGroup=443 where id=40064;

DELETE FROM creature_addon WHERE guid=245325;
DELETE FROM creature_addon WHERE guid=283894;
DELETE FROM creature_addon WHERE guid=245339;
DELETE FROM creature_addon WHERE guid=283930;
DELETE FROM creature_addon WHERE guid=283949;
DELETE FROM creature_addon WHERE guid=286415;
DELETE FROM creature_addon WHERE guid=247105;
DELETE FROM creature_addon WHERE guid=246871;
DELETE FROM creature_addon WHERE guid=246872;
DELETE FROM creature_addon WHERE guid=286250;
DELETE FROM creature_addon WHERE guid=247107;
DELETE FROM creature_addon WHERE guid=286260;
DELETE FROM creature_addon WHERE guid=286262;
DELETE FROM creature_addon WHERE guid=286263;
DELETE FROM creature_addon WHERE guid=247179;
DELETE FROM creature_addon WHERE guid=286264;
DELETE FROM creature_addon WHERE guid=286265;
DELETE FROM creature_addon WHERE guid=286268;
DELETE FROM creature_addon WHERE guid=286270;
DELETE FROM creature_addon WHERE guid=286271;
DELETE FROM creature_addon WHERE guid=286272;
DELETE FROM creature_addon WHERE guid=286276;
DELETE FROM creature_addon WHERE guid=286281;
DELETE FROM creature_addon WHERE guid=286282;
DELETE FROM creature_addon WHERE guid=286284;
DELETE FROM creature_addon WHERE guid=247109;
DELETE FROM creature_addon WHERE guid=247112;
DELETE FROM creature_addon WHERE guid=286306;
DELETE FROM creature_addon WHERE guid=286319;
DELETE FROM creature_addon WHERE guid=286331;
DELETE FROM creature_addon WHERE guid=286337;
DELETE FROM creature_addon WHERE guid=286339;
DELETE FROM creature_addon WHERE guid=286341;
DELETE FROM creature_addon WHERE guid=286346;
DELETE FROM creature_addon WHERE guid=248057;
DELETE FROM creature_addon WHERE guid=286351;
DELETE FROM creature_addon WHERE guid=286359;
DELETE FROM creature_addon WHERE guid=286362;
DELETE FROM creature_addon WHERE guid=286364;
DELETE FROM creature_addon WHERE guid=286366;
DELETE FROM creature_addon WHERE guid=247108;
DELETE FROM creature_addon WHERE guid=286382;
DELETE FROM creature_addon WHERE guid=286393;
DELETE FROM creature_addon WHERE guid=286394;
DELETE FROM creature_addon WHERE guid=286397;
DELETE FROM creature_addon WHERE guid=246901;
DELETE FROM creature_addon WHERE guid=286411;
DELETE FROM creature_addon WHERE guid=247114;
DELETE FROM creature_addon WHERE guid=286419;
DELETE FROM creature_addon WHERE guid=286423;
DELETE FROM creature_addon WHERE guid=286428;
DELETE FROM creature_addon WHERE guid=286429;

update creature set equipment_id=0 where id=35234;

update creature set spawndist=0, MovementType=0 where id=40064;

UPDATE creature SET map=648, zoneId=4720, areaId=4873, position_x=814.2797, position_y=2074.643, position_z=94.44454, orientation=5.946309 WHERE id=38187 AND guid=283943;
UPDATE creature SET map=648, zoneId=4720, areaId=4873, position_x=830.1313, position_y=2006.565, position_z=104.5039, orientation=2.470928 WHERE id=38187 AND guid=283906;
UPDATE creature SET map=648, zoneId=4720, areaId=4873, position_x=818.3521, position_y=1940.67, position_z=109.9866, orientation=4.630769 WHERE id=38187 AND guid=283924;
UPDATE creature SET map=648, zoneId=4720, areaId=4873, position_x=772.9404, position_y=2131.274, position_z=79.40811, orientation=1.127895 WHERE id=38187 AND guid=283944;


DELETE FROM gossip_menu WHERE entry=11045 AND text_id=15354;
INSERT INTO gossip_menu VALUES (11045, 15354);

DELETE FROM gossip_menu WHERE entry=11045 AND text_id=15355;
INSERT INTO gossip_menu VALUES (11045, 15355);

DELETE FROM npc_text WHERE ID=15355;
INSERT INTO npc_text (ID) VALUES (15355);
UPDATE npc_text SET Text0_0="Just like old times, eh, $N?$B$BI'm not too busy here to train you. These guys are creampuffs.", BroadcastTextID0=38444, prob0=100, em0_0=6 WHERE ID=15355;

--

DELETE FROM gossip_menu WHERE entry=11046 AND text_id=15356;
INSERT INTO gossip_menu VALUES (11046, 15356);

DELETE FROM gossip_menu WHERE entry=11046 AND text_id=15357;
INSERT INTO gossip_menu VALUES (11046, 15357);

DELETE FROM npc_text WHERE ID=15356;
INSERT INTO npc_text (ID) VALUES (15356);
-- 15356 38445	0	A little help here?

--

DELETE FROM gossip_menu WHERE entry=11047 AND text_id=15358;
INSERT INTO gossip_menu VALUES (11047, 15358);

DELETE FROM gossip_menu WHERE entry=11047 AND text_id=15359;
INSERT INTO gossip_menu VALUES (11047, 15359);

DELETE FROM npc_text WHERE ID=15358;
INSERT INTO npc_text (ID) VALUES (15358);
-- 38447	0	Could you help with this please? I don't have unlimited mana.		6	0	0	0	0	0	0	0	1	18019
DELETE FROM npc_text WHERE ID=15359;
INSERT INTO npc_text (ID) VALUES (15359);
-- 38448	0	Could you help with this please? I don't have unlimited mana.$B$BOf course, if you need some training....		6	0	0	0	0	0	0	0	1	18019

--

DELETE FROM gossip_menu WHERE entry=11048 AND text_id=15360;
INSERT INTO gossip_menu VALUES (11048, 15360);

--

DELETE FROM gossip_menu WHERE entry=11049 AND text_id=15361;
INSERT INTO gossip_menu VALUES (11049, 15361);

DELETE FROM gossip_menu WHERE entry=11049 AND text_id=15362;
INSERT INTO gossip_menu VALUES (11049, 15362);

DELETE FROM npc_text WHERE ID=15361;
INSERT INTO npc_text (ID) VALUES (15361);
UPDATE npc_text SET text0_0="These little things are a pain in my backside!", BroadcastTextID0=38450 WHERE ID=15361;

--

DELETE FROM gossip_menu WHERE entry=11050 AND text_id=15363;
INSERT INTO gossip_menu VALUES (11050, 15363);

DELETE FROM gossip_menu WHERE entry=11050 AND text_id=15364;
INSERT INTO gossip_menu VALUES (11050, 15364);

DELETE FROM npc_text WHERE ID=15364;
INSERT INTO npc_text (ID) VALUES (15364);
UPDATE npc_text SET Text0_1="These pygmies are cutting into profits!$B$BSeeking enlightenment, $N?", BroadcastTextID0=38453, prob0=100, em0_0=6 WHERE ID=15364;

--

DELETE FROM gossip_menu WHERE entry=11051 AND text_id=15365;
INSERT INTO gossip_menu VALUES (11051, 15365);

DELETE FROM gossip_menu WHERE entry=11051 AND text_id=15366;
INSERT INTO gossip_menu VALUES (11051, 15366);

DELETE FROM npc_text WHERE ID=15366;
INSERT INTO npc_text (ID) VALUES (15366);
UPDATE npc_text SET Text0_1="You've got the moves, $N. Now use them!$B$BOr are you looking for some new moves?", BroadcastTextID0=38455, prob0=100, em0_0=397 WHERE ID=15366;

--

DELETE FROM gossip_menu WHERE entry=11052 AND text_id=15367;
INSERT INTO gossip_menu VALUES (11052, 15367);

DELETE FROM gossip_menu WHERE entry=11052 AND text_id=15368;
INSERT INTO gossip_menu VALUES (11052, 15368);

DELETE FROM npc_text WHERE ID=15368;
INSERT INTO npc_text (ID) VALUES (15368);
UPDATE npc_text SET Text0_0="Warrior-Matic NX-01 is online.$B$BInsert coins for further instructional training.", BroadcastTextID0=38457, prob0=100, em0_0=33 WHERE ID=15368;

--

DELETE FROM gossip_menu WHERE entry=12572 AND text_id=17671;
INSERT INTO gossip_menu VALUES (12572, 17671);

DELETE FROM gossip_menu WHERE entry=12572 AND text_id=17672;
INSERT INTO gossip_menu VALUES (12572, 17672);

DELETE FROM npc_text WHERE ID=17672;
INSERT INTO npc_text (ID) VALUES (17672);
UPDATE npc_text SET Text0_0="What can I do for you, $N? Need some training?", BroadcastTextID0=50015, prob0=100, em0_0=6 WHERE ID=17672;

--

DELETE FROM gossip_menu WHERE entry=12576 AND text_id=17681;
INSERT INTO gossip_menu VALUES (12576, 17681);











