
DELETE FROM creature WHERE guid=142892;

UPDATE creature SET spawnMask=0 WHERE guid=92153;

UPDATE quest_template SET NextQuestId=0 WHERE id=929;

UPDATE quest_template SET PrevQuestId=486 WHERE id=997;

UPDATE quest_template SET NextQuestId=0 WHERE id=7383;

UPDATE quest_template SET PrevQuestId=476 WHERE id=13945;

UPDATE quest_template SET PrevQuestId=935 WHERE id=14039;


UPDATE quest_template SET NextQuestId=0 WHERE id=6342;

UPDATE quest_template SET NextQuestId=0 WHERE id=6344;


UPDATE quest_template SET NextQuestId=0 WHERE id=488;

