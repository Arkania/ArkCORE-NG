

UPDATE quest_template SET NextQuestId=26383 WHERE id=13490;

UPDATE quest_template SET PrevQuestId=13591 WHERE id=13519;

UPDATE quest_template SET PrevQuestId=13525 WHERE id=13526;

UPDATE quest_template SET PrevQuestId=13528 WHERE id=13529;

UPDATE quest_template SET PrevQuestId=13528 WHERE id=13557;

UPDATE quest_template SET PrevQuestId=13569 WHERE id=13560;

UPDATE quest_template SET PrevQuestId=13582 WHERE id=13583;

UPDATE quest_template SET PrevQuestId=13519 WHERE id=13601;

UPDATE quest_template SET PrevQuestId=13528 WHERE id=13831;

UPDATE quest_template SET PrevQuestId=13885 WHERE id=13881;

UPDATE quest_template SET PrevQuestId=28517 WHERE id=26385;

