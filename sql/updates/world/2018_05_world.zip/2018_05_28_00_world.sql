

UPDATE quest_template SET PrevQuestId=28713 WHERE id=28714;

UPDATE quest_template SET PrevQuestId=28714 WHERE id=28734;

UPDATE quest_template SET PrevQuestId=28734 WHERE id=28715;


UPDATE quest_template SET PrevQuestId=28715, NextQuestId=26945, ExclusiveGroup=3116, NextQuestIdChain=0 WHERE id=3116;

UPDATE quest_template SET PrevQuestId=28715, NextQuestId=26947, ExclusiveGroup=3116, NextQuestIdChain=0 WHERE id=3117;

UPDATE quest_template SET PrevQuestId=28715, NextQuestId=26946, ExclusiveGroup=3116, NextQuestIdChain=0 WHERE id=3118;

UPDATE quest_template SET PrevQuestId=28715, NextQuestId=26949, ExclusiveGroup=3116, NextQuestIdChain=0 WHERE id=3119;

UPDATE quest_template SET PrevQuestId=28715, NextQuestId=26948, ExclusiveGroup=3116, NextQuestIdChain=0 WHERE id=3120;

UPDATE quest_template SET PrevQuestId=28715, NextQuestId=26940, ExclusiveGroup=3116, NextQuestIdChain=0 WHERE id=26841;


UPDATE quest_template SET PrevQuestId=26841, NextQuestId=28723, ExclusiveGroup=0, NextQuestIdChain=0 WHERE id=26940;

UPDATE quest_template SET PrevQuestId=3116, NextQuestId=28723, ExclusiveGroup=0, NextQuestIdChain=0 WHERE id=26945;

UPDATE quest_template SET PrevQuestId=3118, NextQuestId=28723, ExclusiveGroup=0, NextQuestIdChain=0 WHERE id=26946;

UPDATE quest_template SET PrevQuestId=3117, NextQuestId=28723, ExclusiveGroup=0, NextQuestIdChain=0 WHERE id=26947;

UPDATE quest_template SET PrevQuestId=3120, NextQuestId=28723, ExclusiveGroup=0, NextQuestIdChain=0 WHERE id=26948;

UPDATE quest_template SET PrevQuestId=3119, NextQuestId=28723, ExclusiveGroup=0, NextQuestIdChain=0 WHERE id=26949;


UPDATE quest_template SET NextQuestId=0 WHERE id=933;

UPDATE quest_template SET PrevQuestId=933, NextQuestId=0 WHERE id=934;

UPDATE quest_template SET PrevQuestId=934, NextQuestId=0 WHERE id=935;

UPDATE quest_template SET NextQuestId=0 WHERE id=14005;


UPDATE quest_template SET NextQuestIdChain=0 WHERE id=28723;

UPDATE quest_template SET NextQuestIdChain=0 WHERE id=28724;

UPDATE quest_template SET NextQuestIdChain=0 WHERE id=28725;

UPDATE quest_template SET NextQuestIdChain=0 WHERE id=28727;

UPDATE quest_template SET NextQuestIdChain=0 WHERE id=28728;

UPDATE quest_template SET NextQuestIdChain=0 WHERE id=28729;

UPDATE quest_template SET NextQuestIdChain=0 WHERE id=28730;

UPDATE quest_template SET Flags=11010048 WHERE id=26947; 


