
update creature set phaseIds="170" where guid=245968;
update creature set phaseIds="170 171 172" where guid=245965;
UPDATE creature SET phaseIds="185" WHERE guid=247591;
UPDATE creature SET phaseIds="184 185" WHERE guid=247592;
UPDATE creature SET phaseIds="179" WHERE guid=247593;
UPDATE creature SET phaseIds="179" WHERE guid=247594;
delete from creature where guid = 245962;

update creature set phaseIds="179" where id in (36188, 36418, 36422, 36424, 36426, 36428, 36468, 36469, 36513, 36518, 36519, 36523, 36524);

UPDATE creature SET phaseIds="170 171 172" WHERE id=36179;
UPDATE creature SET phaseIds="179" WHERE guid=246053 AND id=35917;
UPDATE creature SET phaseIds="179" WHERE guid=246054 AND id=36063;
UPDATE creature SET phaseIds="179" WHERE guid=246055 AND id=36578;
UPDATE creature SET phaseIds="179" WHERE guid=246067 AND id=36429;
UPDATE creature SET phaseIds="179" WHERE guid=246068 AND id=36501;
UPDATE creature SET phaseIds="179" WHERE guid=246069 AND id=38738;
UPDATE creature SET phaseIds="179" WHERE guid=246070 AND id=36467;
UPDATE creature SET phaseIds="179" WHERE guid=246073 AND id=36520;
UPDATE creature SET phaseIds="179" WHERE guid=246074 AND id=36521;
UPDATE creature SET phaseIds="179" WHERE guid=246081 AND id=36615;
UPDATE creature SET phaseIds="179" WHERE guid=246263 AND id=36423;
UPDATE creature SET phaseIds="179" WHERE guid=246264 AND id=36423;
UPDATE creature SET phaseIds="179" WHERE guid=246744 AND id=38432;
UPDATE creature SET phaseIds="179" WHERE guid=246782 AND id=36417;
UPDATE creature SET phaseIds="179" WHERE guid=247294 AND id=36383;
UPDATE creature SET phaseIds="179" WHERE guid=247967 AND id=36466;
UPDATE creature SET phaseIds="179" WHERE guid=248444 AND id=36422;

UPDATE creature SET phaseIds="179" WHERE id=36421;
UPDATE creature SET phaseIds="170 171 172 179" WHERE  id=35904;
UPDATE creature SET phaseIds="170 171 172 179" WHERE id=36383;
UPDATE creature SET phaseIds="170 171 172 179" WHERE guid=245986 AND id=36735;
UPDATE creature SET phaseIds="170 171 172" WHERE map=648 AND id=36591;
UPDATE creature SET phaseIds="170" WHERE  id=35897;
UPDATE creature SET phaseIds="171 172 179" WHERE id=35928;
UPDATE creature SET phaseIds="171 172 179" WHERE id=35929;
UPDATE creature SET phaseIds="170" WHERE guid=248543 AND id=35896;
UPDATE creature SET phaseIds="170 171 172 179" WHERE id=35896;
UPDATE creature SET phaseIds="170 171 172 179 180 181 182 183" WHERE guid in (248581, 248582, 248583, 248584) AND id=36719;
UPDATE creature SET phaseIds="170" WHERE id=35995;

delete from creature WHERE guid=249508 AND id=36042;

UPDATE creature SET phaseIds="170 171 172 179" WHERE id=34699; 
UPDATE creature SET phaseIds="170 171 172 179" WHERE id=36740; 
UPDATE creature SET phaseIds="170 171 172 179" WHERE id=36732; 
UPDATE creature SET phaseIds="170 171 172 179" WHERE id=34763; 

UPDATE gameobject SET phaseIds="170 171 172" WHERE id=195201; 
UPDATE gameobject SET phaseIds="170 171 172" WHERE id=195188;
UPDATE gameobject SET phaseIds="170 171 172 179" WHERE guid=168790 and id=202536;

delete from creature WHERE guid=247490 AND id=34748;

UPDATE creature_template SET InhabitType=2 WHERE entry=34763;

update creature set position_x=490.975, position_y=3139.124 where guid=245573;

UPDATE creature SET phaseIds="170 171 172 179" WHERE id=36721; 
UPDATE creature SET phaseIds="170 171 172 179" WHERE id=34748; 

UPDATE creature SET phaseIds="170 171 172" WHERE guid=249461 and id=39169;

UPDATE creature SET phaseIds="170 171 172" WHERE guid=246743;
UPDATE creature SET phaseIds="170 171 172" WHERE id in (36496, 35650, 35786);

UPDATE creature SET phaseIds="170 171 172" WHERE guid=245960 AND id=36427;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245961 AND id=36186;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245963 AND id=36404;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245966 AND id=36180;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245967 AND id=36615;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245969 AND id=36179;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245970 AND id=36179;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245971 AND id=35758;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245972 AND id=35778;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245973 AND id=35780;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245974 AND id=36184;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245976 AND id=36430;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245977 AND id=35805;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245978 AND id=35806;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245980 AND id=35807;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245982 AND id=38432;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=245983 AND id=38738;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=246034 AND id=36426;
UPDATE creature SET phaseIds="170 171 172" WHERE guid=249467 AND id=36406;

UPDATE creature SET phaseIds="170 171 172 " WHERE guid=246030 AND id=36426;
UPDATE creature SET phaseIds="170 171 172 " WHERE guid=246035 AND id=36403;
UPDATE creature SET phaseIds="170 171 172 " WHERE guid=246038 AND id=35810;
UPDATE creature SET phaseIds="170 171 172 " WHERE guid=246039 AND id=35769;
UPDATE creature SET phaseIds="179 " WHERE guid=246040 AND id=35812;
UPDATE creature SET phaseIds="170 171 172 " WHERE guid=246198 AND id=36344;
UPDATE creature SET phaseIds="170 171 172 " WHERE guid=249463 AND id=37895;



