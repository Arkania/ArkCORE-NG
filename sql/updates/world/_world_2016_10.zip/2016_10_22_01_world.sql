

update creature set position_x=599.305, position_y=2783.18, position_z=89.064 where guid=246089;
