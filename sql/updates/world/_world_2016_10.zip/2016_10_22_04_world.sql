

UPDATE creature_template SET InhabitType=4 WHERE entry=23837;

delete from creature where guid in (34352, 34348, 34271, 34295, 34304, 34310, 34319, 34315, 34313, 246205);

DELETE FROM creature_addon WHERE guid=34309;

DELETE FROM creature_addon WHERE guid=34305;

