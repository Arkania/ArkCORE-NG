
update npc_trainer set reqskill=26, spellcost=3600, reqlevel=22 where spell=57755;
