
-- wrong entry in game_event love is in the air..
update game_event set start_time="2013-02-15 01:01:01", occurence=525600, length=20160 where eventEntry=8;
