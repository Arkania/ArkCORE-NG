
update creature set spawndist=0, MovementType=0 where id=10218;
