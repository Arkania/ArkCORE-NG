
UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Hervorragende Arbeit, $N. Es hat sich herausgestellt, dass Ihr ein echter Gewinn für die Garnison seid.$B$BEs steht Euch frei, mit unseren Ausbildern in und um die Abtei herum zu sprechen, wenn Ihr Eure Kampfkünste schulen wollt.$B$BWenn Ihr soweit seid habe ich einen weiteren Auftrag für Euch...", RequestItemsText_loc3="Tötet die Spione!", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück." WHERE Id=29079;

UPDATE locales_quest SET OfferRewardText_loc3="Hervorragende Arbeit, $N. Es hat sich herausgestellt, dass Ihr ein echter Gewinn für die Garnison seid. Es wird Zeit für Eure Ausbildung!", RequestItemsText_loc3="Tötet die Spione", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück." WHERE Id=28774;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Hervorragende Arbeit, $N. Es hat sich herausgestellt, dass Ihr ein echter Gewinn für die Garnison seid. Es wird Zeit für Eure Ausbildung!", RequestItemsText_loc3="Tötet die Spione", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück.", QuestGiverTextWindow_loc3="Dies ist ein männlicher Spion des Schwarzfels. Es sind unter ihnen auch weibliche.", QuestGiverTargetName_loc3="Spion der Schwarzfelsorcs" WHERE Id=28773;

UPDATE locales_quest SET EndText_loc3="", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück." WHERE Id=28772;

UPDATE locales_quest SET OfferRewardText_loc3="Hervorragende Arbeit, $N. Es hat sich herausgestellt, dass Ihr ein echter Gewinn für die Garnison seid. Es wird Zeit für Eure Ausbildung!", RequestItemsText_loc3="Tötet die Spione", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück.", QuestGiverTextWindow_loc3="Dies ist ein männlicher Spion der Schwarzfelsorcs. Es gibt aber auch weibliche unter ihnen.", QuestGiverTargetName_loc3="Spion der Schwarzfelsorcs" WHERE Id=28771;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Hervorragende Arbeit, $N. Es hat sich herausgestellt, dass Ihr ein echter Gewinn für die Garnison seid. Es wird Zeit für Eure Ausbildung!", RequestItemsText_loc3="Tötet die Spione", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück.", QuestGiverTextWindow_loc3="Dies ist ein männlicher Spion des Schwarzfels. Es sind unter ihnen auch weibliche.", QuestGiverTargetName_loc3="Spion der Schwarzfelsorcs" WHERE Id=28770;

UPDATE locales_quest SET OfferRewardText_loc3="Hervorragende Arbeit, $N. Es hat sich herausgestellt, dass Ihr ein echter Gewinn für die Garnison seid. Es wird Zeit für Eure Ausbildung!", RequestItemsText_loc3="Tötet die Spione", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück.", QuestGiverTextWindow_loc3="Dies ist ein männlicher Spion des Schwarzfels. Es sind unter ihnen auch weibliche.", QuestGiverTargetName_loc3="Spion der Schwarzfelsorcs" WHERE Id=28769;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Hervorragende Arbeit, $N. Es hat sich herausgestellt, dass Ihr ein echter Gewinn für die Garnison seid. Es wird Zeit für Eure Ausbildung!", RequestItemsText_loc3="Tötet die Spione", CompletedText_loc3="Kehrt zu Marschall McBride in der Abtei von Nordhain im Wald von Elwynn zurück." WHERE Id=28759;

UPDATE locales_quest SET RequestItemsText_loc3="Ihr habt es in einem Stück hierher geschafft und es sieht so aus, als ob Ihr nicht von zu vielen Leuten gesichtet wurdet. Das reicht mir. Ich mag es nicht, zu viel Aufmerksamkeit auf mich hier zu lenken... ich bin gern für mich und unbehelligt. Ich bin sicher, Ihr versteht mich.$B$BGab es Ärger bisher? Nicht? Freut mich zu hören. Das wird sich jedoch schon bald ändern.", QuestGiverTextWindow_loc3="Ihr könnt Jorik Kerridan im Stall hinter der Abtei von Nordhain finden." WHERE Id=3102;

UPDATE locales_quest SET QuestGiverTextWindow_loc3="Ihr könnt Bruder Sammuel in der Abtei von Nordhain finden, gleich hinter Marschall McBride", QuestGiverTargetName_loc3="Bruder Sammuel" WHERE Id=3101;

UPDATE locales_quest SET QuestGiverTextWindow_loc3="Die Pristerin Anetta befindet sich im hinteren Teil des Bibliotheksflügels, Geht einfach vorbei an Marschall McBride, in die Abtei von Nordhain.", QuestGiverTargetName_loc3="Priesterin Anetta" WHERE Id=3103;

UPDATE locales_quest SET QuestGiverTextWindow_loc3="Ihr findet Khelden Bremen in der Abtei von Nordhain, in der 2ten Etage des Bibliotheksflügels." WHERE Id=3104;

UPDATE locales_quest SET QuestGiverTextWindow_loc3="Ihr findet Drusilla La Salle auf dem Friedhof nahe der Abtei von Nordhain, östlich von Marschall McBride." WHERE Id=3105;

UPDATE locales_quest SET OfferRewardText_loc3="Ihr habt meine Nachricht also erhalten? Ausgezeichnet. Ihr habt Euch im Umgang mit den Orcs als recht geschickt erwiesen. Während Ihr immer mächtiger werdet, werde ich Euch einige neue Techniken lehren.", RequestItemsText_loc3="Hallo, $N. Gibt es etwas, das ich für Euch tun kann?" WHERE Id=26910;

UPDATE locales_quest SET OfferRewardText_loc3="Seid Ihr die Verstärkung, die Thork geschickt hat?$B$BIhr werdet Eure Sache gut machen, vorausgesetzt Ihr könnt Nachtelfen töten. Der Wald ist voll mit ihnen." WHERE Id=28876;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=28876;

UPDATE quest_template SET Method=2, RequiredRaces=946 WHERE Id=28493;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13612;

UPDATE quest_template SET RequiredRaces=946, NextQuestId=13619 WHERE Id=13618;

UPDATE locales_quest SET OfferRewardText_loc3="Hört mir aufmerksam zu, $R...." WHERE Id=13618;

UPDATE locales_quest SET OfferRewardText_loc3="<Kadrak hört aufmerksam zu, während Ihr ihm Gorats letzte Worte übermittelt.>$B$BEs ist also so, wie ich befürchtet hatte. Möge er in Frieden ruhen – aber jetzt noch nicht!", RequestItemsText_loc3="Habt Ihr Gorat gefunden, $C?!" WHERE Id=13619;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13619;

UPDATE locales_quest SET OfferRewardText_loc3="Sehen wir uns das mal an, $C.", RequestItemsText_loc3="Was habt Ihr da,, $R?" WHERE Id=13620;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13620;

UPDATE quest_template SET RequiredRaces=946, NextQuestId=13640 WHERE Id=13628;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Willkommen, $C. Es ist schön, zu sehen, dass die Straße zum Schutzwall von Mor'shan frei bleibt.", CompletedText_loc3="Sprecht mit Gorka im Lager des Kriegshymnenklans im Eschental.." WHERE Id=13628;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13640;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Es scheint, Ihr habt das eine Problem gelöst, nur um vor einem neuen zu stehen, $C.", RequestItemsText_loc3="Habt Ihr das Holz bekommen, das Ihr benötigt?", CompletedText_loc3="Kehrt zu Gorka im Lager des Kriegshymnenklans im Eschental zurück." WHERE Id=13640;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13651;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Habt Dank für das Öl, $C. Jetzt haltet Euch fest!$B$BMein Läufer ist mit niederschmetternden Neuigkeiten zurückgekehrt...$B$BDer Splitterholzposten ist umzingelt!", RequestItemsText_loc3="Habt Ihr das Öl gesammelt, das wir brauchen, $C?", CompletedText_loc3="Sprecht mit Gorka im Holzfällerlager des Kriegshymnenklans." WHERE Id=13651;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13653;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Gorka...$B$BWir müssen immer auf Verluste vorbereitet sein. Ihre ehrenvollen Verdienste für die Horde werden niemals vergessen werden.$B$BAll ihre Opfer werden nicht vergeblich gewesen sein!", CompletedText_loc3="Meldet Euch bei Kadrak am Schutzwall von Mor'shan." WHERE Id=13653;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Gorkas Tod war nicht umsonst, $N.$B$BDer Splitterholzposten wäre sicher gefallen, wenn wir nicht rechtzeitig gekommen wären.$B$BJetzt müssen wir uns daran machen, die Verteidigung wieder aufzubauen.$B$BEs ist noch nicht vorbei...", CompletedText_loc3="Sprecht mit Kadrak im Splitterholzposten." WHERE Id=13712;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13712;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13803;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Das Herz des Waldes verderben?$B$BWie skrupellos – ein äußerst heimtückischer Schlag...$B$BDas gefällt mir!", CompletedText_loc3="Bringt die Blutgetränkte Axt zu Durak am Splitterholzposten." WHERE Id=13803;

UPDATE quest_template SET RequiredRaces=946 WHERE Id=13805;

UPDATE locales_quest SET EndText_loc3="", OfferRewardText_loc3="Ist es vollbracht?$B$BGute Arbeit, $N! Das wird ihre Streitkräfte langsam schwächen und auch ihren Geist.", CompletedText_loc3="Meldet Euch bei Kadrak am Splitterholzposten.", QuestGiverTargetName_loc3="Herz des Waldes" WHERE Id=13805;




