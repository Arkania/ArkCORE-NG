
UPDATE quest_template SET OfferRewardText="Aha!  You got him!$B$BYou do your clan proud, $N. And because of you, Durotar is free of one more agent of evil.", RequestItemsText="Did you find Fizzle, $N?  He, and rest of the Burning Blade, must be scoured from our lands!" WHERE Id=806;


