
DELETE FROM spell_script_names WHERE spell_id=40470 and ScriptName="spell_pal_item_t6_trinket";
INSERT INTO spell_script_names VALUES 
(40470, "spell_pal_item_t6_trinket");

DELETE FROM spell_script_names WHERE spell_id=53651 and ScriptName="spell_pal_light_s_beacon";
INSERT INTO spell_script_names VALUES 
(53651, "spell_pal_light_s_beacon");

DELETE FROM spell_script_names WHERE spell_id=53600 and ScriptName="spell_pal_shield_of_the_righteous";
INSERT INTO spell_script_names VALUES 
(53600, "spell_pal_shield_of_the_righteous");

DELETE FROM spell_script_names WHERE spell_id=28789 and ScriptName="spell_pal_t3_6p_bonus";
INSERT INTO spell_script_names VALUES 
(28789, "spell_pal_t3_6p_bonus");

DELETE FROM spell_script_names WHERE spell_id=64890 and ScriptName="spell_pal_t8_2p_bonus";
INSERT INTO spell_script_names VALUES 
(64890, "spell_pal_t8_2p_bonus");

DELETE FROM spell_script_names WHERE spell_id=20167 and ScriptName="spell_pal_seal_of_insight";
INSERT INTO spell_script_names VALUES 
(20167, "spell_pal_seal_of_insight");		

DELETE FROM spell_script_names WHERE spell_id IN (-87138, 87138) and ScriptName="spell_pal_exorcism";

DELETE FROM spell_script_names WHERE spell_id=26573 and ScriptName="spell_pal_consecration";
INSERT INTO spell_script_names VALUES 
(26573, "spell_pal_consecration");		

DELETE FROM spell_script_names WHERE spell_id=81297 and ScriptName="spell_pal_consecration_damage";
INSERT INTO spell_script_names VALUES 
(81297, "spell_pal_consecration_damage");		

DELETE FROM spell_script_names WHERE spell_id=85222 and ScriptName="spell_pal_ligh_of_dawn";
INSERT INTO spell_script_names VALUES 
(85222, "spell_pal_ligh_of_dawn");		

DELETE FROM spell_script_names WHERE spell_id=31935 and ScriptName="spell_pal_avenger_shield";
INSERT INTO spell_script_names VALUES 
(31935, "spell_pal_avenger_shield");		

DELETE FROM spell_script_names WHERE spell_id=19750 and ScriptName="spell_pal_flash_of_light";
INSERT INTO spell_script_names VALUES 
(19750, "spell_pal_flash_of_light");		

DELETE FROM spell_script_names WHERE spell_id=85673 and ScriptName="spell_pal_word_of_glory";
INSERT INTO spell_script_names VALUES 
(85673, "spell_pal_word_of_glory");		
