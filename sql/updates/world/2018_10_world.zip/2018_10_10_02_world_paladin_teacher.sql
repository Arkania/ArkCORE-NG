

update gossip_menu_option set option_icon=3, OptionBroadcastTextID=5299, option_id=5, npc_option_npcflag=16 where id=0 and menu_id=4663;
update gossip_menu_option set option_icon=3, OptionBroadcastTextID=5299, option_id=5, npc_option_npcflag=16 where id=1 and menu_id=4664;
update gossip_menu_option set option_icon=3, OptionBroadcastTextID=5299, option_id=5, npc_option_npcflag=16 where id=0 and menu_id=12516;

