
DELETE FROM spell_script_names WHERE spell_id=86698 and ScriptName="spell_pal_guardian_of_ancient_kings_retri";
INSERT INTO spell_script_names VALUES
(86698, "spell_pal_guardian_of_ancient_kings_retri");

DELETE FROM spell_script_names WHERE spell_id=86150 and ScriptName="spell_pal_guardian_of_ancient_kings";
INSERT INTO spell_script_names VALUES
(86150, "spell_pal_guardian_of_ancient_kings");

DELETE FROM spell_script_names WHERE spell_id=86704 and ScriptName="spell_pal_ancient_fury";
INSERT INTO spell_script_names VALUES
(86704, "spell_pal_ancient_fury");
