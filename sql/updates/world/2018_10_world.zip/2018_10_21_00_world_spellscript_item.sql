
-- SpellScript: item

DELETE FROM spell_script_names WHERE spell_id=7434 and ScriptName="spell_item_fate_rune_of_unsurpassed_vigor";
INSERT INTO spell_script_names VALUES 
(7434, "spell_item_fate_rune_of_unsurpassed_vigor");

DELETE FROM spell_script_names WHERE spell_id=79637 and ScriptName="spell_item_flask_of_enhancement";
INSERT INTO spell_script_names VALUES 
(79637, "spell_item_flask_of_enhancement");

DELETE FROM spell_script_names WHERE spell_id=82626 and ScriptName="spell_item_grounded_plasma_shield";
INSERT INTO spell_script_names VALUES 
(82626, "spell_item_grounded_plasma_shield");
