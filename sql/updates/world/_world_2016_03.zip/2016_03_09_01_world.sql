

-- fix issue #103
update creature_template set minlevel=29, maxlevel=29 where entry=31636;


