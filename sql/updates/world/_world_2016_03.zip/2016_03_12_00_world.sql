

-- fix issue #107
delete from playercreateinfo_spell where spell=75461;

